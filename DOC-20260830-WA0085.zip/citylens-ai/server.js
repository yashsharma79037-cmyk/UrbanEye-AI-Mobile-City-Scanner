'use strict';
/**
 * CityLens AI server v2 — zero-dependency Node HTTP.
 * Transport concerns only: routing, auth, RBAC gate, body parsing, SSE,
 * static + evidence file streaming. All behaviour lives in src/.
 */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { URL } = require('url');

const db = require('./src/db');
const auth = require('./src/auth');
const { seed } = require('./src/seed');
const cv = require('./src/cv');
const coverage = require('./src/coverage');
const realtime = require('./src/realtime');
const ai = require('./src/ai');
const { ROUTES } = require('./src/api');

/* zero-dependency .env loader (KEY=VALUE lines; existing env wins) */
try {
  for (const line of require('fs').readFileSync(require('path').join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch { /* no .env — defaults apply */ }
const PORT = process.env.PORT || 4000;
const PUB = path.join(__dirname, 'public');
const DATA = path.join(__dirname, 'data');
const JSON_LIMIT = 2 * 1024 * 1024;
const RAW_LIMIT = 122 * 1024 * 1024;

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.mp4': 'video/mp4', '.webm': 'video/webm' };

/* ---------- helpers ---------- */
function send(res, code, body, headers = {}) {
  const h = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'same-origin', ...headers };
  res.writeHead(code, h); res.end(body);
}
function sendJson(res, code, obj) { send(res, code, JSON.stringify(obj), { 'content-type': 'application/json; charset=utf-8' }); }
const safeSeg = s => typeof s === 'string' && !!s && !s.includes('/') && !s.includes('\\') && !s.includes('..');

function matchRoute(method, pathname) {
  for (const r of ROUTES) {
    if (r.method !== method) continue;
    const rp = r.pattern.split('/').filter(Boolean);
    const pp = pathname.split('/').filter(Boolean);
    if (rp.length !== pp.length) continue;
    const params = {}; let ok = true;
    for (let i = 0; i < rp.length; i++) {
      if (rp[i].startsWith(':')) params[rp[i].slice(1)] = decodeURIComponent(pp[i]);
      else if (rp[i] !== pp[i]) { ok = false; break; }
    }
    if (ok) return { route: r, params };
  }
  return null;
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > limit) { reject(new Error('payload too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function userFrom(req, url) {
  let token = null;
  const h = req.headers.authorization;
  if (h && h.startsWith('Bearer ')) token = h.slice(7);
  if (!token) token = url.searchParams.get('token');
  if (!token) return null;
  const payload = auth.verify(token);
  if (!payload) return null;
  return db.get('users', payload.sub) || null;
}

/* simple per-ip rate limits (in-memory sliding window) */
const loginHits = new Map(), regHits = new Map();
function windowLimited(map, ip, windowMs, max) {
  const now = Date.now();
  const arr = (map.get(ip) || []).filter(t => now - t < windowMs);
  arr.push(now); map.set(ip, arr);
  return arr.length > max;
}
const loginLimited = ip => windowLimited(loginHits, ip, 60000, 8);        // 8 / min
const registerLimited = ip => windowLimited(regHits, ip, 10 * 60000, 5); // 5 / 10 min

function streamFile(req, res, filePath, disposition) {
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) return sendJson(res, 404, { error: 'File not found' });
    const ext = path.extname(filePath).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    const range = req.headers.range;
    const base = { 'content-type': type, 'Accept-Ranges': 'bytes', 'X-Content-Type-Options': 'nosniff' };
    if (disposition) base['content-disposition'] = disposition;
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      let start = m && m[1] ? parseInt(m[1]) : 0;
      let end = m && m[2] ? parseInt(m[2]) : st.size - 1;
      if (isNaN(start) || isNaN(end) || start > end || end >= st.size) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); return res.end(); }
      res.writeHead(206, { ...base, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'content-length': end - start + 1 });
      fs.createReadStream(filePath, { start, end }).pipe(res);
    } else {
      res.writeHead(200, { ...base, 'content-length': st.size });
      fs.createReadStream(filePath).pipe(res);
    }
  });
}

/* ---------- server ---------- */
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const p = url.pathname;
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();

  try {
    /* --- SSE --- */
    if (p === '/api/stream' && req.method === 'GET') {
      const user = userFrom(req, url);
      if (!user) return sendJson(res, 401, { error: 'Authentication required' });
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
      return realtime.addClient(res);
    }

    /* --- protected file streams (evidence / repairs / uploads) --- */
    const fileRoute = p.match(/^\/api\/(evidence|repairs|uploads)\/([^/]+)(?:\/([^/]+))?$/);
    if (fileRoute && req.method === 'GET') {
      const user = userFrom(req, url);
      if (!user) return sendJson(res, 401, { error: 'Authentication required' });
      const [, kind, a, b] = fileRoute;
      if (!safeSeg(a) || (b !== undefined && !safeSeg(b))) return sendJson(res, 400, { error: 'Bad path' });
      let fp = null;
      if (kind === 'evidence' && b) fp = path.join(ai.EVIDENCE_DIR, a, b);
      if (kind === 'repairs' && b) fp = path.join(DATA, 'repairs', a, b);
      if (kind === 'uploads' && !b) fp = path.join(ai.UPLOAD_DIR, a);
      if (!fp) return sendJson(res, 400, { error: 'Bad path' });
      return streamFile(req, res, fp);
    }

    /* --- API routes --- */
    if (p.startsWith('/api/')) {
      const m = matchRoute(req.method, p);
      if (!m) return sendJson(res, 404, { error: `No such endpoint: ${req.method} ${p}` });
      const { route, params } = m;

      let user = null;
      if (!route.public) {
        user = userFrom(req, url);
        if (!user) return sendJson(res, 401, { error: 'Authentication required' });
        if (route.perm && !auth.can(user.role, route.perm)) {
          return sendJson(res, 403, { error: `Your role (${auth.ROLES[user.role].label}) lacks permission '${route.perm}'` });
        }
      }
      if (p === '/api/auth/login' && loginLimited(ip)) return sendJson(res, 429, { error: 'Too many login attempts — wait a minute.' });
      if (p === '/api/auth/register' && registerLimited(ip)) return sendJson(res, 429, { error: 'Too many registration attempts — please try again in a few minutes.' });

      let body = null, raw = null;
      if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method)) {
        const ct = (req.headers['content-type'] || '').split(';')[0].trim();
        if (route.raw && ct !== 'application/json') {
          raw = await readBody(req, RAW_LIMIT);
        } else {
          const buf = await readBody(req, JSON_LIMIT);
          if (buf.length) { try { body = JSON.parse(buf.toString('utf8')); } catch { return sendJson(res, 400, { error: 'Invalid JSON body' }); } }
        }
      }

      const ctx = { req, res, user, params, query: Object.fromEntries(url.searchParams), body, raw, ip };
      const out = await route.handler(ctx);
      if (!out) return; // handler streamed its own response
      if (out.body !== undefined) return send(res, out.code, out.body, out.headers || {});
      return sendJson(res, out.code, out.json);
    }

    /* --- static --- */
    let file = p === '/' ? '/index.html' : p;
    if (file === '/app' || file.startsWith('/app/')) file = '/app.html';
    if (file === '/edge' || file.startsWith('/edge/')) file = '/edge.html';
    const fp = path.normalize(path.join(PUB, file));
    if (!fp.startsWith(PUB)) return send(res, 403, 'Forbidden');
    fs.readFile(fp, (err, buf) => {
      if (err) return send(res, 404, 'Not found');
      send(res, 200, buf, { 'content-type': MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-cache' });
    });
  } catch (err) {
    const code = /payload too large/.test(err.message) ? 413 : 500;
    console.error('[server]', req.method, p, err.message);
    sendJson(res, code, { error: code === 413 ? 'Payload too large' : 'Internal server error' });
  }
});

/* ---------- boot ---------- */
seed();
const cap = cv.syncModelRegistry();
coverage.ensureSegments();
realtime.start();
server.listen(PORT, () => {
  const n = c => db.count(c, () => true);
  console.log(`
  ┌─────────────────────────────────────────────────────────────┐
  │  CityLens AI v2 — real-data build                           │
  │  http://localhost:${PORT}   (app: /app · edge client: /edge)   │
  ├─────────────────────────────────────────────────────────────┤
  │  CV engine: ${cap.classical.available ? 'OpenCV ready (classical-cv-v1)     ' : 'UNAVAILABLE — analysis will fail  '}          │
  │  YOLO adapter: ${cap.yolo.configured ? 'configured                     ' : 'Not Configured (YOLO_SERVICE_URL)'}         │
  │  data: users ${n('users')} · routes ${n('routes')} · buses ${n('buses')} · devices ${n('devices')}            │
  │  detections ${n('detections')} · incidents ${n('incidents')} · telemetry ${n('telemetry')}  ← real only     │
  └─────────────────────────────────────────────────────────────┘`);
});
process.on('SIGINT', () => { db.flushNow(); process.exit(0); });
process.on('SIGTERM', () => { db.flushNow(); process.exit(0); });
