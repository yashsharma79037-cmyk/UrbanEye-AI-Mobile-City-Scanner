# Deployment Notes

## Development (Windows laptop)
Double-click `START_CITYLENS_WINDOWS.bat`, or run `node server.js` (Node ≥ 18, zero npm installs). Browser GPS works on `localhost` without HTTPS. Optional Python 3 + OpenCV + ffmpeg enable the built-in CV engine; without them, analysis jobs fail honestly with `AI_SERVICE_FAILURE` (never mocked).

## Configuration
Copy `.env.example` → `.env`. Keys: `PORT`, `CITYLENS_SECRET` (set a long random value in production; otherwise one is generated once into `data/.secret`), `YOLO_SERVICE_URL` (external inference adapter — absent = the Integrations/Models pages truthfully show *Not Configured*). Secrets never reach the frontend.

## Production hardening
- Terminate TLS at a reverse proxy (Caddy/Nginx). **HTTPS is required for field-phone GPS** — browsers block geolocation on plain HTTP away from localhost.
- Change or delete the seeded operational accounts (`src/seed.js`); public sign-ups are always read-only `analyst`.
- Back up `data/` (single JSON store, written atomically via temp-file + rename; evidence/uploads/repairs live alongside it).
- Rate limits are per-process; put a proxy-level limiter in front for internet exposure.

## Scaling path
`schema.sql` is a ready PostgreSQL(+PostGIS) translation of all 26 collections — `src/db.js` is the single data-access seam to swap. The CV contract (`src/cv.js`) accepts any HTTP inference service (YOLO/FastAPI) via one env var; ingest is UUID-idempotent so devices and importers can retry safely.
