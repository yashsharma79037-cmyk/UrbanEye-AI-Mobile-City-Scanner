# Build Status — spec §1–36, honestly assessed

✅ implemented & exercised end-to-end · 🟡 implemented with stated limits · ⭕ deliberately deferred (shows honest status in-app)

| § | Requirement | State | Notes |
|---|---|---|---|
| 1 | Real CV processing | ✅🟡 | OpenCV classical analyzer (pothole/crack/damage) on images **and** video (ffmpeg). Deterministic, feature-derived confidence. YOLO = external adapter, `Not Configured` until `YOLO_SERVICE_URL` set (no weights offline). RTSP ⭕. |
| 2 | Detection storage | ✅ | Full field set incl. model, inference-ms, bbox, evidence refs, validation state; survives restarts. |
| 3 | Telemetry & GPS | ✅ | POST /api/telemetry + trace import + edge-client browser GPS; provenance stored; **No Recent Telemetry** otherwise. |
| 4 | Fleet & devices | ✅ | Registry CRUD (admin), heartbeat-driven status, watchdog flips offline + notification. |
| 5 | Multi-bus dedupe | ✅ | Haversine, per-category radii (configurable), obs/unique-bus/device counts, first/last seen. Image-similarity ⭕. |
| 6 | Confidence aggregation | ✅ | Documented noisy-OR over best-per-device; method string stored; explained in UI. |
| 7 | Incident workflow | ✅ | 11 states, server-side transition service, invalid jumps → 409, VERIFIED only via system re-observation. |
| 8 | Incident history | ✅ | Every change → history row; timeline in UI. |
| 9 | Civic Impact Score | ✅ | 7 weighted factors, all computed (incl. real fleet-exposure pings & zone geo); breakdown persisted; weights editable. |
| 10 | Safety geo-fencing | ✅ | Zone CRUD (typed, weighted), map layer, feeds scoring. |
| 11 | Internal ticketing | ✅ | Own ticket system; PMC push lives under Integrations as `Not Configured`. |
| 12 | Departments | ✅ | Persistent; category→department map editable in Settings, used at confirm/ticket time. |
| 13 | SLA engine | ✅ | Rules by category+minImpact incl. specced examples; server-computed due/remaining/status. |
| 14 | Escalation | ✅ | 3 levels with records + notifications; tested via short-window rule. |
| 15 | Notifications | ✅ | Persistent, role/dept/user-scoped, read/unread/archive, SSE push, deep links. |
| 16 | Field worker UI | ✅ | My Tasks + full flow incl. before/after uploads; also usable via /edge on a phone. |
| 17 | AI repair verification | ✅ | CLEAR obs from real scans; configurable N-clear + M-device + threshold; re-detection ⇒ auto-REOPEN both. |
| 18 | Edge offline queue | ✅ | IndexedDB store-and-forward, retry, UUID-idempotent ingest; on-screen queue stats are the real queue. |
| 19 | Coverage | ✅ | Segment recency from real pings (thresholds shown); fresh/moderate/stale/uncovered. |
| 20 | Road health | ✅ | Documented formula; `insufficient data` when unearned. |
| 21 | GIS command map | ✅🟡 | Layers: buses(live-only)/routes/detections/incidents/tickets/zones/coverage; rich popups. Marker-clustering lib ⭕ (bbox+limit queries mitigate). |
| 22 | Map performance | 🟡 | Server bbox filters + pagination + live-only buses; clustering deferred as above. |
| 23 | Analytics | ✅ | Every chart/table from stored queries; honest empty notes. |
| 24 | Human-in-the-loop | ✅ | 4 decisions, stored feedback, drives model confirmation-rate; sole-obs FP auto-rejects incident. |
| 25 | Model health | ✅ | Derived metrics only; explicit “accuracy not claimed” note. |
| 26 | Privacy evidence | 🟡 | Status field + RBAC on evidence; blur itself `Unavailable — no face/plate model configured` (honest). |
| 27 | Audit log | ✅ | 25+ actions incl. logins, transitions, settings, integrations; filterable UI. |
| 28 | RBAC | ✅ | 6 roles, permission map enforced per-endpoint; verified 403s in tests. |
| 29 | Reporting | ✅🟡 | 7 report types, filters, CSV. PDF ⭕ and says so in-app. |
| 30 | Global search | ✅ | Grouped across incidents/tickets/buses/devices/routes/detections. |
| 31 | Real-time | ✅ | SSE for detections/incidents/tickets/telemetry/jobs/SLA/notifications/devices. |
| 32 | Integrations | ✅ | Config+enable+**real** Test Connection; truthful states; secrets masked, stored server-side. |
| 33 | Assistant | ✅ | Structured query engine over live data incl. “why does X score Y” breakdown; no LLM pretence. |
| 34 | Database design | ✅ | 26 collections + schema.sql relational equivalent; versioned migration archives v1 file. |
| 35 | API engineering | ✅ | ~60 endpoints, validation, proper codes, structured errors. |
| 36 | Security | ✅🟡 | scrypt, JWT expiry, RBAC, upload magic/size checks, login rate-limit, security headers. CSRF n/a (Bearer, no cookies). |

**Removed from v1 for honesty:** bus-movement simulator, ~2 000 seeded detections/incidents, procedural SVG “evidence”, random AI results, fixed 850 GB/98.5 % bandwidth story, hard-coded model accuracy, demo-reset button. v1 modules are archived in `legacy/`.
