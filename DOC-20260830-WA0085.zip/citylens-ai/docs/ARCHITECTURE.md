# Architecture (v2)

```
 bus / phone                      server (Node, zero-npm)                     browsers
┌─────────────┐   HTTPS/JSON   ┌──────────────────────────────┐   SSE   ┌──────────────┐
│ edge.html   │──telemetry────▶│ server.js  (routing·auth·SSE)│────────▶│ /app SPA     │
│  GPS watch  │──octet upload─▶│  src/ingest ─ idempotent UUID│         │ role-scoped  │
│  IndexedDB  │◀─409/200───────│  src/cv ──▶ analyzer.py      │         │ dashboards   │
│  offline q  │                │   (OpenCV+ffmpeg, real px)   │         └──────────────┘
└─────────────┘                │  src/dedupe  haversine+radii │
                               │   └noisy-OR agg over devices │   files: data/uploads
 external YOLO (optional)      │  src/score   7-factor impact │          data/evidence
 YOLO_SERVICE_URL ─ HTTP ─────▶│  src/state   incident/ticket │          data/repairs
 else model = Not Configured   │   server-side state machines │
                               │  src/sla     evaluator+escal.│   store: data/citylens.json
                               │  src/verify  re-observation  │   (26 collections, debounced
                               │   auto-close / auto-reopen   │    writes, v1→v2 migration)
                               │  src/coverage · realtime     │
                               │  src/api  ~60 REST endpoints │
                               └──────────────────────────────┘
```

**Design rules**
1. **Provenance first** — every telemetry ping, detection and evidence file records its true source (`browser | edge | trace_import | upload | synthetic_test`); UI labels follow the data.
2. **No silent fallbacks** — analyzer failure ⇒ job `failed` + AI_SERVICE_FAILURE alert; unconfigured externals say `Not Configured`; absent data renders `insufficient data`.
3. **Server is the authority** — RBAC, state transitions, SLA math, verification thresholds and scores are computed server-side; the SPA only renders.
4. **Idempotent ingest** — client-generated `eventUuid` + ledger makes offline replays safe.
5. **Swappable model** — `cv.analyze()` is a contract; classical OpenCV ships, external YOLO drops in via one env var, and every downstream engine is model-agnostic.
