# CityLens AI — Judge Demo Script (v2, everything live)

**Golden rule of this build:** nothing on screen is pre-scripted. Every number you show is created *during* the demo by real pipeline actions. A fresh install is empty — say that out loud; it's the point.

## 0 · Setup (before judges)
`node server.js` → open `/app` (operator login) on the laptop and `/edge` on a phone (field login). Optional: second laptop tab as **field** user. Toggle ☀/☾ to show both themes.

## 1 · "The city sees" — real inference (90 s)
Operator → **Upload & Analyze**.
- Click **Generate synthetic test frame** (say: *"clearly labelled synthetic pixels — but the analyzer is real OpenCV; watch it measure, not pretend"*). Set capture GPS (e.g. 18.5090, 73.8600) → job runs → show measured inference-ms, annotated frame, feature-derived confidence.
- **Publish** → toast shows *published 1 · merged 0*. Open **Incidents** → your `POT-10xx` exists at `DETECTED` with an impact-score breakdown you can defend line-by-line.

## 2 · "Two buses, one pothole" — dedupe (60 s)
Repeat with GPS ~10 m away and a **different device id** (EDGE-002). Publish → *merged 1*. Open the incident: observations 2, independent devices 2, aggregated confidence jumps (noisy-OR — the explainer is on screen). **This is the differentiator: a city-scale dedup graph, not a marker dump.**

## 3 · Governance kicks in (60 s)
Incident → `UNDER_REVIEW` → `CONFIRMED` (department auto-routes from the editable map) → **Create work ticket**, assign the field worker. Show SLA due-time computed from the rules table. Try `DETECTED → CLOSED` on anything → **409** — the state machine is server-side.

## 4 · Field reality (on the phone, 60 s)
`/edge` as field: **Start telemetry** — the bus goes live on the ops map from *your actual GPS*. In **My Field Tasks** (or app): Acknowledge → Start work → upload **before/after** photos → **Submit repair**. Status flips to `AWAITING_VERIFICATION` — *no one can close it by hand.*

## 5 · The loop closes itself (90 s)
Say: *"repairs are verified by re-observation, not by a button."* Publish **clear** road frames at the same GPS from **two device ids** (need 3 clear + 2 devices by default — thresholds are in Settings). Watch the verification bar fill → incident `VERIFIED → CLOSED`, ticket `RESOLVED (within SLA)`, notifications fire.
**Plan B (stronger):** publish a *defect* frame instead → instant `REOPENED` on incident **and** ticket + VERIFICATION_FAILED alert.

## 6 · Honest edges (30 s — do NOT skip)
- **Integrations** → Test Connection on PMC API → real attempt → truthful `connection_failed / not configured`. *"We never fake Connected."*
- **AI Models** → derived metrics + the line "accuracy is not claimed — no ground-truth set". Judges trust everything else more after this.
- If asked about coverage/traffic: import the sample trace under **Telemetry** and watch segments turn fresh — computed, not painted.

## Rapid Q&A ammo
- *Why classical CV?* Offline build, no weights; the YOLO adapter is one env-var away and the contract is documented. The pipeline (dedupe→SLA→verify) is model-agnostic.
- *Scale?* Bbox queries, pagination, SSE, idempotent UUID ingest, IndexedDB store-and-forward on the edge.
- *Score = 74, why?* Open the incident — the persisted factor breakdown answers it, or ask the Assistant: "why does POT-1001 have its impact score".
