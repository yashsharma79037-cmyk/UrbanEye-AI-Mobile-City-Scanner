# CityLens AI — HTTP API (v2)

Base URL `http://localhost:4000`. All endpoints return JSON unless noted. Authenticate with `Authorization: Bearer <token>` (from login/register). Errors: `{ "error": "message", "field?": "..." }` with proper status codes (400/401/403/404/409/413/415/429). Every mutating action is RBAC-checked server-side and audit-logged.

## Auth (public)
- `POST /api/auth/register` `{name,email,password}` → `201 {token,user}` — validated, scrypt-hashed, role clamped to `analyst`, rate-limited 5/10 min/IP
- `POST /api/auth/login` `{email,password}` → `{token,user}` — rate-limited 8/min/IP
- `POST /api/auth/logout` · `GET /api/auth/me`
- `GET /api/health` → `{server, database:{connected,sizeKB,records}, schema}` · `GET /api/public/stats`

## Ingest
- `POST /api/telemetry` `{eventUuid,busId?,deviceId?,latitude,longitude,speed?,heading?,accuracy?,timestamp?,source}` — validated, UUID-idempotent
- `POST /api/telemetry/import` `{busId?,deviceId?,points:[…≤5000]}` (stored as `trace_import`) · `GET /api/telemetry?busId&since&limit`
- `POST /api/detections/ingest` — external/edge detection events (requires `modelName`; class must be a known category)

## AI analysis
- `POST /api/ai/analyze` — binary body + headers `x-filename,x-lat,x-lng,x-device,x-bus,x-engine` → job; or JSON `{testFrame:true,…}` (watermarked, flagged `synthetic_test`)
- `GET /api/ai/jobs` · `GET /api/ai/jobs/:id` · `POST /api/ai/jobs/:id/publish` (requires real geo)
- `GET /api/models` — derived metrics only; accuracy is not claimed

## Incidents & resolution
- `GET /api/incidents?status&open=1&category&department&minImpact&minLat…` · `GET /api/incidents/:id` (observations, history, ticket, verification, zones, score breakdown)
- `POST /api/incidents/:id/transition` `{to,note}` — server-side state machine (invalid → 409)
- `POST /api/incidents/:id/ticket` · `GET /api/incidents/:id/verification`
- `GET /api/tickets…` · `POST /api/tickets/:id/assign|transition` · `POST /api/tickets/:id/evidence` (binary, `x-kind: before|after`, JPEG/PNG magic-checked, ≤15 MB)
- `POST /api/detections/:id/review` `{decision, correctedCategory?, comment?}`

## Fleet, geo & governance
- Buses `GET/POST /api/buses`, `GET/PATCH /api/buses/:id` · Devices `GET /api/devices`, `PATCH /api/devices/:id`
- Routes `GET /api/routes[/:id]` · Zones `GET/POST/PATCH/DELETE /api/zones[...]`
- Coverage `GET /api/coverage` · Analytics `GET /api/analytics/overview|road-health|traffic`
- SLA `GET/POST/PATCH /api/sla`, `POST /api/sla/evaluate`, `GET /api/sla/escalations`
- Notifications `GET /api/notifications`, `PATCH …/read`, `POST …/read-all`, `PATCH …/archive`
- Reports `GET /api/reports?type=detections|incidents|merges|tickets_sla|verification|department_performance|coverage&from&to[&format=csv]`
- Search `GET /api/search?q=` · Audit `GET /api/audit` · Users `GET/POST/PATCH /api/users`
- Settings `GET /api/settings`, `PATCH /api/settings/:key` · Integrations `GET/PATCH /api/integrations`, `POST /api/integrations/:id/test` (real connection attempt)
- Assistant `GET /api/assistant?q=` — structured queries over live records

## Realtime
- `GET /api/stream?token=…` — SSE: `notification, detection, incident, ticket, telemetry, device, bus, job, sla`

## Files
- `GET /api/evidence/:jobId/:file` · `/api/repairs/:ticketId/:file` · `/api/uploads/:file` — Bearer-protected streams with Range support
