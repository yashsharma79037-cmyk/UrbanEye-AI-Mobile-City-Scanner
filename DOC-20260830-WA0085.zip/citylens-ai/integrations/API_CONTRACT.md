# AI analysis service contract

The dashboard is engine-agnostic. `src/ai.js` calls whichever engine is configured and normalises the output; the UI never changes.

## Request (platform → your service)
When `YOLO_SERVICE_URL` is set, the platform POSTs to `{YOLO_SERVICE_URL}/analyze`:

```json
{
  "jobId": "JOB-XXXX",
  "filename": "dashcam_clip.mp4",
  "filePath": "/api/uploads/1712_dashcam_clip.mp4",
  "latitude": 18.5289, "longitude": 73.8744,
  "routeCode": "R-05"
}
```
Fetch the video from the platform (`filePath`, include the caller's token) or mount a shared volume.

## Response (your service → platform)
```json
{
  "fps": 24.6,
  "inferenceMs": 38,
  "framesProcessed": 2150,
  "results": [
    {
      "detection_type": "pothole",
      "confidence": 0.942,
      "frame_number": 512,
      "timestamp": "2024-06-01T09:41:22Z",
      "latitude": 18.5291,
      "longitude": 73.8747,
      "bounding_box": { "x": 0.41, "y": 0.63, "w": 0.16, "h": 0.11 },
      "severity": "high",
      "evidence_image": "https://your-store/evt_512.jpg"
    }
  ]
}
```

* `detection_type` ∈ pothole, road_crack, road_damage, waterlogging, missing_divider, damaged_divider, missing_zebra, sign_damage, vehicle, congestion, pedestrian_risk, obstruction, accident, other
* `severity` ∈ low, medium, high, critical (omit → platform infers from confidence)
* `bounding_box` is normalised 0–1 (x,y = top-left)
* `evidence_image` optional — if omitted the platform renders a placeholder evidence frame so the UI still works.

Timeout: 120 s. Non-200 or timeout → the platform falls back to the mock engine and tags the job `engine:"mock"`, so demos never break.
