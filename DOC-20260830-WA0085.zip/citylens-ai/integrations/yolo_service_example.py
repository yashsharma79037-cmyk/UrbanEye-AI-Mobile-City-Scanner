"""
CityLens AI — reference YOLO analysis microservice (FastAPI + Ultralytics).

Run:
    pip install fastapi uvicorn ultralytics opencv-python requests
    uvicorn yolo_service_example:app --port 8001
Then start the platform with:
    YOLO_SERVICE_URL=http://localhost:8001 node server.js

Implements the contract in API_CONTRACT.md. Swap `MODEL` / class mapping for
your fine-tuned road-defect weights (e.g. best.pt trained on RDD2022).
"""
import datetime, tempfile, requests
from fastapi import FastAPI
from pydantic import BaseModel

try:
    from ultralytics import YOLO
    MODEL = YOLO("yolov8n.pt")   # replace with your road-defect weights
except Exception:                # keeps the reference importable without weights
    MODEL = None

app = FastAPI(title="CityLens YOLO service")

# Map your model's class names → CityLens detection_type
CLASS_MAP = {
    "pothole": "pothole", "crack": "road_crack", "car": "vehicle", "truck": "vehicle",
    "bus": "vehicle", "motorcycle": "vehicle", "person": "pedestrian_risk",
}
SEVERITY = lambda conf: "critical" if conf > 0.92 else "high" if conf > 0.8 else "medium" if conf > 0.6 else "low"

class Job(BaseModel):
    jobId: str
    filename: str
    filePath: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    routeCode: str | None = None

@app.post("/analyze")
def analyze(job: Job):
    results, frames = [], 0
    if MODEL and job.filePath:
        # Pull the clip from the platform (add ?token=... if auth is enforced)
        src = job.filePath if job.filePath.startswith("http") else f"http://localhost:4000{job.filePath}"
        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as f:
            f.write(requests.get(src, timeout=60).content)
            path = f.name
        for r in MODEL.predict(source=path, stream=True, vid_stride=5, verbose=False):
            frames += 1
            for b in r.boxes:
                name = MODEL.names[int(b.cls)]
                dtype = CLASS_MAP.get(name)
                if not dtype:
                    continue
                conf = float(b.conf)
                x1, y1, x2, y2 = [float(v) for v in b.xyxyn[0]]
                results.append({
                    "detection_type": dtype,
                    "confidence": round(conf, 3),
                    "frame_number": frames * 5,
                    "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
                    "latitude": job.latitude, "longitude": job.longitude,
                    "bounding_box": {"x": x1, "y": y1, "w": x2 - x1, "h": y2 - y1},
                    "severity": SEVERITY(conf),
                    # "evidence_image": upload the annotated crop to your store and put its URL here
                })
    return {"fps": 24.0, "inferenceMs": 40, "framesProcessed": frames * 5, "results": results[:40]}
