'use strict';
/* Pages B: tickets · field tasks · review queue · verification queue · notifications · zones */
(() => {
  const { $, $$, esc, ago, dt, cat, badge, impactBadge, empty, api, src, can, on } = window.CL;
  const CL = window.CL;
  const slaChip = t => { if (!t.dueAt || ['RESOLVED', 'CLOSED'].includes(t.status)) return badge(t.slaStatus || 'RESOLVED'); const m = t.slaRemainingMin; const s = m == null ? '' : m < 0 ? `${-m}m over` : m < 120 ? `${m}m left` : `${Math.round(m / 60)}h left`; return `${badge(t.slaStatus)} <span class="mono muted" style="font-size:11px">${s}</span>`; };

  /* ================= TICKETS ================= */
  CL.page('tickets', async (el, rest) => {
    if (rest[0]) return ticketDetail(el, rest[0]);
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Work Tickets</div><div class="page-sub">Internal municipal ticketing — SLA computed server-side; external PMC push shows under Integrations as Not&nbsp;Configured.</div></div>
      <div class="page-actions"><select id="fs" class="inp inp-sm"><option value="">All states</option>${CL.meta.ticketStates.map(s => `<option>${s}</option>`).join('')}</select>
      <select id="fsla" class="inp inp-sm"><option value="">Any SLA</option><option>WITHIN_SLA</option><option>AT_RISK</option><option>BREACHED</option></select></div></div>
      <div class="card"><div class="tablewrap"><table class="tbl"><thead><tr><th>Ticket</th><th>Incident</th><th>Category</th><th>Department</th><th>Priority</th><th>Status</th><th>SLA</th><th>Assignee</th><th>Esc.</th></tr></thead><tbody id="tb"></tbody></table></div><div id="none"></div></div>`;
    async function load() {
      const q = new URLSearchParams({ limit: 200 });
      if ($('#fs').value) q.set('status', $('#fs').value);
      if ($('#fsla').value) q.set('slaStatus', $('#fsla').value);
      const d = await api('/api/tickets?' + q);
      $('#tb').innerHTML = d.rows.map(t => `<tr class="rowlink" onclick="location.hash='#/tickets/${t.id}'">
        <td class="mono"><b>${t.code}</b></td><td class="mono">${t.incidentCode || '—'}</td><td>${cat(t.category)}</td>
        <td>${esc(t.department)}</td><td>${badge(t.priority === 'CRITICAL' ? 'BREACHED' : t.priority === 'HIGH' ? 'AT_RISK' : 'WITHIN_SLA').replace(/>[^<]+</, '>' + t.priority.toLowerCase() + '<')}</td>
        <td>${badge(t.status)}</td><td>${slaChip(t)}</td><td>${t.assignedOfficer ? esc(t.assignedOfficer.name) : '<span class="muted">—</span>'}</td>
        <td class="mono">${t.escalationLevel || 0}</td></tr>`).join('');
      $('#none').innerHTML = d.rows.length ? '' : empty('No tickets', 'Tickets are raised from CONFIRMED incidents on the incident page.');
    }
    $('#fs').onchange = load; $('#fsla').onchange = load;
    await load(); on('ticket', load); on('sla', load);
  });

  async function ticketDetail(el, id) {
    const d = await api('/api/tickets/' + id);
    const t = d.ticket, inc = d.incident;
    const role = CL.user.role;
    const NEXT = { OPEN: can('ticket.manage') ? [] : [], ASSIGNED: ['ACKNOWLEDGED'], ACKNOWLEDGED: ['WORK_STARTED'], WORK_STARTED: ['REPAIR_SUBMITTED'], REOPENED: can('ticket.manage') ? ['ASSIGNED'] : [] };
    const acts = (NEXT[t.status] || []).filter(() => can('ticket.fieldwork') || can('ticket.manage'));
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title mono">${t.code} ${badge(t.status)}</div>
        <div class="page-sub">${cat(t.category)} · ${esc(t.department)} · impact ${t.impactScore ?? '—'} · ${slaChip(t)}</div></div>
        <div class="page-actions">
          ${acts.map(s => `<button class="btn btn-sm btn-primary" data-tr="${s}">→ ${cat(s.toLowerCase())}</button>`).join('')}
          ${can('ticket.manage') && !t.assignedOfficer ? `<button class="btn btn-sm btn-ghost" id="asgBtn">Assign…</button>` : ''}
          ${inc ? `<a class="btn btn-sm btn-ghost" href="#/incidents/${inc.id}">Incident ↗</a>` : ''}</div></div>
      <div class="grid g23">
        <div>
          <div class="card"><div class="card-t">Repair evidence</div>
            <div class="grid g2">
              ${['before', 'after'].map(k => `<div><div class="dt" style="margin-bottom:6px">${k.toUpperCase()}</div>
                <div class="ev-strip">${d.repairEvidence.filter(e => e.kind === k).map(e => `<a href="${src(e.file)}" target="_blank" class="thumb"><img src="${src(e.file)}"/></a>`).join('') || '<div class="muted" style="font-size:12px">none yet</div>'}</div>
                ${can('repair.submit') && !['RESOLVED', 'CLOSED', 'AWAITING_VERIFICATION'].includes(t.status) ? `<label class="btn btn-sm btn-ghost" style="margin-top:8px">＋ upload ${k}<input type="file" accept="image/*" hidden data-k="${k}"/></label>` : ''}</div>`).join('')}
            </div>
            ${t.status === 'WORK_STARTED' ? `<div class="note-banner" style="margin-top:12px">Submitting the repair requires at least one AFTER photo — then the incident moves to <b>AWAITING_VERIFICATION</b> and only clear re-scans can close it.</div>` : ''}
            ${t.status === 'AWAITING_VERIFICATION' ? `<div class="note-banner ok" style="margin-top:12px">Awaiting AI verification — new scans at this location (buses / edge client / uploads) will confirm or reopen automatically.</div>` : ''}
          </div>
          <div class="card" style="margin-top:14px"><div class="card-t">History</div>
            <div class="timeline">${d.history.slice().reverse().map(h => `<div class="tl-item"><span class="tl-time">${dt(h.timestamp)}</span><div><b>${h.previousStatus ? h.previousStatus + ' → ' : ''}${h.newStatus}</b> <span class="tl-user">${esc(h.changedBy)}</span>${h.note ? `<div class="tl-msg">${esc(h.note)}</div>` : ''}</div></div>`).join('')}</div></div>
        </div>
        <div>
          <div class="card"><div class="card-t">Details</div><div class="meta-grid one">
            <div class="meta-cell"><div class="dt">assignee</div><b>${t.assignedOfficer ? esc(t.assignedOfficer.name) : '—'}</b></div>
            <div class="meta-cell"><div class="dt">sla rule</div><b>${esc(t.slaRuleName || '—')} (${t.slaHours ?? '—'} h)</b></div>
            <div class="meta-cell"><div class="dt">due</div><b>${dt(t.dueAt)}</b></div>
            <div class="meta-cell"><div class="dt">created by</div><b>${esc(t.createdBy || '—')}</b></div>
            <div class="meta-cell"><div class="dt">location</div><b>${esc(t.locationName || '—')}</b></div>
            <div class="meta-cell"><div class="dt">gps</div><b class="mono" style="font-size:12px">${t.latitude != null ? t.latitude.toFixed(5) + ', ' + t.longitude.toFixed(5) : '—'}</b></div></div>
            ${t.latitude != null ? `<a class="btn btn-sm btn-ghost btn-block" style="margin-top:10px" target="_blank" href="https://www.openstreetmap.org/?mlat=${t.latitude}&mlon=${t.longitude}#map=18/${t.latitude}/${t.longitude}">Directions / map ↗</a>` : ''}</div>
          ${d.escalations.length ? `<div class="card" style="margin-top:14px"><div class="card-t">Escalations</div>${d.escalations.map(e2 => `<div class="tl-item"><span class="tl-time">${dt(e2.timestamp)}</span><b>${cat(e2.newLevel.toLowerCase())}</b><div class="muted" style="font-size:11px">${esc(e2.reason)}</div></div>`).join('')}</div>` : ''}
        </div></div>`;
    $$('[data-tr]').forEach(b => b.onclick = async () => {
      try { await api(`/api/tickets/${id}/transition`, { method: 'POST', body: { to: b.dataset.tr, note: b.dataset.tr === 'REPAIR_SUBMITTED' ? prompt('Repair note (optional)') || undefined : undefined } }); CL.toast('Updated'); ticketDetail(el, id); }
      catch (e) { CL.toast(esc(e.message), 'err'); }
    });
    $$('input[type=file][data-k]').forEach(inp => inp.onchange = async () => {
      const f = inp.files[0]; if (!f) return;
      try {
        const r = await fetch(`/api/tickets/${id}/evidence`, { method: 'POST', headers: { authorization: 'Bearer ' + CL.token, 'content-type': 'application/octet-stream', 'x-kind': inp.dataset.k }, body: f });
        const j = await r.json(); if (!r.ok) throw new Error(j.error);
        CL.toast(`${inp.dataset.k} photo stored`); ticketDetail(el, id);
      } catch (e) { CL.toast(esc(e.message), 'err'); }
    });
    const asg = $('#asgBtn');
    if (asg) asg.onclick = async () => {
      const users = (await api('/api/users')).rows.filter(u => ['field', 'officer'].includes(u.role));
      const m = CL.modal('Assign ticket', `<div class="field"><select id="aOff" class="inp">${users.map(u => `<option value="${u.id}">${esc(u.name)} (${u.role})</option>`).join('')}</select></div>`, `<button class="btn btn-primary" id="aGo">Assign</button>`);
      m.querySelector('#aGo').onclick = async () => { try { await api(`/api/tickets/${id}/assign`, { method: 'POST', body: { officerId: m.querySelector('#aOff').value } }); m.remove(); CL.toast('Assigned'); ticketDetail(el, id); } catch (e) { CL.toast(esc(e.message), 'err'); } };
    };
  }

  /* ================= FIELD TASKS ================= */
  CL.page('field', async el => {
    const d = await api('/api/tickets?limit=100');
    const mine = d.rows;
    const open = mine.filter(t => !['RESOLVED', 'CLOSED'].includes(t.status));
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">My Field Tasks</div><div class="page-sub">${CL.user.name} · ${open.length} active assignment(s)</div></div></div>
      ${open.length ? `<div class="grid g2">${open.map(t => `
        <div class="card task-card" onclick="location.hash='#/tickets/${t.id}'">
          <div style="display:flex;justify-content:space-between;align-items:center"><b class="mono">${t.code}</b>${badge(t.status)}</div>
          <div style="margin:6px 0 2px"><b>${cat(t.category)}</b> ${impactBadge(t.impactScore)}</div>
          <div class="muted" style="font-size:12px">${esc(t.locationName || '—')} · ${esc(t.department)}</div>
          <div style="margin-top:8px">${slaChip(t)}</div>
          <div class="muted" style="font-size:11px;margin-top:8px">Tap to open — accept, start work, upload before/after photos, submit repair.</div>
        </div>`).join('')}</div>` : empty('No active field tasks', 'Tasks appear here when an operator or officer assigns a ticket to you.')}
      ${mine.length > open.length ? `<div class="card" style="margin-top:14px"><div class="card-t">Completed</div>${mine.filter(t => ['RESOLVED', 'CLOSED'].includes(t.status)).map(t => `<div class="tick-item"><span>✅</span><div><b class="mono">${t.code}</b> ${cat(t.category)} <span class="muted">· ${badge(t.slaStatus)}</span></div></div>`).join('')}</div>` : ''}`;
    on('ticket', () => CL.pages.field(el, []));
  });

  /* ================= REVIEW QUEUE ================= */
  CL.page('review', async el => {
    el.innerHTML = `<div class="page-head"><div><div class="page-title">AI Review Queue</div><div class="page-sub">Human-in-the-loop — your decisions become the model's confirmation / false-positive metrics.</div></div></div><div id="q"></div>`;
    async function load() {
      const d = await api('/api/detections?validationState=UNREVIEWED&limit=60');
      $('#q').innerHTML = d.rows.length ? `<div class="grid g3">${d.rows.map(r => `
        <div class="card result-card">
          <div class="evidence-frame">${r.evidenceCrop ? `<img src="${src(r.evidenceCrop)}"/>` : `<div class="muted" style="padding:22px;text-align:center;font-size:12px">no frame — ${r.sourceType} ingest</div>`}</div>
          <div style="display:flex;justify-content:space-between;margin-top:8px"><b>${cat(r.category)}</b><span class="badge b-cyan">${(r.confidence * 100).toFixed(1)}%</span></div>
          <div class="muted" style="font-size:11px">${esc(r.modelName)} · ${ago(r.createdAt)} · ${esc(r.locationName || '')}</div>
          <div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap">
            <button class="btn btn-sm btn-green" data-d="CORRECT" data-id="${r.id}">✓ correct</button>
            <button class="btn btn-sm btn-danger" data-d="FALSE_POSITIVE" data-id="${r.id}">✗ false +</button>
            <button class="btn btn-sm btn-ghost" data-open="${r.id}">details…</button></div>
        </div>`).join('')}</div>` : empty('Queue clear — nothing unreviewed', 'New AI detections land here automatically.');
      $$('#q [data-d]').forEach(b => b.onclick = async () => { try { await api(`/api/detections/${b.dataset.id}/review`, { method: 'POST', body: { decision: b.dataset.d } }); CL.toast('Recorded'); load(); } catch (e) { CL.toast(esc(e.message), 'err'); } });
      $$('#q [data-open]').forEach(b => b.onclick = () => { location.hash = '#/detections'; setTimeout(() => CL.openDetection && CL.openDetection(b.dataset.open), 350); });
    }
    await load(); on('detection', load);
  });

  /* ================= VERIFICATION QUEUE ================= */
  CL.page('verifyq', async el => {
    const d = await api('/api/incidents?status=AWAITING_VERIFICATION&limit=100');
    el.innerHTML = `<div class="page-head"><div><div class="page-title">Awaiting Repair Verification</div><div class="page-sub">Closure happens only through clear re-observations — never a button.</div></div></div><div id="vq" class="grid g2"></div>`;
    if (!d.rows.length) { $('#vq').outerHTML = empty('Nothing awaiting verification', 'After a crew submits a repair, the incident sits here until enough clear scans arrive.'); return; }
    for (const i of d.rows) {
      const v = await api(`/api/incidents/${i.id}/verification`);
      $('#vq').insertAdjacentHTML('beforeend', `
        <div class="card" onclick="location.hash='#/incidents/${i.id}'" style="cursor:pointer">
          <div style="display:flex;justify-content:space-between"><b class="mono">${i.code}</b>${impactBadge(i.impactScore)}</div>
          <div class="muted" style="font-size:12px">${cat(i.category)} · ${esc(i.locationName || '')}</div>
          <div class="verify-bar"><span style="width:${Math.min(100, v.clearObservations / v.required.minClearObservations * 100)}%"></span></div>
          <div class="muted" style="font-size:11.5px">${v.clearObservations}/${v.required.minClearObservations} clear scans · ${v.independentDevices}/${v.required.minIndependentDevices} devices · ${v.redetections} re-detections</div>
        </div>`);
    }
  });

  /* ================= NOTIFICATIONS ================= */
  CL.page('notifications', async el => {
    el.innerHTML = `<div class="page-head"><div><div class="page-title">Notifications</div><div class="page-sub">Persistent — generated only by real system events.</div></div>
      <div class="page-actions"><label class="chip"><input type="checkbox" id="fUn"/> unread only</label><button class="btn btn-sm btn-ghost" id="mAll">Mark all read</button></div></div><div class="card" id="list"></div>`;
    async function load() {
      const d = await api('/api/notifications?limit=100' + ($('#fUn').checked ? '&unread=1' : ''));
      CL.setBell(d.unread);
      $('#list').innerHTML = d.rows.length ? d.rows.map(n => `
        <div class="notif ${n.isRead ? '' : 'unread'}" data-id="${n.id}">
          <span class="notif-dot b-${{ critical: 'critical', high: 'high', medium: 'medium', low: 'low' }[n.severity] || 'low'}"></span>
          <div style="min-width:0;flex:1"><div style="display:flex;gap:8px;align-items:baseline"><b>${esc(n.title)}</b><span class="muted" style="font-size:11px">${ago(n.createdAt)}</span></div>
            <div class="muted" style="font-size:12.5px">${esc(n.message)}</div></div>
          ${n.entityType === 'incident' ? `<a class="btn btn-sm btn-ghost" href="#/incidents/${n.entityId}">open</a>` : n.entityType === 'ticket' ? `<a class="btn btn-sm btn-ghost" href="#/tickets/${n.entityId}">open</a>` : ''}
          <button class="icon-btn" data-arch="${n.id}" title="Archive">🗄</button></div>`).join('') : empty('No notifications', 'Critical incidents, SLA events, repairs and verifications will appear here.');
      $$('#list .notif').forEach(x => x.onclick = async e => { if (e.target.closest('a,button')) return; await api(`/api/notifications/${x.dataset.id}/read`, { method: 'PATCH' }); load(); });
      $$('#list [data-arch]').forEach(b => b.onclick = async () => { await api(`/api/notifications/${b.dataset.arch}/archive`, { method: 'PATCH' }); load(); });
    }
    $('#fUn').onchange = load;
    $('#mAll').onclick = async () => { await api('/api/notifications/read-all', { method: 'POST' }); load(); };
    await load(); on('notification', load);
  });

  /* ================= SAFETY ZONES ================= */
  CL.page('zones', async el => {
    el.innerHTML = `<div class="page-head"><div><div class="page-title">Safety Geo-Fencing</div><div class="page-sub">Zones feed the impact-score engine via real proximity checks.</div></div>
      ${can('zones.manage') ? '<div class="page-actions"><span class="muted" style="font-size:12px">Click the map to place a zone</span></div>' : ''}</div>
      <div class="grid g23"><div class="card"><div id="zmap" class="map-el" style="height:520px"></div></div>
      <div class="card"><div class="card-t">Zones</div><div id="zlist"></div></div></div>`;
    let map = null, circles = {};
    if (window.L) {
      map = L.map('zmap').setView([18.5204, 73.8567], 13);
      L.tileLayer(CL.theme === 'light' ? 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png' : 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { maxZoom: 19, attribution: '© OSM © CARTO' }).addTo(map);
      if (can('zones.manage')) map.on('click', e => zoneModal({ latitude: +e.latlng.lat.toFixed(5), longitude: +e.latlng.lng.toFixed(5) }));
    }
    const TYPEC = { SCHOOL: '#E67E22', HOSPITAL: '#C62828', HIGH_FOOTFALL: '#B45309', PEDESTRIAN_PRIORITY: '#138808', CRITICAL_INFRASTRUCTURE: '#3B4390' };
    async function load() {
      const rows = (await api('/api/zones')).rows;
      if (map) { Object.values(circles).forEach(c => map.removeLayer(c)); circles = {};
        rows.filter(z => z.active).forEach(z => circles[z.id] = L.circle([z.latitude, z.longitude], { radius: z.radiusM, color: TYPEC[z.zoneType] || '#3B4390', weight: 1.5, fillOpacity: .12 }).bindPopup(`<b>${esc(z.name)}</b><br>${z.zoneType} · ${z.radiusM} m`).addTo(map)); }
      $('#zlist').innerHTML = rows.length ? rows.map(z => `
        <div class="tick-item"><span style="color:${TYPEC[z.zoneType]}">⛨</span>
          <div style="flex:1;min-width:0"><b>${esc(z.name)}</b> ${z.active ? '' : '<span class="badge b-grey">inactive</span>'}<div class="muted" style="font-size:11px">${cat(z.zoneType.toLowerCase())} · r ${z.radiusM} m · weight ${z.priorityWeight}</div></div>
          ${can('zones.manage') ? `<button class="icon-btn" data-e="${z.id}">✎</button><button class="icon-btn" data-d="${z.id}">🗑</button>` : ''}</div>`).join('') : empty('No zones', 'Add schools, hospitals and footfall areas to weight nearby incidents.');
      $$('#zlist [data-e]').forEach(b => b.onclick = () => zoneModal(rows.find(z => z.id === b.dataset.e)));
      $$('#zlist [data-d]').forEach(b => b.onclick = async () => { if (!confirm('Delete zone?')) return; await api('/api/zones/' + b.dataset.d, { method: 'DELETE' }); CL.toast('Zone deleted'); load(); });
    }
    function zoneModal(z) {
      const isNew = !z.id;
      const m = CL.modal(isNew ? 'New safety zone' : 'Edit zone', `
        <div class="field"><label>Name</label><input id="zn" class="inp" value="${esc(z.name || '')}"/></div>
        <div class="grid g2"><div class="field"><label>Type</label><select id="zt" class="inp">${Object.keys(TYPEC).map(t => `<option ${z.zoneType === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
        <div class="field"><label>Radius (m)</label><input id="zr" class="inp" type="number" value="${z.radiusM || 220}"/></div>
        <div class="field"><label>Priority weight (1–3)</label><input id="zw" class="inp" type="number" min="1" max="3" value="${z.priorityWeight || 2}"/></div>
        <div class="field"><label>Active</label><select id="za" class="inp"><option value="1" ${z.active !== false ? 'selected' : ''}>yes</option><option value="0">no</option></select></div></div>
        <div class="muted" style="font-size:11.5px">at ${z.latitude}, ${z.longitude}</div>`,
        `<button class="btn btn-primary" id="zGo">${isNew ? 'Create' : 'Save'}</button>`);
      m.querySelector('#zGo').onclick = async () => {
        const body = { name: m.querySelector('#zn').value, zoneType: m.querySelector('#zt').value, radiusM: +m.querySelector('#zr').value, priorityWeight: +m.querySelector('#zw').value, active: m.querySelector('#za').value === '1', latitude: z.latitude, longitude: z.longitude };
        try { await api(isNew ? '/api/zones' : '/api/zones/' + z.id, { method: isNew ? 'POST' : 'PATCH', body }); CL.toast('Saved'); m.remove(); load(); } catch (e) { CL.toast(esc(e.message), 'err'); }
      };
    }
    await load();
  });
})();
