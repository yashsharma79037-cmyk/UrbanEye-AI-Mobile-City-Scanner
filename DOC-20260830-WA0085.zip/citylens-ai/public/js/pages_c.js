'use strict';
/* Pages C: telemetry · coverage · analytics · models · assistant · fleet · sla · reports · audit · integrations · users · settings */
(() => {
  const { $, $$, esc, ago, dt, cat, num, badge, impactBadge, empty, api, can, on, every } = window.CL;
  const CL = window.CL;
  const charts = {};
  const chart = (id, cfg) => {
    const cs = getComputedStyle(document.documentElement);
    Chart.defaults.color = cs.getPropertyValue('--mut').trim();
    Chart.defaults.borderColor = cs.getPropertyValue('--line').trim();
    charts[id]?.destroy(); charts[id] = new Chart($('#' + id), cfg);
  };
  const CLR = { cyan: '#D97706', blue: '#3B4390', amber: '#E67E22', red: '#C62828', green: '#138808', violet: '#6B6F9E', mut: '#84847B' };
  Chart.defaults.color = getComputedStyle(document.documentElement).getPropertyValue('--mut').trim() || CLR.mut;
  Chart.defaults.borderColor = 'rgba(140,163,196,.14)';
  Chart.defaults.font.family = 'Inter, sans-serif';

  /* ================= TELEMETRY ================= */
  CL.page('telemetry', async el => {
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Telemetry</div>
        <div class="page-sub">GPS pings from real sources only — browser geolocation, edge devices, imported traces, hardware. Buses without pings show <b>No&nbsp;Recent&nbsp;Telemetry</b>; nothing is animated.</div></div>
        ${can('telemetry.ingest') ? '<div class="page-actions"><button class="btn btn-sm" id="impBtn">⇪ Import route trace</button></div>' : ''}</div>
      <div class="grid g4" id="tkpis"></div>
      <div class="card" style="margin-top:14px"><div class="card-t">Latest pings <span class="muted" id="tcount"></span></div>
        <div class="tablewrap" style="max-height:520px"><table class="tbl"><thead><tr><th>Time</th><th>Bus</th><th>Device</th><th>Lat / Lng</th><th>Speed</th><th>Accuracy</th><th>Source</th></tr></thead><tbody id="tb"></tbody></table></div>
        <div id="none"></div></div>`;
    const row = t => `<tr><td class="mono">${dt(t.timestamp)}</td><td><b>${esc(t.busId || '—')}</b></td><td class="mono">${esc(t.deviceId || '—')}</td>
      <td class="mono muted">${t.latitude.toFixed(5)}, ${t.longitude.toFixed(5)}</td><td>${t.speed == null ? '—' : t.speed + ' km/h'}</td>
      <td>${t.accuracyM == null ? '—' : '±' + Math.round(t.accuracyM) + ' m'}</td><td>${badge(t.source)}</td></tr>`;
    async function load() {
      const d = await api('/api/telemetry?limit=150');
      const srcs = {}; d.rows.forEach(t => srcs[t.source] = (srcs[t.source] || 0) + 1);
      $('#tkpis').innerHTML = `
        <div class="kpi"><div class="kpi-l">Pings loaded</div><div class="kpi-v">${num(d.rows.length)}</div><div class="kpi-s">latest window</div></div>
        <div class="kpi"><div class="kpi-l">Sources</div><div class="kpi-v">${Object.keys(srcs).length || '—'}</div><div class="kpi-s">${Object.entries(srcs).map(([k, v]) => `${cat(k)}: ${v}`).join(' · ') || 'none yet'}</div></div>
        <div class="kpi"><div class="kpi-l">Buses reporting</div><div class="kpi-v">${new Set(d.rows.map(t => t.busId).filter(Boolean)).size}</div><div class="kpi-s">in this window</div></div>
        <div class="kpi"><div class="kpi-l">Live stream</div><div class="kpi-v" id="liveN">0</div><div class="kpi-s">pings since page open (SSE)</div></div>`;
      $('#tb').innerHTML = d.rows.map(row).join('');
      $('#none').innerHTML = d.rows.length ? '' : empty('No telemetry yet', d.note || 'Open the Edge Client on a phone, or import a recorded trace — the fleet map stays honest until then.');
    }
    let live = 0;
    on('telemetry', t => { live++; const n = $('#liveN'); if (n) n.textContent = live; $('#tb')?.insertAdjacentHTML('afterbegin', row(t)); });
    $('#impBtn')?.addEventListener('click', () => {
      const z = CL.modal('Import route trace', `
        <p class="muted" style="margin-top:0">Paste recorded GPS points as JSON. They are stored with source <b>trace_import</b> — clearly labelled, never presented as live movement.</p>
        <div class="grid g2"><label class="lbl">Bus code<input class="inp" id="ibus" placeholder="BUS-003"></label>
        <label class="lbl">Device code<input class="inp" id="idev" placeholder="EDGE-003"></label></div>
        <label class="lbl">Points JSON<textarea class="inp" id="ipts" rows="7" placeholder='[{"latitude":18.5018,"longitude":73.8636,"speed":22,"timestamp":"2026-08-29T06:00:00Z"}, …]'></textarea></label>
        <div class="muted" style="font-size:11.5px">Tip: generate a quick test trace along a route with the button below.</div>`,
        `<button class="btn btn-ghost" id="gen">Generate test trace from route R-05 (stored as trace_import)</button><button class="btn" id="go">Import</button>`);
      z.querySelector('#gen').onclick = async () => {
        const rts = (await api('/api/routes')).rows; const r = rts.find(x => x.routeCode === 'R-05') || rts[0];
        const pts = []; const t0 = Date.now() - r.waypoints.length * 20000;
        r.waypoints.forEach((w, i) => pts.push({ latitude: w[0], longitude: w[1], speed: 18 + (i % 4) * 3, timestamp: new Date(t0 + i * 20000).toISOString(), eventUuid: crypto.randomUUID() }));
        z.querySelector('#ipts').value = JSON.stringify(pts, null, 1);
        z.querySelector('#ibus').value ||= 'BUS-003'; z.querySelector('#idev').value ||= 'EDGE-003';
      };
      z.querySelector('#go').onclick = async () => {
        try {
          const points = JSON.parse(z.querySelector('#ipts').value);
          const r = await api('/api/telemetry/import', { method: 'POST', body: { busId: z.querySelector('#ibus').value.trim(), deviceId: z.querySelector('#idev').value.trim(), points } });
          CL.toast(`Imported <b>${r.imported}</b> points (${r.rejected} rejected) as trace_import`); z.remove(); load();
        } catch (e) { CL.toast(esc(e.message), 'err'); }
      };
    });
    load();
  });

  /* ================= COVERAGE ================= */
  CL.page('coverage', async el => {
    const d = await api('/api/coverage');
    const t = d.totals;
    const pill = s => `<span class="badge b-${{ fresh: 'green', moderate: 'medium', stale: 'high', uncovered: 'grey' }[s]}"><span class="dotb"></span>${s}</span>`;
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Coverage Intelligence</div>
        <div class="page-sub">Segment recency computed from stored telemetry (ping within ${d.thresholds.nearM} m counts). Fresh ≤ ${d.thresholds.freshMin} min · moderate ≤ ${d.thresholds.staleH} h · else stale.</div></div></div>
      <div class="grid g4">
        <div class="kpi"><div class="kpi-l">Network</div><div class="kpi-v">${num(t.segments)}</div><div class="kpi-s">mapped segments</div></div>
        <div class="kpi ${t.freshKm ? 'kpi-good' : 'kpi-dim'}"><div class="kpi-l">Fresh</div><div class="kpi-v">${t.freshKm}<span class="kpi-u"> km</span></div><div class="kpi-s">scanned in last ${d.thresholds.freshMin} min</div></div>
        <div class="kpi"><div class="kpi-l">Touched</div><div class="kpi-v">${t.coveredKm}<span class="kpi-u"> km</span></div><div class="kpi-s">any historical pass</div></div>
        <div class="kpi ${t.uncoveredKm ? 'kpi-bad' : ''}"><div class="kpi-l">Never scanned</div><div class="kpi-v">${t.uncoveredKm}<span class="kpi-u"> km</span></div><div class="kpi-s">${num(t.telemetryPoints)} total pings on record</div></div>
      </div>
      <div class="card" style="margin-top:14px"><div class="card-t">Segments</div>
        <div class="tablewrap" style="max-height:560px"><table class="tbl"><thead><tr><th>Segment</th><th>Road</th><th>Route</th><th>Length</th><th>Status</th><th>Last scanned</th><th>Pings</th><th>Last source</th></tr></thead>
        <tbody>${d.segments.map(s => `<tr><td class="mono muted">${s.id}</td><td><b>${esc(s.roadName)}</b></td><td>${s.routeCode}</td><td>${s.lengthM} m</td><td>${pill(s.status)}</td><td>${s.lastScannedAt ? ago(s.lastScannedAt) : '<span class="muted">never</span>'}</td><td>${s.observationCount}</td><td class="mono">${esc(s.lastBus || '—')}</td></tr>`).join('')}</tbody></table></div>
        ${t.telemetryPoints ? '' : empty('Nothing scanned yet', 'Coverage colours come only from real pings — start the edge client or import a trace and watch segments turn fresh.')}</div>`;
  });

  /* ================= ANALYTICS ================= */
  CL.page('analytics', async el => {
    const [o, rh, tf] = await Promise.all([api('/api/analytics/overview'), api('/api/analytics/road-health'), api('/api/analytics/traffic?hours=6')]);
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Analytics</div><div class="page-sub">Every chart answers a question from stored records. Empty datasets stay empty — no decorative numbers.</div></div></div>
      ${o.note ? `<div class="note-banner">◎ ${esc(o.note)}</div>` : ''}
      <div class="grid g4" style="margin-top:${o.note ? '12px' : '0'}">
        <div class="kpi"><div class="kpi-l">Detections stored</div><div class="kpi-v">${num(o.totals.detections)}</div><div class="kpi-s">${num(o.totals.mergedObservations)} merged as duplicates</div></div>
        <div class="kpi ${o.totals.openCritical ? 'kpi-bad' : ''}"><div class="kpi-l">Open critical</div><div class="kpi-v">${num(o.totals.openCritical)}</div><div class="kpi-s">impact ≥ 70</div></div>
        <div class="kpi"><div class="kpi-l">Review confirmation</div><div class="kpi-v">${o.review.confirmationRate == null ? '—' : o.review.confirmationRate + '<span class="kpi-u">%</span>'}</div><div class="kpi-s">${o.review.reviewed ? `${o.review.reviewed} reviewed · FP ${o.review.falsePositiveRate}%` : 'no human reviews yet'}</div></div>
        <div class="kpi ${o.sla.compliance != null && o.sla.compliance < 80 ? 'kpi-bad' : 'kpi-good'}"><div class="kpi-l">SLA compliance</div><div class="kpi-v">${o.sla.compliance == null ? '—' : o.sla.compliance + '<span class="kpi-u">%</span>'}</div><div class="kpi-s">${o.sla.avgResolutionH == null ? 'no resolved tickets yet' : 'avg resolution ' + o.sla.avgResolutionH + ' h'}</div></div>
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card"><div class="card-t">Ingestion — last 7 days</div><div class="chartbox"><canvas id="cDay"></canvas></div></div>
        <div class="card"><div class="card-t">Detections by category</div><div class="chartbox"><canvas id="cCat"></canvas></div></div>
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card"><div class="card-t">Road health <span class="muted">— ${rh.cityAverage == null ? 'insufficient data' : 'city avg ' + rh.cityAverage + '/100'}</span></div>
          <div class="tablewrap" style="max-height:300px"><table class="tbl"><thead><tr><th>Road</th><th>Route</th><th>km</th><th>Open</th><th>Health</th></tr></thead>
          <tbody>${rh.rows.map(r => `<tr><td><b>${esc(r.roadName)}</b></td><td>${r.routeCode}</td><td>${r.lengthKm}</td><td>${r.openIncidents}${r.openCritical ? ` <span class="badge b-critical">${r.openCritical} crit</span>` : ''}</td>
            <td>${r.health == null ? '<span class="muted">insufficient data</span>' : `<div class="score-row"><div class="bar"><span style="width:${r.health}%;background:${r.health >= 75 ? CLR.green : r.health >= 50 ? CLR.amber : CLR.red}"></span></div><b>${r.health}</b></div>`}</td></tr>`).join('')}</tbody></table></div>
          <div class="muted" style="font-size:11px;padding:8px 2px 0">Formula: 100 − 14·openCritical − 8·openOther − 4·closed30d + 6·min(verified,3)</div></div>
        <div class="card"><div class="card-t">Traffic — avg speed by segment <span class="muted">(last 6 h, from telemetry)</span></div>
          ${tf.rows.length ? `<div class="tablewrap" style="max-height:300px"><table class="tbl"><thead><tr><th>Road</th><th>Samples</th><th>Avg speed</th><th>Level</th></tr></thead>
          <tbody>${tf.rows.map(r => `<tr><td><b>${esc(r.roadName)}</b> <span class="muted">${r.routeCode}</span></td><td>${r.samples}</td><td class="mono">${r.avgSpeed} km/h</td><td>${r.level === 'insufficient_samples' ? '<span class="muted">insufficient samples</span>' : badge(r.level)}</td></tr>`).join('')}</tbody></table></div>`
        : empty('No speed data in window', esc(tf.note || ''))}</div>
      </div>`;
    chart('cDay', { type: 'line', data: { labels: o.byDay.map(x => x.day.slice(5)), datasets: [ { label: 'Detections', data: o.byDay.map(x => x.detections), borderColor: CLR.cyan, backgroundColor: 'rgba(217,119,6,.10)', fill: true, tension: .35 }, { label: 'New incidents', data: o.byDay.map(x => x.incidents), borderColor: CLR.amber, tension: .35 } ] }, options: { plugins: { legend: { labels: { boxWidth: 10 } } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
    const cats = Object.entries(o.byCategory);
    if (cats.length) chart('cCat', { type: 'doughnut', data: { labels: cats.map(c => cat(c[0])), datasets: [{ data: cats.map(c => c[1]), backgroundColor: [CLR.cyan, CLR.amber, CLR.red, CLR.violet, CLR.green, CLR.blue, '#8A6D3B', '#9A9D8F'], borderWidth: 0 }] }, options: { plugins: { legend: { position: 'right', labels: { boxWidth: 10 } } }, cutout: '62%' } });
    else $('#cCat').closest('.card').querySelector('.chartbox').innerHTML = empty('No detections yet', 'Run an analysis to populate this chart.');
  });

  /* ================= MODELS ================= */
  CL.page('models', async el => {
    const d = await api('/api/models');
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">AI Model Health</div><div class="page-sub">Metrics are derived from stored inferences and human review — no ground-truth set exists, so <b>accuracy is not claimed</b>.</div></div></div>
      <div class="grid g2">${d.rows.map(m => `
        <div class="card"><div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">
          <div><div class="card-t" style="margin:0">${esc(m.name)} <span class="muted mono">${esc(m.version)}</span></div>
          <div class="muted" style="font-size:12px;margin-top:3px">${esc(m.task)}</div></div>${badge(m.status)}</div>
          <div class="meta-grid" style="margin-top:12px">
            <div class="meta-cell"><div class="m-l">Inferences stored</div><div class="m-v">${num(m.inferenceCount)}</div></div>
            <div class="meta-cell"><div class="m-l">Avg confidence</div><div class="m-v">${m.avgConfidence == null ? '—' : (m.avgConfidence * 100).toFixed(1) + '%'}</div></div>
            <div class="meta-cell"><div class="m-l">Avg inference</div><div class="m-v">${m.avgInferenceMs == null ? '—' : m.avgInferenceMs + ' ms'}</div></div>
            <div class="meta-cell"><div class="m-l">Human-confirmed</div><div class="m-v">${m.confirmationRate == null ? '—' : m.confirmationRate + '%'} <span class="muted" style="font-size:10px">${m.reviewed ? 'of ' + m.reviewed + ' reviewed' : 'none reviewed'}</span></div></div>
          </div>
          ${m.classes ? `<div style="margin-top:10px">${m.classes.map(c => `<span class="chip">${cat(c)}</span>`).join(' ')}</div>` : ''}
          <div class="muted" style="font-size:11.5px;margin-top:10px;line-height:1.55"><b class="cyan-text">Runtime:</b> ${esc(m.runtime || '—')}<br><b class="cyan-text">Method:</b> ${esc(m.methodology || '')}<br><b class="cyan-text">Note:</b> ${esc(m.accuracyNote)}</div>
        </div>`).join('')}</div>`;
  });

  /* ================= ASSISTANT ================= */
  CL.page('assistant', async el => {
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Command Assistant</div><div class="page-sub">Structured queries answered from live records. No external LLM is configured — and none is imitated.</div></div></div>
      <div class="card"><div style="display:flex;gap:8px"><input class="inp" id="q" placeholder="e.g. why does POT-1001 have its impact score" style="flex:1">
        <button class="btn" id="ask">Ask</button></div>
        <div id="chips" style="margin-top:10px"></div></div>
      <div id="ans" style="margin-top:14px"></div>`;
    const run = async q => {
      $('#q').value = q;
      const r = await api('/api/assistant?q=' + encodeURIComponent(q));
      let body = `<div class="card"><div class="muted" style="font-size:11px;letter-spacing:.08em;text-transform:uppercase">${esc(r.intent)}</div><div style="font-size:15px;margin-top:6px">${esc(r.answer)}</div>`;
      if (r.intent === 'impact_explain' && r.rows.length) {
        body += `<div style="margin-top:12px">${r.rows.map(p => `<div class="score-row"><div style="width:170px" class="muted">${esc(p.label)}</div><div class="bar"><span style="width:${p.max ? p.points / p.max * 100 : 0}%"></span></div><b class="mono">${p.points}</b><span class="muted mono">/${p.max}</span><span class="muted" style="font-size:11px;margin-left:8px">${esc(p.note || '')}</span></div>`).join('')}</div>`;
      } else if (r.rows && r.rows.length) {
        const cols = Object.keys(r.rows[0]);
        body += `<div class="tablewrap" style="margin-top:12px"><table class="tbl"><thead><tr>${cols.map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${r.rows.map(x => `<tr>${cols.map(c => `<td>${esc(x[c] ?? '—')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
      }
      body += '</div>';
      $('#ans').innerHTML = body;
    };
    const examples = ['show critical unresolved potholes', 'which route has the highest defect count', 'which tickets breached SLA today', 'what incidents are awaiting repair verification', 'why does POT-1001 have its impact score'];
    $('#chips').innerHTML = examples.map(x => `<button class="chip chip-btn">${x}</button>`).join(' ');
    $$('#chips .chip-btn').forEach(b => b.onclick = () => run(b.textContent));
    $('#ask').onclick = () => $('#q').value.trim() && run($('#q').value.trim());
    $('#q').onkeydown = e => e.key === 'Enter' && $('#ask').click();
  });

  /* ================= FLEET ================= */
  CL.page('fleet', async el => {
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Fleet & Devices</div><div class="page-sub">Registry is configuration; positions and heartbeats come only from ingested telemetry.</div></div>
        ${can('fleet.manage') ? '<div class="page-actions"><button class="btn btn-sm" id="addBus">+ Add bus</button></div>' : ''}</div>
      <div class="card"><div class="card-t">Buses</div><div class="tablewrap"><table class="tbl"><thead><tr><th>Bus</th><th>Registration</th><th>Route</th><th>Status</th><th>Last telemetry</th><th>Source</th><th>Device</th>${can('fleet.manage') ? '<th></th>' : ''}</tr></thead><tbody id="btb"></tbody></table></div></div>
      <div class="card" style="margin-top:14px"><div class="card-t">Edge devices</div><div class="tablewrap"><table class="tbl"><thead><tr><th>Device</th><th>Mounted on</th><th>Connection</th><th>Last heartbeat</th><th>Camera</th><th>GPS</th><th>AI unit</th><th>Active</th></tr></thead><tbody id="dtb"></tbody></table></div></div>`;
    let routes = [];
    async function load() {
      const [b, d, r] = await Promise.all([api('/api/buses?limit=200'), api('/api/devices?limit=200'), api('/api/routes')]);
      routes = r.rows;
      $('#btb').innerHTML = b.rows.map(x => `<tr>
        <td><b>${esc(x.busCode)}</b></td><td class="mono muted">${esc(x.registrationNumber || '—')}</td>
        <td>${x.routeCode ? `<b>${x.routeCode}</b> <span class="muted">${esc(x.routeName || '')}</span>` : '—'}</td>
        <td>${badge(x.status)}</td>
        <td>${x.lastTelemetryAt ? `${ago(x.lastTelemetryAt)}` : '<span class="muted">No recent telemetry</span>'}</td>
        <td>${x.telemetrySource ? badge(x.telemetrySource) : '—'}</td>
        <td class="mono">${x.device ? `${esc(x.device.deviceCode)} ${badge(x.device.connectionStatus)}` : '—'}</td>
        ${can('fleet.manage') ? `<td><button class="btn btn-ghost btn-sm" data-edit="${x.id}">Edit</button></td>` : ''}</tr>`).join('');
      $('#dtb').innerHTML = d.rows.map(x => `<tr>
        <td><b>${esc(x.deviceCode)}</b>${x.kind === 'field_tablet' ? ' <span class="chip">field tablet</span>' : ''}</td>
        <td class="mono">${esc(x.busCode || '—')}</td><td>${badge(x.connectionStatus)}</td>
        <td>${x.lastHeartbeatAt ? ago(x.lastHeartbeatAt) : '<span class="muted">never</span>'}</td>
        <td class="muted">${cat(x.cameraStatus)}</td><td class="muted">${cat(x.gpsStatus)}</td><td class="muted">${cat(x.aiUnitStatus)}</td>
        <td>${x.active ? badge('active') : badge('disabled')}</td></tr>`).join('');
      if (can('fleet.manage')) $$('#btb [data-edit]').forEach(btn => btn.onclick = () => editBus(b.rows.find(y => y.id === btn.dataset.edit)));
    }
    function busForm(x = {}) {
      return `<div class="grid g2">
        <label class="lbl">Bus code<input class="inp" id="fB" value="${esc(x.busCode || '')}" ${x.id ? 'disabled' : ''} placeholder="BUS-013"></label>
        <label class="lbl">Registration<input class="inp" id="fR" value="${esc(x.registrationNumber || '')}" placeholder="MH-12-2413"></label></div>
        <label class="lbl">Route<select class="inp" id="fRt">${routes.map(r => `<option value="${r.id}" ${x.routeId === r.id ? 'selected' : ''}>${r.routeCode} — ${esc(r.routeName)}</option>`).join('')}</select></label>
        ${x.id ? `<label class="lbl" style="flex-direction:row;align-items:center;gap:8px"><input type="checkbox" id="fA" ${x.active !== false ? 'checked' : ''}> Active in fleet</label>` : ''}`;
    }
    function editBus(x) {
      const z = CL.modal(`Edit ${esc(x.busCode)}`, busForm(x), '<button class="btn" id="sv">Save</button>');
      z.querySelector('#sv').onclick = async () => {
        try { await api('/api/buses/' + x.id, { method: 'PATCH', body: { registrationNumber: z.querySelector('#fR').value.trim(), routeId: z.querySelector('#fRt').value, active: z.querySelector('#fA').checked } }); CL.toast('Bus updated'); z.remove(); load(); }
        catch (e) { CL.toast(esc(e.message), 'err'); }
      };
    }
    $('#addBus')?.addEventListener('click', () => {
      const z = CL.modal('Add bus', busForm(), '<button class="btn" id="sv">Create</button>');
      z.querySelector('#sv').onclick = async () => {
        try { await api('/api/buses', { method: 'POST', body: { busCode: z.querySelector('#fB').value.trim(), registrationNumber: z.querySelector('#fR').value.trim(), routeId: z.querySelector('#fRt').value } }); CL.toast('Bus added to registry'); z.remove(); load(); }
        catch (e) { CL.toast(esc(e.message), 'err'); }
      };
    });
    on('bus', load); on('device', load);
    load();
  });

  /* ================= SLA ================= */
  CL.page('sla', async el => {
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">SLA & Escalations</div><div class="page-sub">Rules apply by category + minimum impact; the evaluator runs every minute on the server clock. Breaches escalate Department&nbsp;Officer → Zone&nbsp;Officer → Command&nbsp;Centre.</div></div>
        <div class="page-actions">${can('sla.manage') ? '<button class="btn btn-sm" id="addR">+ Add rule</button>' : ''}${can('sla.manage') ? '<button class="btn btn-ghost btn-sm" id="evalN">Evaluate now</button>' : ''}</div></div>
      <div class="card"><div class="card-t">Rules</div><div class="tablewrap"><table class="tbl"><thead><tr><th>Name</th><th>Category</th><th>Min impact</th><th>Window</th><th>Active</th>${can('sla.manage') ? '<th></th>' : ''}</tr></thead><tbody id="rtb"></tbody></table></div></div>
      <div class="card" style="margin-top:14px"><div class="card-t">Escalation log</div><div id="esc"></div></div>`;
    async function load() {
      const [r, e] = await Promise.all([api('/api/sla'), api('/api/sla/escalations?limit=50')]);
      $('#rtb').innerHTML = r.rules.map(x => `<tr><td><b>${esc(x.name)}</b></td><td>${x.category === '*' ? '<span class="chip">any category</span>' : cat(x.category)}</td>
        <td>${x.minImpact ? '≥ ' + x.minImpact : '—'}</td><td class="mono">${x.hours} h</td><td>${x.active ? badge('active') : badge('disabled')}</td>
        ${can('sla.manage') ? `<td><button class="btn btn-ghost btn-sm" data-e="${x.id}">Edit</button></td>` : ''}</tr>`).join('');
      $('#esc').innerHTML = e.rows.length ? `<div class="tablewrap"><table class="tbl"><thead><tr><th>Time</th><th>Ticket</th><th>Reason</th><th>Level</th></tr></thead><tbody>
        ${e.rows.map(x => `<tr><td class="mono">${dt(x.timestamp)}</td><td><a href="#/tickets/${x.ticketId}"><b>${esc((x.ticketCode || x.ticketId))}</b></a></td><td>${esc(x.reason)}</td><td>${esc((x.previousLevel || '—').replace(/_/g, ' '))} → <b>${esc(x.newLevel.replace(/_/g, ' '))}</b></td></tr>`).join('')}</tbody></table></div>`
        : empty('No escalations recorded', 'Escalations appear only when a real ticket actually breaches its SLA window.');
      if (can('sla.manage')) $$('#rtb [data-e]').forEach(b => b.onclick = () => form(r.rules.find(y => y.id === b.dataset.e)));
    }
    function form(x = {}) {
      const z = CL.modal(x.id ? 'Edit rule' : 'Add SLA rule', `
        <label class="lbl">Name<input class="inp" id="fN" value="${esc(x.name || '')}"></label>
        <div class="grid g2"><label class="lbl">Category<select class="inp" id="fC">${['*', ...CL.meta.categories].map(c => `<option ${x.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
        <label class="lbl">Min impact (0–100)<input class="inp" id="fM" type="number" value="${x.minImpact ?? 0}"></label></div>
        <label class="lbl">Window (hours)<input class="inp" id="fH" type="number" step="0.1" value="${x.hours ?? 24}"></label>
        ${x.id ? `<label class="lbl" style="flex-direction:row;align-items:center;gap:8px"><input type="checkbox" id="fA" ${x.active ? 'checked' : ''}> Active</label>` : ''}`,
        '<button class="btn" id="sv">Save</button>');
      z.querySelector('#sv').onclick = async () => {
        const body = { name: z.querySelector('#fN').value.trim(), category: z.querySelector('#fC').value, minImpact: +z.querySelector('#fM').value || 0, hours: +z.querySelector('#fH').value };
        try {
          if (x.id) await api('/api/sla/' + x.id, { method: 'PATCH', body: { ...body, active: z.querySelector('#fA').checked } });
          else await api('/api/sla', { method: 'POST', body });
          CL.toast('SLA rule saved'); z.remove(); load();
        } catch (e) { CL.toast(esc(e.message), 'err'); }
      };
    }
    $('#addR')?.addEventListener('click', () => form());
    $('#evalN')?.addEventListener('click', async () => { const r = await api('/api/sla/evaluate', { method: 'POST' }); CL.toast(`Evaluator ran — <b>${r.updated}</b> ticket(s) changed state`); load(); });
    on('sla', load);
    load();
  });

  /* ================= REPORTS ================= */
  CL.page('reports', async el => {
    const TYPES = [['detections', 'Detections'], ['incidents', 'Incidents'], ['merges', 'Duplicate-merge report'], ['tickets_sla', 'Tickets & SLA'], ['verification', 'Verification report'], ['department_performance', 'Department performance'], ['coverage', 'Coverage report']];
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Reports</div><div class="page-sub">Exports run the same queries as the dashboards. CSV is supported; PDF is honestly <b>not implemented</b> in this build.</div></div></div>
      <div class="tri-rail" style="margin:-6px 0 14px"></div>
      <div class="card"><div class="filterbar">
        <select class="inp inp-sm" id="rT">${TYPES.map(t => `<option value="${t[0]}">${t[1]}</option>`).join('')}</select>
        <input class="inp inp-sm" id="rF" type="date"><span class="muted">to</span><input class="inp inp-sm" id="rTo" type="date">
        <button class="btn btn-sm" id="rGo">Preview</button>
        <button class="btn btn-ghost btn-sm" id="rCsv">⇩ Download CSV</button></div>
      <div id="rOut" style="margin-top:12px"></div></div>`;
    const qs = () => { const q = new URLSearchParams({ type: $('#rT').value }); if ($('#rF').value) q.set('from', $('#rF').value); if ($('#rTo').value) q.set('to', $('#rTo').value); return q; };
    $('#rGo').onclick = async () => {
      const d = await api('/api/reports?' + qs());
      $('#rOut').innerHTML = d.rows.length
        ? `<div class="muted" style="font-size:12px;margin-bottom:8px">${d.rows.length} rows · ${esc(d.note)}</div><div class="tablewrap" style="max-height:480px"><table class="tbl"><thead><tr>${d.columns.map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${d.rows.slice(0, 200).map(r => `<tr>${d.columns.map(c => `<td>${esc(r[c] ?? '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`
        : empty('No rows for this selection', 'The report ran — there is simply no matching stored data yet.');
    };
    $('#rCsv').onclick = async () => {
      const r = await fetch('/api/reports?' + qs() + '&format=csv', { headers: { authorization: 'Bearer ' + CL.token } });
      if (!r.ok) return CL.toast('Export failed', 'err');
      const blob = await r.blob(); const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = `citylens_${$('#rT').value}.csv`; a.click(); URL.revokeObjectURL(a.href);
      CL.toast('CSV downloaded — generated from live queries');
    };
    $('#rGo').click();
  });

  /* ================= AUDIT ================= */
  CL.page('audit', async el => {
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Audit Log</div><div class="page-sub">Immutable trail of logins, transitions, uploads, reviews, settings and integration changes.</div></div></div>
      <div class="card"><div class="filterbar">
        <input class="inp inp-sm" id="aQ" placeholder="search text…"><input class="inp inp-sm" id="aA" placeholder="action e.g. TICKET">
        <input class="inp inp-sm" id="aU" placeholder="user email"><button class="btn btn-sm" id="aGo">Filter</button></div>
      <div class="tablewrap" style="max-height:600px;margin-top:12px"><table class="tbl"><thead><tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th><th>IP</th></tr></thead><tbody id="atb"></tbody></table></div><div id="anone"></div></div>`;
    async function load() {
      const q = new URLSearchParams({ limit: 200 });
      if ($('#aQ').value) q.set('q', $('#aQ').value); if ($('#aA').value) q.set('action', $('#aA').value); if ($('#aU').value) q.set('user', $('#aU').value);
      const d = await api('/api/audit?' + q);
      $('#atb').innerHTML = d.rows.map(a => `<tr><td class="mono">${dt(a.timestamp)}</td><td>${esc(a.userEmail || '—')} <span class="muted">${a.role ? '(' + a.role + ')' : ''}</span></td>
        <td><span class="chip">${esc(a.action)}</span></td><td class="mono muted">${esc(a.entityType || '')} ${esc(a.entityId || '')}</td>
        <td class="muted" style="max-width:340px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(a.details || '')}">${esc(a.details || '—')}</td><td class="mono muted">${esc(a.ip || '—')}</td></tr>`).join('');
      $('#anone').innerHTML = d.rows.length ? '' : empty('No audit entries match', '');
    }
    $('#aGo').onclick = load; load();
  });

  /* ================= INTEGRATIONS ================= */
  CL.page('integrations', async el => {
    el.innerHTML = `<div class="page-head"><div><div class="page-title">External Integrations</div>
      <div class="page-sub">Adapters for municipal systems. Status is <b>truthful</b>: a connector says Connected only after a real successful test; otherwise Not&nbsp;Configured / Connection&nbsp;Failed.</div></div></div>
      <div class="grid g2" id="ig"></div>`;
    async function load() {
      const d = await api('/api/integrations');
      $('#ig').innerHTML = d.rows.map(it => `
        <div class="card"><div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start">
          <div><div class="card-t" style="margin:0">${esc(it.name)}</div><div class="muted" style="font-size:12px;margin-top:3px">${esc(it.description)}</div></div>
          ${badge(it.status)}</div>
          ${it.lastTestAt ? `<div class="muted" style="font-size:11.5px;margin-top:8px">Last test ${ago(it.lastTestAt)}: <b>${esc(it.lastTestResult?.message || '')}</b></div>` : ''}
          ${can('integrations.manage') ? `
          <div class="grid g2" style="margin-top:12px">
            <label class="lbl">Endpoint URL<input class="inp inp-sm" data-url="${it.id}" value="${esc(it.config.url || '')}" placeholder="https://…"></label>
            <label class="lbl">API key <span class="muted">(stored server-side)</span><input class="inp inp-sm" data-key="${it.id}" placeholder="${it.config.apiKey ? '•••• saved' : 'paste to set'}"></label></div>
          <div style="display:flex;gap:8px;margin-top:10px">
            <button class="btn btn-sm" data-save="${it.id}">Save</button>
            <button class="btn btn-ghost btn-sm" data-test="${it.id}">Test connection</button>
            <label class="lbl" style="flex-direction:row;align-items:center;gap:7px;margin-left:auto"><input type="checkbox" data-en="${it.id}" ${it.enabled ? 'checked' : ''}> Enabled</label></div>` : ''}
        </div>`).join('');
      if (!can('integrations.manage')) return;
      $$('#ig [data-save]').forEach(b => b.onclick = async () => {
        const id = b.dataset.save; const cfg = {};
        const u = $(`[data-url="${id}"]`).value.trim(); if (u) cfg.url = u;
        const k = $(`[data-key="${id}"]`).value.trim(); if (k) cfg.apiKey = k;
        await api('/api/integrations/' + id, { method: 'PATCH', body: { config: cfg, enabled: $(`[data-en="${id}"]`).checked } });
        CL.toast('Integration saved'); load();
      });
      $$('#ig [data-test]').forEach(b => b.onclick = async () => {
        b.disabled = true; b.textContent = 'Testing…';
        try { const r = await api('/api/integrations/' + b.dataset.test + '/test', { method: 'POST' }); CL.toast(`${r.result.ok ? '✓ Connected' : '✗ ' + cat(r.result.kind)} — ${esc(r.result.message)}`, r.result.ok ? 'ok' : 'err'); }
        catch (e) { CL.toast(esc(e.message), 'err'); }
        load();
      });
      $$('#ig [data-en]').forEach(c => c.onchange = async () => { await api('/api/integrations/' + c.dataset.en, { method: 'PATCH', body: { enabled: c.checked } }); load(); });
    }
    load();
  });

  /* ================= USERS ================= */
  CL.page('users', async el => {
    el.innerHTML = `<div class="page-head"><div><div class="page-title">Users & Roles</div><div class="page-sub">Six roles enforced in the backend on every endpoint — hiding buttons is not the security model.</div></div>
      <div class="page-actions"><button class="btn btn-sm" id="addU">+ Add user</button></div></div>
      <div class="card"><div class="tablewrap"><table class="tbl"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Created</th><th></th></tr></thead><tbody id="utb"></tbody></table></div></div>`;
    async function load() {
      const d = await api('/api/users');
      $('#utb').innerHTML = d.rows.map(u => `<tr><td><b>${esc(u.name)}</b></td><td class="mono muted">${esc(u.email)}</td>
        <td>${badge(u.role)} <span class="muted">${esc(CL.meta.roles[u.role]?.label || '')}</span></td><td>${esc(u.department || '—')}</td>
        <td class="muted">${dt(u.createdAt)}</td><td><button class="btn btn-ghost btn-sm" data-e="${u.id}">Edit</button></td></tr>`).join('');
      $$('#utb [data-e]').forEach(b => b.onclick = () => form(d.rows.find(x => x.id === b.dataset.e)));
    }
    function form(u = {}) {
      const deps = CL.meta.departments;
      const z = CL.modal(u.id ? `Edit ${esc(u.name)}` : 'Add user', `
        <div class="grid g2"><label class="lbl">Name<input class="inp" id="uN" value="${esc(u.name || '')}"></label>
        <label class="lbl">Email<input class="inp" id="uE" value="${esc(u.email || '')}" ${u.id ? 'disabled' : ''}></label></div>
        <div class="grid g2"><label class="lbl">Role<select class="inp" id="uR">${Object.entries(CL.meta.roles).map(([k, v]) => `<option value="${k}" ${u.role === k ? 'selected' : ''}>${v.label}</option>`).join('')}</select></label>
        <label class="lbl">Department<select class="inp" id="uD">${deps.map(d => `<option ${u.department === d ? 'selected' : ''}>${d}</option>`).join('')}</select></label></div>
        <label class="lbl">${u.id ? 'Reset password (blank = keep)' : 'Password'}<input class="inp" id="uP" type="password" autocomplete="new-password"></label>`,
        '<button class="btn" id="sv">Save</button>');
      z.querySelector('#sv').onclick = async () => {
        const body = { name: z.querySelector('#uN').value.trim(), role: z.querySelector('#uR').value, department: z.querySelector('#uD').value };
        const pw = z.querySelector('#uP').value;
        try {
          if (u.id) { if (pw) body.password = pw; await api('/api/users/' + u.id, { method: 'PATCH', body }); }
          else await api('/api/users', { method: 'POST', body: { ...body, email: z.querySelector('#uE').value.trim(), password: pw } });
          CL.toast('User saved'); z.remove(); load();
        } catch (e) { CL.toast(esc(e.message), 'err'); }
      };
    }
    $('#addU').onclick = () => form();
    load();
  });

  /* ================= SETTINGS ================= */
  CL.page('settings', async el => {
    const d = await api('/api/settings');
    const get = k => (d.rows.find(x => x.key === k) || {}).value;
    const radii = get('mergeRadii') || {}; const weights = get('scoringWeights') || {};
    const ver = get('verification') || {}; const map = get('categoryDepartmentMap') || {};
    const DEF_R = { pothole: 20, road_crack: 20, road_damage: 25, waterlogging: 40, missing_divider: 25, damaged_divider: 25, missing_zebra: 15, sign_damage: 15, obstruction: 30, accident: 50, congestion: 120, pedestrian_risk: 40, vehicle: 60, garbage_overflow: 30, missing_sign: 15, rash_driving: 80, road_hazard: 35, other: 25 };
    const DEF_W = { severity: 25, trafficExposure: 18, observations: 16, zoneProximity: 15, age: 10, confidence: 8, recurrence: 8 };
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">System Settings</div><div class="page-sub">These values drive the engines directly — merge radii feed dedupe, weights feed the impact score, thresholds gate auto-close.</div></div></div>
      <div class="grid g2">
        <div class="card"><div class="card-t">Duplicate-merge radii <span class="muted">(m, by category)</span></div>
          <div class="grid g2">${CL.meta.categories.map(c => `<label class="lbl">${cat(c)}<input class="inp inp-sm" data-rad="${c}" type="number" value="${radii[c] ?? DEF_R[c] ?? 25}"></label>`).join('')}</div>
          <button class="btn btn-sm" id="svR" style="margin-top:10px">Save radii</button></div>
        <div>
        <div class="card"><div class="card-t">Impact-score weights <span class="muted">(sum ≈ 100)</span></div>
          <div class="grid g2">${Object.keys(DEF_W).map(k => `<label class="lbl">${cat(k)}<input class="inp inp-sm" data-w="${k}" type="number" value="${weights[k] ?? DEF_W[k]}"></label>`).join('')}</div>
          <button class="btn btn-sm" id="svW" style="margin-top:10px">Save weights</button></div>
        <div class="card" style="margin-top:14px"><div class="card-t">Repair verification thresholds</div>
          <div class="grid g3">
            <label class="lbl">Clear scans<input class="inp inp-sm" id="vC" type="number" value="${ver.minClearObservations ?? 3}"></label>
            <label class="lbl">Indep. devices<input class="inp inp-sm" id="vD" type="number" value="${ver.minIndependentDevices ?? 2}"></label>
            <label class="lbl">Re-detect conf ≥<input class="inp inp-sm" id="vT" type="number" step="0.05" value="${ver.confidenceThreshold ?? 0.55}"></label></div>
          <button class="btn btn-sm" id="svV" style="margin-top:10px">Save thresholds</button></div>
        </div>
      </div>
      <div class="card" style="margin-top:14px"><div class="card-t">Category → Department routing</div>
        <div class="grid g3">${CL.meta.categories.map(c => `<label class="lbl">${cat(c)}<select class="inp inp-sm" data-map="${c}">${CL.meta.departments.map(dep => `<option ${((map[c]) || 'Municipal Command Centre') === dep ? 'selected' : ''}>${dep}</option>`).join('')}</select></label>`).join('')}</div>
        <button class="btn btn-sm" id="svM" style="margin-top:10px">Save routing</button></div>`;
    const save = async (key, value, msg) => { try { await api('/api/settings/' + key, { method: 'PATCH', body: { value } }); CL.toast(msg); } catch (e) { CL.toast(esc(e.message), 'err'); } };
    $('#svR').onclick = () => { const v = {}; $$('[data-rad]').forEach(i => v[i.dataset.rad] = +i.value); save('mergeRadii', v, 'Merge radii updated — applies to the next detection'); };
    $('#svW').onclick = () => { const v = {}; $$('[data-w]').forEach(i => v[i.dataset.w] = +i.value); save('scoringWeights', v, 'Weights saved — scores recompute as incidents update'); };
    $('#svV').onclick = () => save('verification', { minClearObservations: +$('#vC').value, minIndependentDevices: +$('#vD').value, confidenceThreshold: +$('#vT').value }, 'Verification thresholds saved');
    $('#svM').onclick = () => { const v = {}; $$('[data-map]').forEach(s => v[s.dataset.map] = s.value); save('categoryDepartmentMap', v, 'Routing map saved'); };
  });
})();
