# CityLens AI — v2 (Real-Data Build)

**AI-powered buses as mobile city scanners.** Ordinary public-transport buses carry camera + GPS + edge compute; CityLens turns their observations into a full civic-resolution loop:

> detect → record → validate → **merge duplicates** → prioritise → ticket → assign → track repair → **re-observe** → verify → close

## Run

```bash
node server.js          # zero npm dependencies · Node ≥ 18 · Python3 + OpenCV for CV
# app:  http://localhost:4000/app
# edge: http://localhost:4000/edge   (phone-friendly field/bus client)
```

**Windows laptop:** double-click `START_CITYLENS_WINDOWS.bat` — it checks Node, starts the server and opens the app. Configuration is optional via `.env` (see `.env.example`: `PORT`, `CITYLENS_SECRET`, `YOLO_SERVICE_URL`).

**GPS note:** browser geolocation works on `localhost` during development; for real field phones serve CityLens over **HTTPS** (see `docs/DEPLOYMENT.md`). Denied permission shows clear enable-instructions instead of fake coordinates. The map runs on OpenStreetMap/CARTO tiles — **no map API key needed**, with marker clustering, fullscreen, recenter and a my-location control.

## Signing in

Public **Create Account** self-registration is live at `/app` (`POST /api/auth/register`): scrypt-hashed passwords, strict validation, per-IP rate limiting, and every public sign-up is clamped to the read-only **analyst** role — privileged roles are assignable only by an admin from Users & Roles. A visible **Log out** action sits in the profile area (app) and on the Edge client.

## Seeded operational accounts (for development & evaluation)

| Role | Email | Password |
|---|---|---|
| System Admin | admin@citylens.ai | admin123 |
| Command Centre Operator | operator@citylens.ai | operator123 |
| Dept. Officer (Roads) | roads@citylens.ai | officer123 |
| Dept. Officer (Drainage) | drainage@citylens.ai | officer123 |
| Field Worker | field@citylens.ai | field123 |
| AI Reviewer | reviewer@citylens.ai | review123 |
| Read-Only Analyst | analyst@citylens.ai | analyst123 |

RBAC is enforced **in the backend** on every endpoint — hiding buttons is not the security model.

## What is genuinely real here

- **Computer vision** — `src/analyzer.py` runs OpenCV (contours, adaptive threshold, Canny) on your uploaded images/videos; confidence is derived from *measured* features (ring-contrast, solidity, elongation). ffmpeg samples video frames. Evidence JPEGs (annotated frame + crop) are written from the actual pixels. A deep-learning **YOLO adapter** exists but is honestly `Not Configured` until you set `YOLO_SERVICE_URL`.
- **Telemetry** — only from real sources: the edge client’s browser GPS, imported traces (labelled `trace_import`), or hardware later. Buses with no pings say **No Recent Telemetry**; nothing is animated.
- **Dedupe** — Haversine matching with per-category radii (Settings); repeated sightings attach as observations; incident confidence uses documented **noisy-OR over independent devices**.
- **Impact score** — 0–100 from configurable weights; every factor (fleet exposure = real pings ≤150 m/24 h, safety-zone proximity, age, recurrence…) is computed and the breakdown is stored & shown.
- **Workflow** — server-side state machines for incidents & tickets; invalid jumps → 409; every change writes history.
- **SLA** — rules table → `dueAt` computed at creation; a real evaluator flips `AT_RISK`/`BREACHED`, writes escalations (Dept → Zone → Command Centre) and notifications.
- **Repair verification** — closing needs **re-observation**: N clear scans from M independent devices with no re-detection ≥ threshold (Settings). A re-detection auto-**REOPENS** incident *and* ticket. No “mark verified” button exists.
- **Edge offline queue** — the edge client stores events in IndexedDB when offline and retries with UUID-idempotent ingest; queue counts on screen are the real queue.
- **Coverage / road-health / traffic** — computed from stored telemetry & incidents with documented formulas; empty data ⇒ `insufficient data`, never invented.
- **Analytics, reports (CSV), search, audit, notifications, model health** — all straight from stored records. PDF export is *not implemented* and says so.
- **Integrations** — adapters ship `Not Configured`; **Test Connection** makes a real request and records the truthful outcome.

A fresh install therefore starts **empty** — that’s correct behaviour, not a bug.

## 3-minute live demo (no faking required)

1. **Operator** → *Upload & Analyze* → “Generate synthetic test frame” (clearly labelled) or upload your own road photo, set capture GPS → watch the real analyzer return boxes + evidence → **Publish**.
2. Publish a second frame with GPS ~10 m away → dedupe **merges** it: observation 2, device count, noisy-OR confidence rise.
3. Open the incident → `UNDER_REVIEW` → `CONFIRMED` → **Create work ticket** (department auto-routed) — SLA clock starts.
4. **Field** login (or `/edge` on a phone) → acknowledge → start work → upload before/after photos → **Submit repair** → status becomes `AWAITING_VERIFICATION`.
5. Publish clear road frames near the spot from two device IDs → verification progress fills → incident **VERIFIED → CLOSED**, ticket resolved within SLA. (Publish a defect frame instead → **REOPENED** + notification.)
6. *Telemetry* → import the sample trace → Coverage segments turn **fresh**; Overview buses go live.

`docs/DEMO_SCRIPT.md` has the full narrated version; `docs/STATUS.md` maps every spec section to its implementation state — including what’s deliberately deferred.

## Layout

```
server.js          transport: routing, auth gate, SSE, static, file streams
src/               db · geo · state · score · dedupe · sla · verify · ingest
                   cv.js + analyzer.py · coverage · realtime · api · seed (config-only)
public/            app.html + js/ (SPA) · edge.html · index.html (landing)
legacy/            archived v1 modules that generated demo data (kept for audit)
schema.sql         relational equivalent of the embedded store
```

## Design system — "Tiranga"

The UI uses an Indian-tricolour-derived engineering palette, not the generic AI-dashboard blue: warm neutral surfaces (70–80 %), **saffron `#E88922`** for primary actions and active states, **India green `#138808`** strictly for healthy/verified/resolved semantics, and **Ashoka navy `#16164F`** as a quiet identity colour (logo, headings, bus markers). One recognisable signature — a thin saffron-neutral-green rail — appears under the brand, on the login card, report headers and the boot spinner. Light is the primary theme (system-aware on first load); dark is a warm night-ops variant, not black-and-neon. All colours are CSS tokens in `public/css/app.css`, so both themes cover the map, charts, tables, forms and modals.
