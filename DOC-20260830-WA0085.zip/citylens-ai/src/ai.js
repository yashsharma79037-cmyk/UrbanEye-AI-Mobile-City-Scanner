'use strict';
/**
 * AI job service v2. An analysis job is a REAL unit of work:
 *   upload (image/video, validated) → analyzer (OpenCV or external YOLO)
 *   → structured results + real evidence JPEGs on disk → operator publishes
 *   → each result enters the ingestion pipeline (dedupe/scoring/verification).
 * Failures are stored as failures. Nothing is invented.
 *
 * Demo aid (clearly labelled, never hidden): generateTestFrame() renders a
 * synthetic road image with painted defects so the pipeline can be exercised
 * without street footage. Jobs created this way carry sourceKind
 * 'synthetic_test' and the flag is displayed everywhere the data appears.
 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const db = require('./db');
const { uid } = require('./util');
const cv = require('./cv');
const ingest = require('./ingest');
const verify = require('./verify');
const { audit } = require('./audit');

const UPLOAD_DIR = path.join(__dirname, '..', 'data', 'uploads');
const EVIDENCE_DIR = path.join(__dirname, '..', 'data', 'evidence');
const MAX_BYTES = 120 * 1024 * 1024;
const EXT_OK = ['.mp4', '.mov', '.avi', '.mkv', '.webm', '.jpg', '.jpeg', '.png'];

let emit = () => { };
function bindEmitter(fn) { emit = fn; }

function dirBytes(dir) {
  try { return fs.readdirSync(dir).reduce((a, f) => a + fs.statSync(path.join(dir, f)).size, 0); } catch { return 0; }
}

function createJobFromUpload(buffer, meta, actor) {
  const ext = path.extname(meta.filename || '').toLowerCase();
  if (!EXT_OK.includes(ext)) return { ok: false, code: 400, error: `Unsupported file type ${ext || '(none)'} — allowed: ${EXT_OK.join(' ')}` };
  if (!buffer || !buffer.length) return { ok: false, code: 400, error: 'Empty upload' };
  if (buffer.length > MAX_BYTES) return { ok: false, code: 413, error: 'File exceeds 120 MB limit' };

  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const id = uid('JOB');
  const stored = `${id}${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, stored), buffer);

  const job = db.insert('ai_jobs', {
    id, filename: meta.filename, storedFile: stored, filePath: path.join(UPLOAD_DIR, stored),
    sizeBytes: buffer.length, kind: ext === '.jpg' || ext === '.jpeg' || ext === '.png' ? 'image' : 'video',
    sourceKind: meta.sourceKind || 'upload',
    engine: meta.engine === 'yolo-external' ? 'yolo-external' : 'classical-cv-v1',
    latitude: Number.isFinite(meta.latitude) ? meta.latitude : null,
    longitude: Number.isFinite(meta.longitude) ? meta.longitude : null,
    routeCode: meta.routeCode || null, deviceId: meta.deviceId || null, busId: meta.busId || null,
    scanRadiusM: 60,
    status: 'queued', error: null, results: null,
    framesProcessed: null, avgInferenceMs: null, measuredFps: null,
    rawBytes: buffer.length, evidenceBytes: null,
    requestedBy: actor ? actor.email : null,
    published: false, publishedAt: null, publishedCounts: null,
    createdAt: new Date().toISOString(),
  });
  audit(actor, 'ANALYSIS_UPLOADED', 'ai_job', id, `${meta.filename} (${(buffer.length / 1024).toFixed(0)} KB, ${job.engine})`);
  setImmediate(() => runJob(id));
  return { ok: true, job };
}

async function runJob(id) {
  let job = db.get('ai_jobs', id);
  if (!job) return;
  db.update('ai_jobs', id, { status: 'processing', startedAt: new Date().toISOString() });
  emit('job', { id, status: 'processing' });

  const outDir = path.join(EVIDENCE_DIR, id);
  fs.mkdirSync(outDir, { recursive: true });
  const r = await cv.analyze(job, outDir);

  if (!r.ok) {
    db.update('ai_jobs', id, { status: 'failed', error: r.error, finishedAt: new Date().toISOString() });
    emit('job', { id, status: 'failed', error: r.error });
    return;
  }
  const results = (r.results || []).map((d, i) => ({
    idx: i,
    class: d.class, confidence: d.confidence,
    frameNumber: d.frame_number ?? null, frameTimeS: d.frame_time_s ?? null,
    bboxNorm: d.bbox_norm || null, bboxPx: d.bbox_px || null, features: d.features || null,
    evidenceImage: d.evidence_annotated ? `/api/evidence/${id}/${d.evidence_annotated}` : (d.evidence_url || null),
    evidenceCrop: d.evidence_crop ? `/api/evidence/${id}/${d.evidence_crop}` : null,
    latitude: Number.isFinite(d.latitude) ? d.latitude : job.latitude,
    longitude: Number.isFinite(d.longitude) ? d.longitude : job.longitude,
  }));
  job = db.update('ai_jobs', id, {
    status: 'complete', results, engine: r.engine || job.engine,
    framesProcessed: r.framesProcessed ?? null,
    avgInferenceMs: r.avgInferenceMs ?? null, measuredFps: r.measuredFps ?? null,
    evidenceBytes: dirBytes(outDir),
    finishedAt: new Date().toISOString(),
  });
  emit('job', { id, status: 'complete', detections: results.length });
}

/** Publish job results into the live pipeline. Requires real geo on job or per result. */
function publish(jobId, actor) {
  const job = db.get('ai_jobs', jobId);
  if (!job) return { ok: false, code: 404, error: 'Job not found' };
  if (job.status !== 'complete') return { ok: false, code: 409, error: `Job is ${job.status}, not complete` };
  if (job.published) return { ok: true, idempotent: true, counts: job.publishedCounts };
  const missingGeo = (job.results || []).some(r => !Number.isFinite(r.latitude) || !Number.isFinite(r.longitude));
  if (missingGeo) return { ok: false, code: 400, error: 'No GPS on this job — set capture latitude/longitude before publishing (detections are never placed by guesswork).' };

  const created = [];
  let merged = 0, idem = 0;
  for (const r of job.results || []) {
    const res = ingest.ingestDetection({
      eventUuid: `${job.id}:${r.idx}`,
      class: r.class, confidence: r.confidence,
      latitude: r.latitude, longitude: r.longitude,
      bbox: r.bboxNorm, frameNumber: r.frameNumber,
      deviceId: job.deviceId, busId: job.busId, routeId: job.routeCode,
      jobId: job.id, modelName: job.engine, modelVersion: job.engine === 'classical-cv-v1' ? 'v1' : 'external',
      inferenceMs: job.avgInferenceMs,
      evidenceImage: r.evidenceImage, evidenceCrop: r.evidenceCrop,
      timestamp: job.createdAt,
    }, 'upload', actor);
    if (!res.ok) return { ok: false, code: res.code || 400, error: `Result ${r.idx}: ${res.error}` };
    if (res.idempotent) idem++;
    else { created.push({ ...r, category: r.class, id: res.detection.id }); if (res.merged) merged++; }
  }
  const cleared = verify.onScanCompleted(job, created);
  const counts = { published: created.length, mergedIntoExisting: merged, idempotentReplays: idem, verificationClears: cleared.length };
  db.update('ai_jobs', jobId, { published: true, publishedAt: new Date().toISOString(), publishedCounts: counts });
  audit(actor, 'ANALYSIS_PUBLISHED', 'ai_job', jobId, JSON.stringify(counts));
  emit('job', { id: jobId, status: 'published', counts });
  return { ok: true, counts };
}

/** Render a clearly-labelled synthetic road frame (real pixels for the real analyzer). */
function generateTestFrame(meta, actor) {
  const script = `
import cv2, numpy as np, sys
rng = np.random.default_rng()
img = np.full((720,1280,3), 128, np.uint8)
img = np.clip(img.astype(np.int16)+rng.normal(0,14,(720,1280,1)).astype(np.int16),0,255).astype(np.uint8)
cv2.rectangle(img,(0,0),(1280,300),(190,182,172),-1)
for x in range(600,681,40): cv2.rectangle(img,(x,300),(x+18,720),(212,212,212),-1)
n = rng.integers(1,4)
for _ in range(int(n)):
    cx,cy = int(rng.integers(180,1100)), int(rng.integers(420,660))
    ax,ay = int(rng.integers(45,95)), int(rng.integers(30,60))
    cv2.ellipse(img,(cx,cy),(ax,ay),int(rng.integers(-15,15)),0,360,(38,36,40),-1)
    cv2.ellipse(img,(cx,cy),(ax,ay),0,0,360,(72,68,72),5)
cv2.putText(img,'SYNTHETIC TEST FRAME - CityLens pipeline test',(24,40),cv2.FONT_HERSHEY_SIMPLEX,0.9,(30,30,200),2,cv2.LINE_AA)
cv2.imwrite(sys.argv[1],img)
print('ok')
`;
  const tmp = path.join(UPLOAD_DIR, `test_${Date.now()}.jpg`);
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const r = spawnSync('python3', ['-c', script, tmp], { timeout: 30000 });
  if (r.status !== 0 || !fs.existsSync(tmp)) return { ok: false, code: 500, error: 'Test-frame generator failed: ' + (r.stderr || '').toString().slice(-200) };
  const buf = fs.readFileSync(tmp); fs.unlinkSync(tmp);
  return createJobFromUpload(buf, { ...meta, filename: `synthetic_test_${Date.now()}.jpg`, sourceKind: 'synthetic_test' }, actor);
}

module.exports = { createJobFromUpload, publish, generateTestFrame, bindEmitter, EVIDENCE_DIR, UPLOAD_DIR };
