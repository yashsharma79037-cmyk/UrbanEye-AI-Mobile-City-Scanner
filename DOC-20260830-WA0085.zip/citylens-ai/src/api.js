'use strict';
/** CityLens API v2 — every endpoint reads/writes real records. See server.js for transport. */
const fs = require('fs');
const path = require('path');
const net = require('net');
const http = require('http');
const https = require('https');
const db = require('./db');
const auth = require('./auth');
const geo = require('./geo');
const { uid } = require('./util');
const ingest = require('./ingest');
const dedupe = require('./dedupe');
const score = require('./score');
const state = require('./state');
const sla = require('./sla');
const verifySvc = require('./verify');
const coverage = require('./coverage');
const ai = require('./ai');
const realtime = require('./realtime');
const { audit, notify, visibleTo } = require('./audit');

const J = (code, json) => ({ code, json });
const ERR = (code, error, extra) => ({ code, json: { error, ...(extra || {}) } });
const setting = (k, fb) => { const r = db.getBy('settings', 'key', k); return r ? r.value : fb; };
const nowIso = () => new Date().toISOString();

/* ---------- small utils ---------- */
function paginate(rows, query, defLimit = 50) {
  const limit = Math.min(parseInt(query.limit) || defLimit, 500);
  const offset = parseInt(query.offset) || 0;
  return { total: rows.length, limit, offset, rows: rows.slice(offset, offset + limit) };
}
function inBounds(row, q) {
  if (!q.minLat) return true;
  return row.latitude >= +q.minLat && row.latitude <= +q.maxLat && row.longitude >= +q.minLng && row.longitude <= +q.maxLng;
}
function csv(rows, cols) {
  const esc = v => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return [cols.join(','), ...rows.map(r => cols.map(c => esc(r[c])).join(','))].join('\n');
}
const userPublic = u => ({ id: u.id, name: u.name, email: u.email, role: u.role, department: u.department, createdAt: u.createdAt });

/* ---------- enrichment helpers ---------- */
function busView(b) {
  const dev = db.getBy('devices', 'busId', b.id);
  const route = b.routeId ? db.get('routes', b.routeId) : null;
  const ageMin = b.lastTelemetryAt ? Math.round((Date.now() - new Date(b.lastTelemetryAt)) / 60000) : null;
  return { ...b, device: dev ? { id: dev.id, deviceCode: dev.deviceCode, connectionStatus: dev.connectionStatus, lastHeartbeatAt: dev.lastHeartbeatAt } : null, routeCode: route ? route.routeCode : null, routeName: route ? route.routeName : null, telemetryAgeMin: ageMin };
}
function ticketView(t) {
  const officer = t.assignedOfficerId ? db.get('users', t.assignedOfficerId) : null;
  const inc = t.incidentId ? db.get('incidents', t.incidentId) : null;
  const remainingMin = t.dueAt && !['RESOLVED', 'CLOSED'].includes(t.status) ? Math.round((new Date(t.dueAt) - Date.now()) / 60000) : null;
  return { ...t, assignedOfficer: officer ? { id: officer.id, name: officer.name, role: officer.role } : null, incidentCode: inc ? inc.code : null, incidentStatus: inc ? inc.status : null, latitude: inc ? inc.latitude : null, longitude: inc ? inc.longitude : null, locationName: inc ? inc.locationName : null, slaRemainingMin: remainingMin };
}
function departmentFor(category) { return (setting('categoryDepartmentMap', {}))[category] || 'Municipal Command Centre'; }

/* =========================================================== ROUTES */
const ROUTES = [];
const on = (method, pattern, opts, handler) => ROUTES.push({ method, pattern, ...(opts || {}), handler });

/* ---------- auth ---------- */
on('POST', '/api/auth/login', { public: true }, (ctx) => {
  const { email, password } = ctx.body || {};
  const user = db.getBy('users', 'email', String(email || '').toLowerCase().trim());
  if (!user || !auth.verifyPassword(password, user.passwordHash)) {
    audit({ email: email || 'unknown' }, 'LOGIN_FAILED', 'user', null, null, ctx.ip);
    return ERR(401, 'Invalid email or password');
  }
  audit(user, 'LOGIN', 'user', user.id, null, ctx.ip);
  return J(200, { token: auth.sign({ sub: user.id, role: user.role }), user: userPublic(user) });
});
const PW_RULES = [
  { re: /.{8,}/, msg: 'at least 8 characters' },
  { re: /[A-Z]/, msg: 'an uppercase letter' },
  { re: /[a-z]/, msg: 'a lowercase letter' },
  { re: /[0-9]/, msg: 'a number' },
];
on('POST', '/api/auth/register', { public: true }, (ctx) => {
  const b = ctx.body || {};
  const name = String(b.name || '').trim().replace(/\s+/g, ' ');
  const email = String(b.email || '').trim().toLowerCase();
  const password = String(b.password || '');
  if (name.length < 2 || name.length > 80) return ERR(400, 'Please enter your full name (2–80 characters).', { field: 'name' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 160) return ERR(400, 'Please enter a valid email address.', { field: 'email' });
  const missing = PW_RULES.filter(r => !r.re.test(password)).map(r => r.msg);
  if (missing.length) return ERR(400, `Password needs ${missing.join(', ')}.`, { field: 'password' });
  if (db.getBy('users', 'email', email)) return ERR(409, 'An account with this email already exists.', { field: 'email' });
  // Public sign-ups always receive the lowest-privilege read-only role.
  // Any client-supplied role is ignored; elevation is admin-only via /api/users.
  const u = db.insert('users', {
    id: uid('USR'), name, email,
    passwordHash: auth.hashPassword(password),
    role: 'analyst', department: null,
    selfRegistered: true, createdAt: nowIso(),
  });
  audit(u, 'ACCOUNT_REGISTERED', 'user', u.id, 'public self-registration (role: analyst)', ctx.ip);
  return J(201, { token: auth.sign({ sub: u.id, role: u.role }), user: userPublic(u) });
});
on('POST', '/api/auth/logout', {}, (ctx) => { audit(ctx.user, 'LOGOUT', 'user', ctx.user.id, null, ctx.ip); return J(200, { ok: true }); });
on('GET', '/api/auth/me', {}, (ctx) => J(200, { user: userPublic(ctx.user), permissions: Object.keys(auth.PERMS).filter(p => auth.can(ctx.user.role, p)) }));

/* ---------- meta / health / public ---------- */
on('GET', '/api/health', { public: true }, () => {
  let dbInfo;
  try {
    const st = fs.statSync(path.join(__dirname, '..', 'data', 'citylens.json'));
    dbInfo = { connected: true, sizeKB: Math.round(st.size / 1024), records: ['users','buses','devices','telemetry','detections','incidents','tickets'].reduce((o,c)=>(o[c]=db.count(c,()=>true),o),{}) };
  } catch { dbInfo = { connected: true, sizeKB: 0, note: 'store initialises on first write' }; }
  return J(200, { server: 'online', ok: true, time: nowIso(), schema: db.meta().version || 2, database: dbInfo });
});
on('GET', '/api/meta', {}, (ctx) => J(200, {
  roles: auth.ROLES, categories: ingest.CATEGORIES,
  departments: db.all('departments').map(d => d.name),
  incidentStates: state.INCIDENT_STATES, ticketStates: state.TICKET_STATES,
  zoneTypes: ['SCHOOL', 'HOSPITAL', 'HIGH_FOOTFALL', 'PEDESTRIAN_PRIORITY', 'CRITICAL_INFRASTRUCTURE'],
  categoryDepartmentMap: setting('categoryDepartmentMap', {}),
  permissions: Object.keys(auth.PERMS).filter(p => auth.can(ctx.user.role, p)),
}));
on('GET', '/api/public/stats', { public: true }, () => J(200, {
  buses: db.count('buses', b => b.active !== false),
  routesKm: Math.round(db.all('routes').reduce((a, r) => a + (r.distanceKm || 0), 0)),
  detections: db.count('detections', () => true),
  incidentsResolved: db.count('incidents', i => i.status === 'CLOSED'),
  openIncidents: db.count('incidents', i => !['CLOSED', 'REJECTED'].includes(i.status)),
}));

/* ---------- dashboard ---------- */
on('GET', '/api/dashboard/stats', {}, (ctx) => {
  const today = new Date(); today.setHours(0, 0, 0, 0); const t0 = today.toISOString();
  const openStates = dedupe.OPEN_STATES;
  const cov = coverage.coverage().totals;
  const rh = coverage.roadHealth();
  return J(200, {
    fleet: {
      buses: db.count('buses', () => true),
      busesActive: db.count('buses', b => b.status === 'active'),
      busesNoTelemetry: db.count('buses', b => b.status !== 'active'),
      devicesOnline: db.count('devices', d => d.connectionStatus === 'online'),
      devices: db.count('devices', () => true),
    },
    ingest: {
      telemetryToday: db.count('telemetry', t => t.receivedAt >= t0),
      telemetryTotal: db.count('telemetry', () => true),
      detectionsToday: db.count('detections', d => d.createdAt >= t0),
      detectionsTotal: db.count('detections', () => true),
    },
    incidents: {
      open: db.count('incidents', i => openStates.includes(i.status)),
      critical: db.count('incidents', i => openStates.includes(i.status) && (i.impactScore || 0) >= 70),
      awaitingVerification: db.count('incidents', i => i.status === 'AWAITING_VERIFICATION'),
      closed: db.count('incidents', i => i.status === 'CLOSED'),
      byStatus: state.INCIDENT_STATES.map(s => ({ status: s, n: db.count('incidents', i => i.status === s) })).filter(x => x.n),
    },
    tickets: {
      open: db.count('tickets', t => !['RESOLVED', 'CLOSED'].includes(t.status)),
      breached: db.count('tickets', t => t.slaStatus === 'BREACHED'),
      atRisk: db.count('tickets', t => t.slaStatus === 'AT_RISK'),
    },
    coverage: cov,
    roadHealthCityAvg: rh.cityAverage,          // null until real incidents/coverage exist
    notificationsUnread: visibleTo(ctx.user).filter(n => !n.isRead).length,
  });
});
on('GET', '/api/dashboard/activity', {}, (ctx) => {
  const det = db.all('detections').slice(-40).map(d => ({ type: 'detection', at: d.createdAt, text: `${d.category} @ ${(d.locationName || d.latitude.toFixed(4) + ',' + d.longitude.toFixed(4))} · ${(d.confidence * 100).toFixed(1)}% (${d.modelName})`, entityId: d.id }));
  const ih = db.all('incident_history').slice(-40).map(h => ({ type: 'incident', at: h.timestamp, text: `${(db.get('incidents', h.incidentId) || {}).code || h.incidentId}: ${h.previousStatus || '∅'} → ${h.newStatus} (${h.changedBy})`, entityId: h.incidentId }));
  const th = db.all('ticket_history').slice(-40).map(h => ({ type: 'ticket', at: h.timestamp, text: `${(db.get('tickets', h.ticketId) || {}).code || h.ticketId}: ${h.previousStatus || '∅'} → ${h.newStatus}`, entityId: h.ticketId }));
  const rows = [...det, ...ih, ...th].sort((a, b) => b.at.localeCompare(a.at)).slice(0, parseInt(ctx.query.limit) || 30);
  return J(200, { rows });
});

/* ---------- fleet: buses & devices ---------- */
on('GET', '/api/buses', {}, (ctx) => {
  let rows = db.all('buses').map(busView);
  if (ctx.query.q) { const q = ctx.query.q.toLowerCase(); rows = rows.filter(b => b.busCode.toLowerCase().includes(q) || (b.registrationNumber || '').toLowerCase().includes(q)); }
  if (ctx.query.status) rows = rows.filter(b => b.status === ctx.query.status);
  return J(200, paginate(rows, ctx.query, 100));
});
on('GET', '/api/buses/:id', {}, (ctx) => {
  const b = db.get('buses', ctx.params.id) || db.getBy('buses', 'busCode', ctx.params.id);
  if (!b) return ERR(404, 'Bus not found');
  const tel = db.find('telemetry', t => t.busId === b.busCode || t.busId === b.id).slice(-100).reverse();
  const dets = db.find('detections', d => d.busId === b.busCode || d.busId === b.id).slice(-50).reverse();
  return J(200, { bus: busView(b), telemetry: tel, detections: dets });
});
on('POST', '/api/buses', { perm: 'fleet.manage' }, (ctx) => {
  const { busCode, registrationNumber, routeId } = ctx.body || {};
  if (!busCode) return ERR(400, 'busCode required');
  if (db.getBy('buses', 'busCode', busCode)) return ERR(409, 'busCode already exists');
  const b = db.insert('buses', { id: uid('BUS'), busCode, registrationNumber: registrationNumber || null, routeId: routeId || null, status: 'no_telemetry', latitude: null, longitude: null, lastTelemetryAt: null, active: true, createdAt: nowIso() });
  audit(ctx.user, 'BUS_CREATED', 'bus', b.id, busCode);
  return J(201, { bus: busView(b) });
});
on('PATCH', '/api/buses/:id', { perm: 'fleet.manage' }, (ctx) => {
  const b = db.get('buses', ctx.params.id); if (!b) return ERR(404, 'Bus not found');
  const allowed = ['registrationNumber', 'routeId', 'active'];
  const patch = {}; for (const k of allowed) if (k in (ctx.body || {})) patch[k] = ctx.body[k];
  const upd = db.update('buses', b.id, patch);
  audit(ctx.user, 'BUS_UPDATED', 'bus', b.id, JSON.stringify(patch));
  return J(200, { bus: busView(upd) });
});
on('GET', '/api/devices', {}, (ctx) => {
  const rows = db.all('devices').map(d => ({ ...d, busCode: d.busId ? (db.get('buses', d.busId) || {}).busCode : null }));
  return J(200, paginate(rows, ctx.query, 100));
});
on('PATCH', '/api/devices/:id', { perm: 'fleet.manage' }, (ctx) => {
  const d = db.get('devices', ctx.params.id); if (!d) return ERR(404, 'Device not found');
  const allowed = ['busId', 'active', 'softwareVersion', 'modelVersion'];
  const patch = {}; for (const k of allowed) if (k in (ctx.body || {})) patch[k] = ctx.body[k];
  const upd = db.update('devices', d.id, patch);
  audit(ctx.user, 'DEVICE_UPDATED', 'device', d.id, JSON.stringify(patch));
  return J(200, { device: upd });
});

/* ---------- routes ---------- */
on('GET', '/api/routes', {}, () => J(200, { rows: db.all('routes') }));
on('GET', '/api/routes/:id', {}, (ctx) => {
  const r = db.get('routes', ctx.params.id) || db.getBy('routes', 'routeCode', ctx.params.id);
  if (!r) return ERR(404, 'Route not found');
  const segs = db.find('road_segments', s => s.routeId === r.id);
  const incs = db.find('incidents', i => geo.nearestSegment(segs, i.latitude, i.longitude, 120));
  return J(200, { route: r, segments: segs, incidents: incs });
});

/* ---------- telemetry ---------- */
on('POST', '/api/telemetry', { perm: 'telemetry.ingest' }, (ctx) => {
  const r = ingest.ingestTelemetry(ctx.body || {}, ctx.body && ctx.body.source === 'browser' ? 'browser' : 'edge');
  return r.ok ? J(200, r) : ERR(r.code || 400, r.error);
});
on('POST', '/api/telemetry/import', { perm: 'telemetry.ingest' }, (ctx) => {
  const { busId, deviceId, routeId, points } = ctx.body || {};
  if (!Array.isArray(points) || !points.length) return ERR(400, 'points[] required — [{latitude, longitude, timestamp?, speed?}]');
  if (points.length > 5000) return ERR(413, 'Max 5000 points per import');
  let ok = 0, failed = 0;
  for (const p of points) {
    const r = ingest.ingestTelemetry({ ...p, busId, deviceId, routeId, eventUuid: p.eventUuid }, 'trace_import');
    r.ok ? ok++ : failed++;
  }
  audit(ctx.user, 'TELEMETRY_IMPORTED', 'bus', busId || deviceId, `${ok} points (${failed} rejected)`);
  return J(200, { imported: ok, rejected: failed, source: 'trace_import' });
});
on('GET', '/api/telemetry', {}, (ctx) => {
  let rows = db.all('telemetry');
  if (ctx.query.busId) rows = rows.filter(t => t.busId === ctx.query.busId);
  if (ctx.query.since) rows = rows.filter(t => t.timestamp >= ctx.query.since);
  rows = rows.slice(-(parseInt(ctx.query.limit) || 200)).reverse();
  return J(200, { rows, note: rows.length ? undefined : 'No telemetry yet — open the Edge Client, or import a route trace.' });
});

/* ---------- detections + edge ingest + review ---------- */
on('GET', '/api/detections', {}, (ctx) => {
  let rows = db.all('detections');
  const q = ctx.query;
  if (q.category) rows = rows.filter(d => d.category === q.category);
  if (q.validationState) rows = rows.filter(d => d.validationState === q.validationState);
  if (q.jobId) rows = rows.filter(d => d.jobId === q.jobId);
  if (q.incidentId) rows = rows.filter(d => d.incidentId === q.incidentId);
  if (q.since) rows = rows.filter(d => d.createdAt >= q.since);
  rows = rows.filter(d => inBounds(d, q));
  rows = rows.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return J(200, paginate(rows, ctx.query));
});
on('GET', '/api/detections/:id', {}, (ctx) => {
  const d = db.get('detections', ctx.params.id); if (!d) return ERR(404, 'Detection not found');
  return J(200, {
    detection: d,
    incident: d.incidentId ? db.get('incidents', d.incidentId) : null,
    job: d.jobId ? db.get('ai_jobs', d.jobId) : null,
    feedback: db.find('human_feedback', f => f.detectionId === d.id),
  });
});
on('POST', '/api/detections/ingest', { perm: 'analysis.run' }, (ctx) => {
  const r = ingest.ingestDetection(ctx.body || {}, ctx.body && ctx.body.sourceType === 'edge' ? 'edge' : 'external', ctx.user);
  return r.ok ? J(r.idempotent ? 200 : 201, r) : ERR(r.code || 400, r.error);
});
on('POST', '/api/detections/:id/review', { perm: 'detection.review' }, (ctx) => {
  const d = db.get('detections', ctx.params.id); if (!d) return ERR(404, 'Detection not found');
  const { decision, comment, correctedCategory } = ctx.body || {};
  const DECISIONS = ['CORRECT', 'FALSE_POSITIVE', 'NEEDS_REVIEW', 'WRONG_CATEGORY'];
  if (!DECISIONS.includes(decision)) return ERR(400, `decision must be one of ${DECISIONS.join(', ')}`);
  if (decision === 'WRONG_CATEGORY' && !ingest.CATEGORIES.includes(correctedCategory)) return ERR(400, 'correctedCategory required for WRONG_CATEGORY');
  const fb = db.insert('human_feedback', { id: uid('HFB'), detectionId: d.id, incidentId: d.incidentId, decision, correctedCategory: correctedCategory || null, comment: comment || null, reviewer: ctx.user.email, reviewerId: ctx.user.id, timestamp: nowIso() });
  db.update('detections', d.id, { validationState: decision });
  audit(ctx.user, 'DETECTION_REVIEWED', 'detection', d.id, decision);
  // sole-observation false positive ⇒ reject the incident through the state machine
  if (decision === 'FALSE_POSITIVE' && d.incidentId) {
    const obs = db.find('observations', o => o.incidentId === d.incidentId);
    const inc = db.get('incidents', d.incidentId);
    if (obs.length <= 1 && inc && ['DETECTED', 'UNDER_REVIEW'].includes(inc.status)) {
      state.transitionIncident(inc.id, 'REJECTED', ctx.user, 'Reviewer marked the only observation as a false positive.');
    }
  }
  return J(201, { feedback: fb, detection: db.get('detections', d.id) });
});

/* ---------- incidents ---------- */
on('GET', '/api/incidents', {}, (ctx) => {
  let rows = db.all('incidents');
  const q = ctx.query;
  if (q.status) rows = rows.filter(i => i.status === q.status);
  if (q.open === '1') rows = rows.filter(i => dedupe.OPEN_STATES.includes(i.status));
  if (q.category) rows = rows.filter(i => i.category === q.category);
  if (q.department) rows = rows.filter(i => i.department === q.department);
  if (q.minImpact) rows = rows.filter(i => (i.impactScore || 0) >= +q.minImpact);
  rows = rows.filter(i => inBounds(i, q));
  rows = rows.sort((a, b) => (b.impactScore || 0) - (a.impactScore || 0) || b.lastSeenAt.localeCompare(a.lastSeenAt));
  return J(200, paginate(rows, ctx.query));
});
on('GET', '/api/incidents/:id', {}, (ctx) => {
  const i = db.get('incidents', ctx.params.id) || db.getBy('incidents', 'code', ctx.params.id);
  if (!i) return ERR(404, 'Incident not found');
  const obs = db.find('observations', o => o.incidentId === i.id).map(o => ({ ...o, detection: db.get('detections', o.detectionId) }));
  return J(200, {
    incident: i,
    observations: obs,
    history: db.find('incident_history', h => h.incidentId === i.id),
    ticket: i.ticketId ? ticketView(db.get('tickets', i.ticketId)) : null,
    verification: i.status === 'AWAITING_VERIFICATION' || i.verifiedAt ? verifySvc.progress(i.id) : null,
    zones: geo.within(db.find('safety_zones', z => z.active), i.latitude, i.longitude, 1200).filter(z => z.distanceM <= z.radiusM + 200),
  });
});
on('POST', '/api/incidents/:id/transition', {}, (ctx) => {
  const { to, note } = ctx.body || {};
  const i = db.get('incidents', ctx.params.id); if (!i) return ERR(404, 'Incident not found');
  const meta = {};
  if (to === 'CONFIRMED' && !i.department) meta.department = departmentFor(i.category);
  if (to === 'REPAIR_SUBMITTED') meta.repairSubmittedAt = nowIso();
  const r = state.transitionIncident(i.id, to, ctx.user, note, meta);
  if (!r.ok) return ERR(r.code, r.error);
  realtime.broadcast('incident', { id: i.id, code: i.code, status: to });
  return J(200, { incident: r.incident });
});

/* ---------- tickets ---------- */
function nextTicketCode() { return `TKT-${1000 + db.count('tickets', () => true) + 1}`; }
on('POST', '/api/incidents/:id/ticket', { perm: 'incident.assign' }, (ctx) => {
  const i = db.get('incidents', ctx.params.id); if (!i) return ERR(404, 'Incident not found');
  if (i.ticketId) return ERR(409, 'Incident already has a ticket', { ticketId: i.ticketId });
  if (!['CONFIRMED', 'REOPENED'].includes(i.status)) return ERR(409, `Ticket requires a CONFIRMED incident (currently ${i.status})`);
  const department = (ctx.body && ctx.body.department) || i.department || departmentFor(i.category);
  const officerId = ctx.body && ctx.body.assignedOfficerId;
  const officer = officerId ? db.get('users', officerId) : null;
  if (officerId && !officer) return ERR(400, 'assignedOfficerId does not exist');
  const t = db.insert('tickets', {
    id: uid('TKT'), code: nextTicketCode(), incidentId: i.id, incidentCode: i.code,
    category: i.category, department, priority: (i.impactScore || 0) >= 70 ? 'CRITICAL' : (i.impactScore || 0) >= 45 ? 'HIGH' : 'NORMAL',
    impactScore: i.impactScore, status: 'OPEN',
    assignedOfficerId: officer ? officer.id : null, notes: (ctx.body && ctx.body.note) || null,
    createdBy: ctx.user.email, createdAt: nowIso(), updatedAt: nowIso(),
  });
  db.insert('ticket_history', { id: uid('TH'), ticketId: t.id, previousStatus: null, newStatus: 'OPEN', changedBy: ctx.user.email, role: ctx.user.role, note: `Created from ${i.code}`, timestamp: t.createdAt });
  sla.applySla(t);
  state.transitionIncident(i.id, 'ASSIGNED', ctx.user, `Ticket ${t.code} → ${department}`, { ticketId: t.id, department });
  if (officer) {
    state.transitionTicket(t.id, 'ASSIGNED', ctx.user, `Assigned to ${officer.name}`);
    notify({ kind: 'TICKET_ASSIGNED', severity: 'medium', title: `Ticket assigned — ${t.code}`, message: `${i.code} · ${i.category} · impact ${i.impactScore}`, entityType: 'ticket', entityId: t.id, forUserId: officer.id });
  } else {
    notify({ kind: 'TICKET_CREATED', severity: 'medium', title: `Ticket created — ${t.code}`, message: `${i.code} routed to ${department}`, entityType: 'ticket', entityId: t.id, department });
  }
  audit(ctx.user, 'TICKET_CREATED', 'ticket', t.id, `${i.code} → ${department}`);
  realtime.broadcast('ticket', { id: t.id, code: t.code, status: db.get('tickets', t.id).status });
  return J(201, { ticket: ticketView(db.get('tickets', t.id)) });
});
on('GET', '/api/tickets', {}, (ctx) => {
  let rows = db.all('tickets');
  const q = ctx.query;
  if (ctx.user.role === 'field') rows = rows.filter(t => t.assignedOfficerId === ctx.user.id);
  if (ctx.user.role === 'officer' && q.department !== 'all') rows = rows.filter(t => t.department === ctx.user.department);
  if (q.status) rows = rows.filter(t => t.status === q.status);
  if (q.slaStatus) rows = rows.filter(t => t.slaStatus === q.slaStatus);
  if (q.open === '1') rows = rows.filter(t => !['RESOLVED', 'CLOSED'].includes(t.status));
  rows = rows.sort((a, b) => (a.dueAt || 'z').localeCompare(b.dueAt || 'z'));
  return J(200, paginate(rows.map(ticketView), ctx.query));
});
on('GET', '/api/tickets/:id', {}, (ctx) => {
  const t = db.get('tickets', ctx.params.id) || db.getBy('tickets', 'code', ctx.params.id);
  if (!t) return ERR(404, 'Ticket not found');
  if (ctx.user.role === 'field' && t.assignedOfficerId !== ctx.user.id) return ERR(403, 'Not your ticket');
  return J(200, {
    ticket: ticketView(t),
    history: db.find('ticket_history', h => h.ticketId === t.id),
    incident: t.incidentId ? db.get('incidents', t.incidentId) : null,
    repairEvidence: db.find('repair_evidence', e => e.ticketId === t.id),
    escalations: db.find('escalations', e => e.ticketId === t.id),
  });
});
on('POST', '/api/tickets/:id/assign', { perm: 'ticket.manage' }, (ctx) => {
  const t = db.get('tickets', ctx.params.id); if (!t) return ERR(404, 'Ticket not found');
  const u = db.get('users', (ctx.body || {}).officerId);
  if (!u || !['field', 'officer'].includes(u.role)) return ERR(400, 'officerId must be a field worker or officer');
  db.update('tickets', t.id, { assignedOfficerId: u.id });
  const r = t.status === 'OPEN' ? state.transitionTicket(t.id, 'ASSIGNED', ctx.user, `Assigned to ${u.name}`) : { ok: true };
  if (!r.ok) return ERR(r.code, r.error);
  notify({ kind: 'TICKET_ASSIGNED', severity: 'medium', title: `Ticket assigned — ${t.code}`, message: `${t.incidentCode} · ${t.category}`, entityType: 'ticket', entityId: t.id, forUserId: u.id });
  audit(ctx.user, 'TICKET_ASSIGNED', 'ticket', t.id, u.email);
  return J(200, { ticket: ticketView(db.get('tickets', t.id)) });
});
on('POST', '/api/tickets/:id/transition', {}, (ctx) => {
  const { to, note } = ctx.body || {};
  const t = db.get('tickets', ctx.params.id); if (!t) return ERR(404, 'Ticket not found');
  if (to === 'REPAIR_SUBMITTED') {
    const after = db.count('repair_evidence', e => e.ticketId === t.id && e.kind === 'after');
    if (!after) return ERR(409, 'Upload at least one AFTER photo before submitting the repair');
  }
  const r = state.transitionTicket(t.id, to, ctx.user, note);
  if (!r.ok) return ERR(r.code, r.error);
  if (to === 'REPAIR_SUBMITTED') {
    state.transitionTicket(t.id, 'AWAITING_VERIFICATION', 'system', 'Queued for AI re-observation.');
    if (t.incidentId) {
      const inc = db.get('incidents', t.incidentId);
      if (inc && inc.status === 'IN_PROGRESS') state.transitionIncident(inc.id, 'REPAIR_SUBMITTED', ctx.user, note, { repairSubmittedAt: nowIso() });
      state.transitionIncident(t.incidentId, 'AWAITING_VERIFICATION', 'system', 'Repair submitted — awaiting post-repair scans.');
      notify({ kind: 'REPAIR_SUBMITTED', severity: 'medium', title: `Repair submitted — ${t.code}`, message: 'Verification requires clear post-repair scans from independent devices.', entityType: 'ticket', entityId: t.id, department: t.department });
    }
  }
  if (['ACKNOWLEDGED', 'WORK_STARTED'].includes(to) && t.incidentId) {
    const inc = db.get('incidents', t.incidentId);
    if (inc && inc.status === 'ASSIGNED' && to === 'WORK_STARTED') state.transitionIncident(inc.id, 'IN_PROGRESS', ctx.user, 'Field work started.');
  }
  realtime.broadcast('ticket', { id: t.id, code: t.code, status: to });
  return J(200, { ticket: ticketView(db.get('tickets', t.id)) });
});
on('POST', '/api/tickets/:id/evidence', { perm: 'repair.submit', raw: true }, (ctx) => {
  const t = db.get('tickets', ctx.params.id); if (!t) return ERR(404, 'Ticket not found');
  if (ctx.user.role === 'field' && t.assignedOfficerId !== ctx.user.id) return ERR(403, 'Not your ticket');
  const kind = (ctx.req.headers['x-kind'] || '').toLowerCase();
  if (!['before', 'after'].includes(kind)) return ERR(400, 'x-kind header must be before|after');
  if (!ctx.raw || !ctx.raw.length) return ERR(400, 'Empty upload');
  if (ctx.raw.length > 15 * 1024 * 1024) return ERR(413, 'Photo exceeds 15 MB');
  const magic = ctx.raw.slice(0, 3).toString('hex');
  if (!['ffd8ff', '89504e'].includes(magic)) return ERR(415, 'Only JPEG/PNG photos accepted');
  const dir = path.join(__dirname, '..', 'data', 'repairs', t.id);
  fs.mkdirSync(dir, { recursive: true });
  const fname = `${kind}_${Date.now()}${magic === '89504e' ? '.png' : '.jpg'}`;
  fs.writeFileSync(path.join(dir, fname), ctx.raw);
  const row = db.insert('repair_evidence', { id: uid('REV'), ticketId: t.id, incidentId: t.incidentId, kind, file: `/api/repairs/${t.id}/${fname}`, note: ctx.req.headers['x-note'] || null, uploadedBy: ctx.user.email, sizeBytes: ctx.raw.length, timestamp: nowIso() });
  audit(ctx.user, 'REPAIR_EVIDENCE_UPLOADED', 'ticket', t.id, `${kind} ${fname}`);
  return J(201, { evidence: row });
});

/* ---------- verification / sla / escalations ---------- */
on('GET', '/api/incidents/:id/verification', {}, (ctx) => {
  const i = db.get('incidents', ctx.params.id); if (!i) return ERR(404, 'Incident not found');
  return J(200, verifySvc.progress(i.id));
});
on('GET', '/api/sla', {}, () => J(200, { rules: db.all('sla_rules') }));
on('POST', '/api/sla', { perm: 'sla.manage' }, (ctx) => {
  const { name, category, minImpact, hours } = ctx.body || {};
  if (!name || !category || !Number.isFinite(hours)) return ERR(400, 'name, category, hours required');
  const r = db.insert('sla_rules', { id: uid('SLA'), name, category, minImpact: minImpact || 0, hours, active: true, createdAt: nowIso() });
  audit(ctx.user, 'SLA_RULE_CREATED', 'sla_rule', r.id, `${category} ≥${minImpact || 0} → ${hours} h`);
  return J(201, { rule: r });
});
on('PATCH', '/api/sla/:id', { perm: 'sla.manage' }, (ctx) => {
  const r = db.get('sla_rules', ctx.params.id); if (!r) return ERR(404, 'Rule not found');
  const patch = {}; for (const k of ['name', 'minImpact', 'hours', 'active']) if (k in (ctx.body || {})) patch[k] = ctx.body[k];
  audit(ctx.user, 'SLA_RULE_UPDATED', 'sla_rule', r.id, JSON.stringify(patch));
  return J(200, { rule: db.update('sla_rules', r.id, patch) });
});
on('POST', '/api/sla/evaluate', { perm: 'sla.manage' }, () => J(200, { updated: sla.evaluateAll(), note: 'Evaluator also runs automatically every 60 s.' }));
on('GET', '/api/sla/escalations', {}, (ctx) => J(200, paginate(db.all('escalations').slice().reverse(), ctx.query)));

/* ---------- notifications ---------- */
on('GET', '/api/notifications', {}, (ctx) => {
  let rows = visibleTo(ctx.user).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  if (ctx.query.unread === '1') rows = rows.filter(n => !n.isRead);
  if (ctx.query.kind) rows = rows.filter(n => n.kind === ctx.query.kind);
  return J(200, { ...paginate(rows, ctx.query), unread: visibleTo(ctx.user).filter(n => !n.isRead).length });
});
on('PATCH', '/api/notifications/:id/read', {}, (ctx) => { const n = db.get('notifications', ctx.params.id); if (!n) return ERR(404, 'Not found'); return J(200, { notification: db.update('notifications', n.id, { isRead: true }) }); });
on('POST', '/api/notifications/read-all', {}, (ctx) => { let n = 0; for (const x of visibleTo(ctx.user)) if (!x.isRead) { db.update('notifications', x.id, { isRead: true }); n++; } return J(200, { marked: n }); });
on('PATCH', '/api/notifications/:id/archive', {}, (ctx) => { const n = db.get('notifications', ctx.params.id); if (!n) return ERR(404, 'Not found'); return J(200, { notification: db.update('notifications', n.id, { archived: true }) }); });

/* ---------- safety zones ---------- */
on('GET', '/api/zones', {}, () => J(200, { rows: db.all('safety_zones') }));
on('POST', '/api/zones', { perm: 'zones.manage' }, (ctx) => {
  const b = ctx.body || {};
  if (!b.name || !Number.isFinite(b.latitude) || !Number.isFinite(b.longitude) || !Number.isFinite(b.radiusM)) return ERR(400, 'name, latitude, longitude, radiusM required');
  const z = db.insert('safety_zones', { id: uid('ZON'), name: b.name, latitude: b.latitude, longitude: b.longitude, radiusM: b.radiusM, zoneType: b.zoneType || 'HIGH_FOOTFALL', priorityWeight: b.priorityWeight || 2, active: true, source: 'admin', createdAt: nowIso() });
  audit(ctx.user, 'ZONE_CREATED', 'safety_zone', z.id, z.name);
  return J(201, { zone: z });
});
on('PATCH', '/api/zones/:id', { perm: 'zones.manage' }, (ctx) => {
  const z = db.get('safety_zones', ctx.params.id); if (!z) return ERR(404, 'Zone not found');
  const patch = {}; for (const k of ['name', 'radiusM', 'zoneType', 'priorityWeight', 'active']) if (k in (ctx.body || {})) patch[k] = ctx.body[k];
  audit(ctx.user, 'ZONE_UPDATED', 'safety_zone', z.id, JSON.stringify(patch));
  return J(200, { zone: db.update('safety_zones', z.id, patch) });
});
on('DELETE', '/api/zones/:id', { perm: 'zones.manage' }, (ctx) => {
  const z = db.get('safety_zones', ctx.params.id); if (!z) return ERR(404, 'Zone not found');
  db.remove('safety_zones', z.id);
  audit(ctx.user, 'ZONE_DELETED', 'safety_zone', z.id, z.name);
  return J(200, { ok: true });
});

/* ---------- coverage / analytics ---------- */
on('GET', '/api/coverage', {}, () => J(200, coverage.coverage()));
on('GET', '/api/analytics/road-health', {}, () => J(200, coverage.roadHealth()));
on('GET', '/api/analytics/traffic', {}, (ctx) => J(200, coverage.traffic(parseInt(ctx.query.hours) || 3)));
on('GET', '/api/analytics/overview', {}, () => {
  const days = [...Array(7)].map((_, k) => { const d = new Date(Date.now() - (6 - k) * 86400e3); return d.toISOString().slice(0, 10); });
  const byDay = days.map(day => ({ day, detections: db.count('detections', x => x.createdAt.slice(0, 10) === day), incidents: db.count('incidents', x => x.createdAt.slice(0, 10) === day) }));
  const byCategory = {}; for (const d of db.all('detections')) byCategory[d.category] = (byCategory[d.category] || 0) + 1;
  const fb = db.all('human_feedback');
  const reviewed = fb.length;
  const confirmed = fb.filter(f => f.decision === 'CORRECT').length;
  const falsePos = fb.filter(f => f.decision === 'FALSE_POSITIVE').length;
  const resolved = db.find('tickets', t => t.resolvedAt);
  const avgResolutionH = resolved.length ? Math.round(resolved.reduce((a, t) => a + (new Date(t.resolvedAt) - new Date(t.createdAt)) / 3600e3, 0) / resolved.length * 10) / 10 : null;
  const slaDone = db.find('tickets', t => ['RESOLVED_WITHIN_SLA', 'RESOLVED_AFTER_SLA'].includes(t.slaStatus));
  return J(200, {
    byDay, byCategory,
    totals: {
      detections: db.count('detections', () => true),
      incidents: db.count('incidents', () => true),
      mergedObservations: Math.max(0, db.count('observations', () => true) - db.count('incidents', () => true)),
      openCritical: db.count('incidents', i => dedupe.OPEN_STATES.includes(i.status) && (i.impactScore || 0) >= 70),
      verifiedRepairs: db.count('incidents', i => !!i.verifiedAt),
    },
    review: { reviewed, confirmationRate: reviewed ? +(confirmed / reviewed * 100).toFixed(1) : null, falsePositiveRate: reviewed ? +(falsePos / reviewed * 100).toFixed(1) : null },
    sla: { compliance: slaDone.length ? +(slaDone.filter(t => t.slaStatus === 'RESOLVED_WITHIN_SLA').length / slaDone.length * 100).toFixed(1) : null, breachedOpen: db.count('tickets', t => t.slaStatus === 'BREACHED'), avgResolutionH },
    note: db.count('detections', () => true) ? undefined : 'No detections yet — run an analysis or connect the edge client. Analytics populate from real activity only.',
  });
});

/* ---------- AI models & jobs ---------- */
on('GET', '/api/models', {}, () => {
  const rows = db.all('ai_models').map(m => {
    const dets = db.find('detections', d => d.modelName === m.key);
    const fb = db.find('human_feedback', f => dets.some(d => d.id === f.detectionId));
    const inf = dets.filter(d => Number.isFinite(d.inferenceMs));
    return {
      ...m,
      inferenceCount: dets.length,
      avgConfidence: dets.length ? +(dets.reduce((a, d) => a + d.confidence, 0) / dets.length).toFixed(3) : null,
      avgInferenceMs: inf.length ? +(inf.reduce((a, d) => a + d.inferenceMs, 0) / inf.length).toFixed(1) : null,
      reviewed: fb.length,
      confirmationRate: fb.length ? +(fb.filter(f => f.decision === 'CORRECT').length / fb.length * 100).toFixed(1) : null,
      accuracyNote: 'No labelled ground-truth set — accuracy is not claimed. Confirmation rate reflects human review of live detections.',
    };
  });
  return J(200, { rows });
});
on('GET', '/api/ai/jobs', {}, (ctx) => {
  let rows = db.all('ai_jobs').slice().reverse();
  if (ctx.query.mine === '1') rows = rows.filter(j => j.requestedBy === ctx.user.email);
  return J(200, paginate(rows.map(j => ({ ...j, filePath: undefined })), ctx.query, 30));
});
on('GET', '/api/ai/jobs/:id', {}, (ctx) => {
  const j = db.get('ai_jobs', ctx.params.id); if (!j) return ERR(404, 'Job not found');
  return J(200, { job: { ...j, filePath: undefined } });
});
on('POST', '/api/ai/analyze', { perm: 'analysis.run', raw: true }, (ctx) => {
  if (ctx.body && ctx.body.testFrame) {
    const r = ai.generateTestFrame({ latitude: ctx.body.latitude, longitude: ctx.body.longitude, routeCode: ctx.body.routeCode, deviceId: ctx.body.deviceId, busId: ctx.body.busId, engine: ctx.body.engine }, ctx.user);
    return r.ok ? J(201, { job: { ...r.job, filePath: undefined } }) : ERR(r.code, r.error);
  }
  const h = ctx.req.headers;
  const meta = {
    filename: decodeURIComponent(h['x-filename'] || 'upload.bin'),
    latitude: parseFloat(h['x-lat']), longitude: parseFloat(h['x-lng']),
    routeCode: h['x-route'] || null, deviceId: h['x-device'] || null, busId: h['x-bus'] || null,
    engine: h['x-engine'] || 'classical-cv-v1',
  };
  const r = ai.createJobFromUpload(ctx.raw, meta, ctx.user);
  return r.ok ? J(201, { job: { ...r.job, filePath: undefined } }) : ERR(r.code, r.error);
});
on('POST', '/api/ai/jobs/:id/publish', { perm: 'analysis.run' }, (ctx) => {
  const r = ai.publish(ctx.params.id, ctx.user);
  return r.ok ? J(200, r) : ERR(r.code, r.error);
});

/* ---------- reports (CSV from real queries) ---------- */
on('GET', '/api/reports', {}, (ctx) => {
  const q = ctx.query; const type = q.type;
  const inRange = ts => (!q.from || ts >= q.from) && (!q.to || ts <= q.to + 'T23:59:59');
  let rows = [], cols = [];
  if (type === 'detections') {
    rows = db.find('detections', d => inRange(d.createdAt) && (!q.category || d.category === q.category))
      .map(d => ({ id: d.id, time: d.timestamp, category: d.category, confidence: d.confidence, latitude: d.latitude, longitude: d.longitude, location: d.locationName, model: d.modelName, source: d.sourceType, incidentId: d.incidentId, validation: d.validationState }));
    cols = ['id', 'time', 'category', 'confidence', 'latitude', 'longitude', 'location', 'model', 'source', 'incidentId', 'validation'];
  } else if (type === 'incidents') {
    rows = db.find('incidents', i => inRange(i.createdAt) && (!q.status || i.status === q.status))
      .map(i => ({ code: i.code, category: i.category, status: i.status, impact: i.impactScore, observations: i.observationCount, devices: i.uniqueDeviceCount, aggConfidence: i.aggConfidence, firstSeen: i.firstSeenAt, lastSeen: i.lastSeenAt, location: i.locationName, department: i.department, ticket: i.ticketId }));
    cols = ['code', 'category', 'status', 'impact', 'observations', 'devices', 'aggConfidence', 'firstSeen', 'lastSeen', 'location', 'department', 'ticket'];
  } else if (type === 'merges') {
    rows = db.find('incidents', i => i.observationCount > 1).map(i => ({ code: i.code, category: i.category, observations: i.observationCount, uniqueDevices: i.uniqueDeviceCount, uniqueBuses: i.uniqueBusCount, aggConfidence: i.aggConfidence, method: i.aggMethod, firstSeen: i.firstSeenAt, lastSeen: i.lastSeenAt }));
    cols = ['code', 'category', 'observations', 'uniqueDevices', 'uniqueBuses', 'aggConfidence', 'method', 'firstSeen', 'lastSeen'];
  } else if (type === 'tickets_sla') {
    rows = db.find('tickets', t => inRange(t.createdAt) && (!q.department || t.department === q.department))
      .map(t => ({ code: t.code, incident: t.incidentCode, department: t.department, priority: t.priority, status: t.status, sla: t.slaRuleName, dueAt: t.dueAt, slaStatus: t.slaStatus, escalationLevel: t.escalationLevel, created: t.createdAt, resolved: t.resolvedAt }));
    cols = ['code', 'incident', 'department', 'priority', 'status', 'sla', 'dueAt', 'slaStatus', 'escalationLevel', 'created', 'resolved'];
  } else if (type === 'verification') {
    rows = db.find('verifications', v => inRange(v.timestamp)).map(v => ({ id: v.id, incident: (db.get('incidents', v.incidentId) || {}).code, result: v.result, device: v.deviceId, bus: v.busId, confidence: v.confidence, threshold: v.threshold, time: v.timestamp }));
    cols = ['id', 'incident', 'result', 'device', 'bus', 'confidence', 'threshold', 'time'];
  } else if (type === 'department_performance') {
    const deps = db.all('departments').map(d => d.name);
    rows = deps.map(dep => {
      const ts = db.find('tickets', t => t.department === dep);
      const done = ts.filter(t => t.resolvedAt);
      return { department: dep, tickets: ts.length, open: ts.filter(t => !['RESOLVED', 'CLOSED'].includes(t.status)).length, breached: ts.filter(t => t.slaStatus === 'BREACHED').length, resolved: done.length, avgResolutionH: done.length ? +(done.reduce((a, t) => a + (new Date(t.resolvedAt) - new Date(t.createdAt)) / 3600e3, 0) / done.length).toFixed(1) : '' };
    });
    cols = ['department', 'tickets', 'open', 'breached', 'resolved', 'avgResolutionH'];
  } else if (type === 'coverage') {
    rows = coverage.coverage().segments.map(s => ({ segment: s.id, road: s.roadName, route: s.routeCode, lengthM: s.lengthM, status: s.status, lastScannedAt: s.lastScannedAt, observations: s.observationCount, lastBus: s.lastBus }));
    cols = ['segment', 'road', 'route', 'lengthM', 'status', 'lastScannedAt', 'observations', 'lastBus'];
  } else return ERR(400, 'type must be one of detections|incidents|merges|tickets_sla|verification|department_performance|coverage');

  audit(ctx.user, 'REPORT_GENERATED', 'report', type, `${rows.length} rows`);
  if (ctx.query.format === 'csv') return { code: 200, headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="citylens_${type}_${Date.now()}.csv"` }, body: csv(rows, cols) };
  return J(200, { type, rows, columns: cols, note: 'PDF export is not implemented in this build — CSV only (stated honestly rather than faked).' });
});

/* ---------- search ---------- */
on('GET', '/api/search', {}, (ctx) => {
  const q = String(ctx.query.q || '').trim().toLowerCase();
  if (q.length < 2) return ERR(400, 'q must be at least 2 characters');
  const grab = (rows, map) => rows.slice(0, 8).map(map);
  return J(200, {
    incidents: grab(db.find('incidents', i => i.code.toLowerCase().includes(q) || (i.locationName || '').toLowerCase().includes(q) || i.category.includes(q)), i => ({ id: i.id, code: i.code, category: i.category, status: i.status, impact: i.impactScore })),
    tickets: grab(db.find('tickets', t => t.code.toLowerCase().includes(q) || (t.department || '').toLowerCase().includes(q)), t => ({ id: t.id, code: t.code, status: t.status, department: t.department })),
    buses: grab(db.find('buses', b => b.busCode.toLowerCase().includes(q) || (b.registrationNumber || '').toLowerCase().includes(q)), b => ({ id: b.id, busCode: b.busCode, status: b.status })),
    devices: grab(db.find('devices', d => d.deviceCode.toLowerCase().includes(q)), d => ({ id: d.id, deviceCode: d.deviceCode, connectionStatus: d.connectionStatus })),
    routes: grab(db.find('routes', r => r.routeCode.toLowerCase().includes(q) || r.routeName.toLowerCase().includes(q)), r => ({ id: r.id, routeCode: r.routeCode, routeName: r.routeName })),
    detections: grab(db.find('detections', d => d.id.toLowerCase().includes(q)), d => ({ id: d.id, category: d.category, confidence: d.confidence })),
  });
});

/* ---------- users ---------- */
on('GET', '/api/users', {}, (ctx) => {
  // officers need the list to assign field workers; analysts get read-only names
  return J(200, { rows: db.all('users').map(userPublic) });
});
on('POST', '/api/users', { perm: 'users.manage' }, (ctx) => {
  const { name, email, password, role, department } = ctx.body || {};
  if (!name || !email || !password || !auth.ROLES[role]) return ERR(400, 'name, email, password, valid role required');
  if (db.getBy('users', 'email', email.toLowerCase())) return ERR(409, 'Email already registered');
  const u = db.insert('users', { id: uid('USR'), name, email: email.toLowerCase(), passwordHash: auth.hashPassword(password), role, department: department || null, createdAt: nowIso() });
  audit(ctx.user, 'USER_CREATED', 'user', u.id, `${email} (${role})`);
  return J(201, { user: userPublic(u) });
});
on('PATCH', '/api/users/:id', { perm: 'users.manage' }, (ctx) => {
  const u = db.get('users', ctx.params.id); if (!u) return ERR(404, 'User not found');
  const patch = {};
  for (const k of ['name', 'role', 'department']) if (k in (ctx.body || {})) patch[k] = ctx.body[k];
  if (patch.role && !auth.ROLES[patch.role]) return ERR(400, 'Invalid role');
  if (ctx.body && ctx.body.password) patch.passwordHash = auth.hashPassword(ctx.body.password);
  const upd = db.update('users', u.id, patch);
  audit(ctx.user, 'ROLE_UPDATED', 'user', u.id, JSON.stringify({ ...patch, passwordHash: patch.passwordHash ? '(changed)' : undefined }));
  return J(200, { user: userPublic(upd) });
});

/* ---------- settings ---------- */
on('GET', '/api/settings', {}, () => J(200, { rows: db.all('settings') }));
on('PATCH', '/api/settings/:key', { perm: 'settings.manage' }, (ctx) => {
  const WHITELIST = ['city', 'categoryDepartmentMap', 'mergeRadii', 'scoringWeights', 'verification'];
  if (!WHITELIST.includes(ctx.params.key)) return ERR(400, `key must be one of ${WHITELIST.join(', ')}`);
  let row = db.getBy('settings', 'key', ctx.params.key);
  const value = (ctx.body || {}).value;
  if (value === undefined) return ERR(400, 'value required');
  row = row ? db.update('settings', row.id, { value, updatedAt: nowIso() }) : db.insert('settings', { id: uid('SET'), key: ctx.params.key, value, updatedAt: nowIso() });
  audit(ctx.user, 'SYSTEM_SETTING_UPDATED', 'setting', ctx.params.key, JSON.stringify(value).slice(0, 300));
  return J(200, { setting: row });
});

/* ---------- integrations (truthful states + real connection tests) ---------- */
function deriveIntegrationStatus(it) {
  if (!it.enabled) return it.config && Object.keys(it.config).length ? 'disabled' : 'not_configured';
  if (!it.config || !Object.keys(it.config).length) return 'not_configured';
  if (!it.lastTestResult) return 'configured_untested';
  return it.lastTestResult.ok ? 'connected' : (it.lastTestResult.kind || 'connection_failed');
}
on('GET', '/api/integrations', {}, () => J(200, { rows: db.all('integrations').map(it => ({ ...it, config: Object.keys(it.config || {}).length ? Object.fromEntries(Object.entries(it.config).map(([k, v]) => [k, /key|secret|pass|token/i.test(k) ? '••••' : v])) : {}, status: deriveIntegrationStatus(it) })) }));
on('PATCH', '/api/integrations/:id', { perm: 'integrations.manage' }, (ctx) => {
  const it = db.get('integrations', ctx.params.id); if (!it) return ERR(404, 'Integration not found');
  const patch = {};
  if ('enabled' in (ctx.body || {})) patch.enabled = !!ctx.body.enabled;
  if (ctx.body && typeof ctx.body.config === 'object') patch.config = { ...it.config, ...ctx.body.config };
  const upd = db.update('integrations', it.id, patch);
  audit(ctx.user, 'INTEGRATION_CHANGED', 'integration', it.id, JSON.stringify({ enabled: upd.enabled, keys: Object.keys(upd.config || {}) }));
  return J(200, { integration: { ...upd, status: deriveIntegrationStatus(upd) } });
});
on('POST', '/api/integrations/:id/test', { perm: 'integrations.manage' }, async (ctx) => {
  const it = db.get('integrations', ctx.params.id); if (!it) return ERR(404, 'Integration not found');
  const cfgv = it.config || {};
  const record = (result) => { db.update('integrations', it.id, { lastTestAt: nowIso(), lastTestResult: result }); audit(ctx.user, 'INTEGRATION_TESTED', 'integration', it.id, JSON.stringify(result)); return J(200, { result, status: deriveIntegrationStatus(db.get('integrations', it.id)) }); };
  const url = cfgv.url || cfgv.endpoint || (cfgv.host ? `http://${cfgv.host}:${cfgv.port || 80}` : null);
  if (!url) return record({ ok: false, kind: 'not_configured', message: 'No URL/host configured — nothing to test.' });
  // real connection attempt, truthful outcome
  const outcome = await new Promise(resolve => {
    try {
      const lib = url.startsWith('https') ? https : http;
      const req = lib.get(url, { timeout: 4000 }, res => { res.resume(); resolve({ ok: res.statusCode < 500, kind: res.statusCode < 500 ? 'connected' : 'server_error', message: `HTTP ${res.statusCode}` }); });
      req.on('timeout', () => { req.destroy(); resolve({ ok: false, kind: 'connection_failed', message: 'Timed out after 4 s' }); });
      req.on('error', e => resolve({ ok: false, kind: 'connection_failed', message: e.message }));
    } catch (e) { resolve({ ok: false, kind: 'connection_failed', message: e.message }); }
  });
  return record(outcome);
});

/* ---------- audit ---------- */
on('GET', '/api/audit', { perm: 'audit.read' }, (ctx) => {
  let rows = db.all('audit_logs').slice().reverse();
  const q = ctx.query;
  if (q.action) rows = rows.filter(a => a.action.includes(q.action.toUpperCase()));
  if (q.user) rows = rows.filter(a => (a.userEmail || '').includes(q.user.toLowerCase()));
  if (q.entityType) rows = rows.filter(a => a.entityType === q.entityType);
  if (q.q) { const s = q.q.toLowerCase(); rows = rows.filter(a => JSON.stringify(a).toLowerCase().includes(s)); }
  return J(200, paginate(rows, ctx.query, 100));
});

/* ---------- assistant (structured queries over real data — no LLM pretence) ---------- */
on('GET', '/api/assistant', {}, (ctx) => {
  const q = String(ctx.query.q || '').toLowerCase();
  const open = i => dedupe.OPEN_STATES.includes(i.status);
  const codeM = q.match(/\b([a-z]{2,4}-\d{3,5})\b/i);
  if (codeM && /(why|score|impact|explain)/.test(q)) {
    const inc = db.getBy('incidents', 'code', codeM[1].toUpperCase());
    if (!inc) return J(200, { intent: 'impact_explain', answer: `No incident ${codeM[1].toUpperCase()} found.`, rows: [] });
    return J(200, { intent: 'impact_explain', answer: `${inc.code} scores ${inc.impactScore}/100. Factor breakdown below (weights are configurable in Settings).`, rows: inc.impactBreakdown || [], incident: { code: inc.code, impactScore: inc.impactScore, category: inc.category, status: inc.status } });
  }
  if (/critical/.test(q) && /pothole/.test(q)) {
    const rows = db.find('incidents', i => i.category === 'pothole' && open(i) && (i.impactScore || 0) >= 70).map(i => ({ code: i.code, impact: i.impactScore, status: i.status, location: i.locationName, lastSeen: i.lastSeenAt }));
    return J(200, { intent: 'critical_potholes', answer: rows.length ? `${rows.length} critical unresolved pothole incident(s).` : 'No critical unresolved potholes right now.', rows });
  }
  if (/route/.test(q) && /(defect|incident|issue|highest|most)/.test(q)) {
    const byRoute = {};
    for (const i of db.find('incidents', open)) {
      const seg = geo.nearestSegment(db.all('road_segments'), i.latitude, i.longitude, 150);
      const key = seg ? seg.segment.routeCode : 'off-network';
      byRoute[key] = (byRoute[key] || 0) + 1;
    }
    const rows = Object.entries(byRoute).map(([route, count]) => ({ route, openIncidents: count })).sort((a, b) => b.openIncidents - a.openIncidents);
    return J(200, { intent: 'route_defects', answer: rows.length ? `Highest open-incident route: ${rows[0].route} (${rows[0].openIncidents}).` : 'No open incidents on any route yet.', rows });
  }
  if (/sla/.test(q) && /(breach|overdue|late)/.test(q)) {
    const t0 = new Date(); t0.setHours(0, 0, 0, 0);
    const rows = db.find('tickets', t => t.slaStatus === 'BREACHED' && (!/today/.test(q) || t.updatedAt >= t0.toISOString())).map(ticketView).map(t => ({ code: t.code, department: t.department, dueAt: t.dueAt, status: t.status, escalationLevel: t.escalationLevel }));
    return J(200, { intent: 'sla_breached', answer: rows.length ? `${rows.length} ticket(s) in breach.` : 'No SLA breaches — all open tickets are inside their windows.', rows });
  }
  if (/(await|pending).*(verif)|verif.*(await|pending|queue)/.test(q)) {
    const rows = db.find('incidents', i => i.status === 'AWAITING_VERIFICATION').map(i => { const p = verifySvc.progress(i.id); return { code: i.code, category: i.category, clearScans: p.clearObservations, needed: p.required.minClearObservations, independentDevices: p.independentDevices, location: i.locationName }; });
    return J(200, { intent: 'awaiting_verification', answer: rows.length ? `${rows.length} incident(s) awaiting post-repair verification.` : 'Nothing is awaiting verification.', rows });
  }
  return J(200, {
    intent: 'help',
    answer: 'This assistant runs structured queries on live CityLens data (no external LLM is configured — and none is faked). Try one of the examples.',
    examples: ['show critical unresolved potholes', 'which route has the highest defect count', 'which tickets breached SLA today', 'what incidents are awaiting repair verification', 'why does POT-1001 have its impact score'],
  });
});

module.exports = { ROUTES };
