'use strict';
/**
 * Authentication & RBAC.
 * - Passwords: crypto.scrypt (N=16384) with per-user random salt.
 * - Tokens: JWT-format HS256 (header.payload.signature), signed with a
 *   server secret loaded from env CITYLENS_SECRET or generated once
 *   into data/.secret (never shipped to the frontend).
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const SECRET_FILE = path.join(__dirname, '..', 'data', '.secret');
let SECRET = process.env.CITYLENS_SECRET || null;
function secret() {
  if (SECRET) return SECRET;
  try {
    fs.mkdirSync(path.dirname(SECRET_FILE), { recursive: true });
    if (fs.existsSync(SECRET_FILE)) SECRET = fs.readFileSync(SECRET_FILE, 'utf8').trim();
    if (!SECRET) {
      SECRET = crypto.randomBytes(32).toString('hex');
      fs.writeFileSync(SECRET_FILE, SECRET, { mode: 0o600 });
    }
  } catch {
    SECRET = crypto.randomBytes(32).toString('hex');
  }
  return SECRET;
}

/* ---------------- passwords ---------------- */
function hashPassword(plain) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(plain), salt, 32).toString('hex');
  return `scrypt$${salt}$${hash}`;
}
function verifyPassword(plain, stored) {
  try {
    const [algo, salt, hash] = String(stored).split('$');
    if (algo !== 'scrypt' || !salt || !hash) return false;
    const test = crypto.scryptSync(String(plain), salt, 32).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(test, 'hex'));
  } catch { return false; }
}

/* ---------------- tokens (JWT HS256) ---------------- */
const b64u = buf => Buffer.from(buf).toString('base64url');
function sign(payload, ttlMs = 12 * 60 * 60 * 1000) {
  const header = b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64u(JSON.stringify({ ...payload, iat: Date.now(), exp: Date.now() + ttlMs }));
  const sig = crypto.createHmac('sha256', secret()).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}
function verify(token) {
  try {
    const [header, body, sig] = String(token).split('.');
    if (!header || !body || !sig) return null;
    const expect = crypto.createHmac('sha256', secret()).update(`${header}.${body}`).digest('base64url');
    const a = Buffer.from(sig), b = Buffer.from(expect);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload.exp || Date.now() > payload.exp) return null;
    return payload;
  } catch { return null; }
}

/* ---------------- roles & permissions (enforced server-side per endpoint) ---------------- */
const ROLES = {
  admin:    { label: 'System Admin' },
  operator: { label: 'Command Centre Operator' },
  officer:  { label: 'Department Officer' },      // scoped to user.department
  field:    { label: 'Field Worker' },
  reviewer: { label: 'AI Reviewer' },
  analyst:  { label: 'Read-Only Analyst' },
};

/** permission → roles allowed (admin implicitly allowed everywhere). */
const PERMS = {
  'incident.review':   ['operator', 'reviewer', 'officer'],
  'incident.assign':   ['operator', 'officer'],
  'ticket.manage':     ['operator', 'officer'],
  'ticket.fieldwork':  ['field', 'officer'],
  'repair.submit':     ['field', 'officer'],
  'detection.review':  ['reviewer', 'operator'],
  'analysis.run':      ['operator', 'officer', 'field', 'reviewer'],
  'telemetry.ingest':  ['operator', 'officer', 'field'],
  'fleet.manage':      [],                        // admin only
  'zones.manage':      ['operator'],
  'sla.manage':        [],
  'users.manage':      [],
  'settings.manage':   [],
  'integrations.manage': [],
  'audit.read':        ['operator'],
  'notifications.manage': ['operator', 'officer', 'field', 'reviewer'],
};

function can(role, perm) {
  if (role === 'admin') return true;
  const list = PERMS[perm];
  if (!list) return false;
  return list.includes(role);
}

module.exports = { hashPassword, verifyPassword, sign, verify, ROLES, PERMS, can };
