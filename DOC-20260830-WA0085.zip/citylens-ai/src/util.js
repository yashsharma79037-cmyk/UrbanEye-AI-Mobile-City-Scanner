'use strict';
const crypto = require('crypto');

/* ---------- ids & random ---------- */
function uid(prefix) {
  const s = crypto.randomBytes(6).toString('hex').toUpperCase();
  return prefix ? `${prefix}-${s}` : s;
}
function shortNum(n) { return String(n).padStart(3, '0'); }

/** Deterministic PRNG (mulberry32) — stable derived values per id */
function seededRng(seedStr) {
  let h = 1779033703 ^ seedStr.length;
  for (let i = 0; i < seedStr.length; i++) {
    h = Math.imul(h ^ seedStr.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  let a = (h >>> 0) || 42;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function pick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
function between(rng, a, b) { return a + rng() * (b - a); }
function intBetween(rng, a, b) { return Math.floor(between(rng, a, b + 1)); }
function weighted(rng, entries) { // entries: [ [value, weight], ... ]
  const total = entries.reduce((s, e) => s + e[1], 0);
  let r = rng() * total;
  for (const [v, w] of entries) { r -= w; if (r <= 0) return v; }
  return entries[entries.length - 1][0];
}

/* ---------- time ---------- */
const MIN = 60 * 1000, HOUR = 60 * MIN, DAY = 24 * HOUR;
function iso(ts) { return new Date(ts).toISOString(); }
function ago(ms) { return Date.now() - ms; }

/* ---------- geo ---------- */
function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371, toRad = d => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function polylineLengthKm(points) {
  let d = 0;
  for (let i = 1; i < points.length; i++) d += haversineKm(points[i - 1][0], points[i - 1][1], points[i][0], points[i][1]);
  return d;
}
/** Interpolate a position along a polyline. t in [0,1]. Returns {lat,lng,heading}. */
function pointAlong(points, t) {
  const segs = [];
  let total = 0;
  for (let i = 1; i < points.length; i++) {
    const d = haversineKm(points[i - 1][0], points[i - 1][1], points[i][0], points[i][1]);
    segs.push(d); total += d;
  }
  if (total === 0) return { lat: points[0][0], lng: points[0][1], heading: 0 };
  let target = Math.min(Math.max(t, 0), 1) * total;
  for (let i = 0; i < segs.length; i++) {
    if (target <= segs[i] || i === segs.length - 1) {
      const f = segs[i] === 0 ? 0 : target / segs[i];
      const [aLat, aLng] = points[i], [bLat, bLng] = points[i + 1];
      const lat = aLat + (bLat - aLat) * f, lng = aLng + (bLng - aLng) * f;
      const heading = (Math.atan2(bLng - aLng, bLat - aLat) * 180) / Math.PI;
      return { lat: +lat.toFixed(6), lng: +lng.toFixed(6), heading: Math.round((heading + 360) % 360) };
    }
    target -= segs[i];
  }
  const last = points[points.length - 1];
  return { lat: last[0], lng: last[1], heading: 0 };
}

/* ---------- csv ---------- */
function toCsv(columns, rows) {
  const esc = v => {
    if (v === null || v === undefined) return '';
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [columns.map(esc).join(','), ...rows.map(r => columns.map(c => esc(r[c])).join(','))].join('\n');
}

/* ---------- misc ---------- */
function clamp(n, a, b) { return Math.min(Math.max(n, a), b); }
function round1(n) { return Math.round(n * 10) / 10; }
function safeName(name) { return String(name || 'file').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 120); }

module.exports = {
  uid, shortNum, seededRng, pick, between, intBetween, weighted,
  MIN, HOUR, DAY, iso, ago,
  haversineKm, polylineLengthKm, pointAlong,
  toCsv, clamp, round1, safeName,
};
