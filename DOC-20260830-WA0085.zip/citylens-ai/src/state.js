'use strict';
/**
 * Incident & ticket state machines. ALL status changes go through transition();
 * invalid jumps are rejected server-side and every change writes a history row.
 */
const db = require('./db');
const { uid } = require('./util');
const { audit, notify } = require('./audit');

const INCIDENT_STATES = ['DETECTED', 'UNDER_REVIEW', 'CONFIRMED', 'ASSIGNED', 'IN_PROGRESS',
  'REPAIR_SUBMITTED', 'AWAITING_VERIFICATION', 'VERIFIED', 'CLOSED', 'REOPENED', 'REJECTED'];

/** to-state -> { from:[...], roles:[...] } (roles that may perform it; admin always may) */
const INCIDENT_FLOW = {
  UNDER_REVIEW: { from: ['DETECTED', 'REOPENED'], roles: ['operator', 'reviewer', 'officer'] },
  CONFIRMED: { from: ['UNDER_REVIEW', 'DETECTED'], roles: ['operator', 'reviewer', 'officer'] },
  REJECTED: { from: ['DETECTED', 'UNDER_REVIEW'], roles: ['operator', 'reviewer', 'officer'] },
  ASSIGNED: { from: ['CONFIRMED', 'REOPENED'], roles: ['operator', 'officer'] },
  IN_PROGRESS: { from: ['ASSIGNED'], roles: ['operator', 'officer', 'field'] },
  REPAIR_SUBMITTED: { from: ['IN_PROGRESS'], roles: ['field', 'officer'] },
  AWAITING_VERIFICATION: { from: ['REPAIR_SUBMITTED'], roles: ['system', 'operator', 'officer'] },
  VERIFIED: { from: ['AWAITING_VERIFICATION'], roles: ['system'] },          // only re-observation verifies
  REOPENED: { from: ['AWAITING_VERIFICATION', 'VERIFIED', 'CLOSED'], roles: ['system', 'operator', 'officer'] },
  CLOSED: { from: ['VERIFIED', 'REJECTED'], roles: ['system', 'operator', 'officer'] },
};

const TICKET_STATES = ['OPEN', 'ASSIGNED', 'ACKNOWLEDGED', 'WORK_STARTED', 'REPAIR_SUBMITTED',
  'AWAITING_VERIFICATION', 'RESOLVED', 'REOPENED', 'CLOSED'];

const TICKET_FLOW = {
  ASSIGNED: { from: ['OPEN', 'REOPENED'], roles: ['operator', 'officer'] },
  ACKNOWLEDGED: { from: ['ASSIGNED'], roles: ['field', 'officer'] },
  WORK_STARTED: { from: ['ACKNOWLEDGED', 'ASSIGNED'], roles: ['field', 'officer'] },
  REPAIR_SUBMITTED: { from: ['WORK_STARTED'], roles: ['field', 'officer'] },
  AWAITING_VERIFICATION: { from: ['REPAIR_SUBMITTED'], roles: ['system'] },
  RESOLVED: { from: ['AWAITING_VERIFICATION'], roles: ['system'] },
  REOPENED: { from: ['AWAITING_VERIFICATION', 'RESOLVED', 'CLOSED'], roles: ['system', 'operator', 'officer'] },
  CLOSED: { from: ['RESOLVED'], roles: ['system', 'operator', 'officer'] },
};

function canTransition(flow, fromStatus, toStatus, actorRole) {
  const rule = flow[toStatus];
  if (!rule) return { ok: false, error: `Unknown target status ${toStatus}` };
  if (!rule.from.includes(fromStatus)) return { ok: false, error: `Invalid transition ${fromStatus} → ${toStatus}` };
  if (actorRole === 'admin' || actorRole === 'system') return { ok: true };
  if (!rule.roles.includes(actorRole)) return { ok: false, error: `Role '${actorRole}' may not perform ${fromStatus} → ${toStatus}` };
  return { ok: true };
}

/** Transition an incident. actor = user object or 'system'. Returns {ok, incident?|error}. */
function transitionIncident(incidentId, toStatus, actor, note, meta = {}) {
  const inc = db.get('incidents', incidentId);
  if (!inc) return { ok: false, code: 404, error: 'Incident not found' };
  const role = actor === 'system' ? 'system' : actor.role;
  const chk = canTransition(INCIDENT_FLOW, inc.status, toStatus, role);
  if (!chk.ok) return { ok: false, code: 409, error: chk.error };

  const patch = { status: toStatus, updatedAt: new Date().toISOString(), ...meta };
  if (toStatus === 'CLOSED') patch.closedAt = patch.updatedAt;
  if (toStatus === 'VERIFIED') patch.verifiedAt = patch.updatedAt;
  const updated = db.update('incidents', incidentId, patch);

  db.insert('incident_history', {
    id: uid('IH'), incidentId, previousStatus: inc.status, newStatus: toStatus,
    changedBy: actor === 'system' ? 'system' : actor.email, role,
    note: note || null, ticketId: meta.ticketId || inc.ticketId || null,
    metadata: meta && Object.keys(meta).length ? meta : null,
    timestamp: patch.updatedAt,
  });
  audit(actor === 'system' ? 'system' : actor, 'INCIDENT_' + toStatus, 'incident', incidentId, note || null);

  if (toStatus === 'REOPENED') notify({ kind: 'INCIDENT_REOPENED', severity: 'high', title: `Incident reopened — ${inc.code}`, message: note || 'Defect re-detected after repair.', entityType: 'incident', entityId: incidentId, department: inc.department });
  if (toStatus === 'VERIFIED') notify({ kind: 'INCIDENT_VERIFIED', severity: 'low', title: `Repair verified — ${inc.code}`, message: 'Post-repair observations show no remaining defect.', entityType: 'incident', entityId: incidentId, department: inc.department });
  return { ok: true, incident: updated };
}

function transitionTicket(ticketId, toStatus, actor, note, meta = {}) {
  const t = db.get('tickets', ticketId);
  if (!t) return { ok: false, code: 404, error: 'Ticket not found' };
  const role = actor === 'system' ? 'system' : actor.role;
  // field workers may only act on their own tickets
  if (role === 'field' && t.assignedOfficerId && actor.id !== t.assignedOfficerId)
    return { ok: false, code: 403, error: 'This ticket is assigned to another field worker' };
  const chk = canTransition(TICKET_FLOW, t.status, toStatus, role);
  if (!chk.ok) return { ok: false, code: 409, error: chk.error };

  const now = new Date().toISOString();
  const patch = { status: toStatus, updatedAt: now, ...meta };
  if (toStatus === 'WORK_STARTED' && !t.workStartedAt) patch.workStartedAt = now;
  if (toStatus === 'REPAIR_SUBMITTED') patch.repairSubmittedAt = now;
  if (toStatus === 'RESOLVED') patch.resolvedAt = now;
  const updated = db.update('tickets', ticketId, patch);

  db.insert('ticket_history', {
    id: uid('TH'), ticketId, previousStatus: t.status, newStatus: toStatus,
    changedBy: actor === 'system' ? 'system' : actor.email, role, note: note || null,
    metadata: meta && Object.keys(meta).length ? meta : null, timestamp: now,
  });
  audit(actor === 'system' ? 'system' : actor, 'TICKET_' + toStatus, 'ticket', ticketId, note || null);
  return { ok: true, ticket: updated };
}

module.exports = { INCIDENT_STATES, TICKET_STATES, INCIDENT_FLOW, TICKET_FLOW, transitionIncident, transitionTicket };
