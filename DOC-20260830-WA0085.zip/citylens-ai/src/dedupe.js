'use strict';
/**
 * Multi-source duplicate detection & incident merging — a signature CityLens feature.
 * A new accepted detection either ATTACHES to a matching unresolved incident as an
 * additional observation, or opens a new incident. All matching uses real Haversine
 * distance with per-category radii from settings.mergeRadii.
 *
 * Confidence aggregation ("noisy-OR v1", documented in the UI):
 *   For each independent device keep its best confidence c_d, then
 *   agg = 1 − Π_d (1 − c_d), capped at 0.995.
 * Independent corroboration raises reliability; repeated frames from one
 * device do not inflate it.
 */
const db = require('./db');
const geo = require('./geo');
const { uid } = require('./util');
const { audit, notify } = require('./audit');
const { refreshImpact } = require('./score');

const DEFAULT_RADII = { // metres
  pothole: 20, road_crack: 20, road_damage: 25, waterlogging: 40, missing_divider: 25,
  damaged_divider: 25, missing_zebra: 15, sign_damage: 15, obstruction: 30, accident: 50,
  congestion: 120, pedestrian_risk: 40, vehicle: 60, garbage_overflow: 30, missing_sign: 15, rash_driving: 80, road_hazard: 35, other: 25,
};
const OPEN_STATES = ['DETECTED', 'UNDER_REVIEW', 'CONFIRMED', 'ASSIGNED', 'IN_PROGRESS',
  'REPAIR_SUBMITTED', 'AWAITING_VERIFICATION', 'REOPENED'];

function setting(key, fallback) { const r = db.getBy('settings', 'key', key); return r ? r.value : fallback; }
function radiusFor(category) { return (setting('mergeRadii', {})[category]) ?? DEFAULT_RADII[category] ?? 25; }

function aggregate(observations) {
  const bestPerDevice = {};
  for (const o of observations) {
    const k = o.deviceId || o.sourceId || 'unknown';
    bestPerDevice[k] = Math.max(bestPerDevice[k] || 0, o.confidence || 0);
  }
  let miss = 1;
  for (const c of Object.values(bestPerDevice)) miss *= (1 - Math.min(0.99, c));
  return {
    aggConfidence: Math.min(0.995, 1 - miss),
    uniqueDeviceCount: Object.keys(bestPerDevice).length,
    maxConfidence: Math.max(0, ...observations.map(o => o.confidence || 0)),
    method: 'noisy-or v1 (best confidence per independent device)',
  };
}

function nextIncidentCode(category) {
  const prefix = ({ pothole: 'POT', waterlogging: 'WTR', road_crack: 'CRK', road_damage: 'DMG', sign_damage: 'SGN', accident: 'ACC', obstruction: 'OBS', congestion: 'CNG', garbage_overflow: 'GAR', missing_sign: 'MSN', rash_driving: 'RSH', road_hazard: 'HAZ', missing_zebra: 'ZEB', missing_divider: 'DIV', damaged_divider: 'DIV', pedestrian_risk: 'PED', waterlogging: 'WTR' }[category]) || 'INC';
  const n = db.count('incidents', () => true) + 1000 + 1;
  return `${prefix}-${n}`;
}

/**
 * Process one stored detection through dedupe. Returns { incident, observation, merged:bool }.
 */
function processDetection(det) {
  const radius = radiusFor(det.category);
  const candidates = db.find('incidents', i =>
    i.category === det.category && OPEN_STATES.includes(i.status) &&
    geo.haversineM(i.latitude, i.longitude, det.latitude, det.longitude) <= radius);
  // nearest unresolved same-category incident within radius wins
  candidates.sort((a, b) =>
    geo.haversineM(a.latitude, a.longitude, det.latitude, det.longitude) -
    geo.haversineM(b.latitude, b.longitude, det.latitude, det.longitude));
  const now = det.timestamp || new Date().toISOString();
  let incident = candidates[0] || null;
  let merged = !!incident;
  const prevStatus = incident ? incident.status : null;

  if (!incident) {
    incident = db.insert('incidents', {
      id: uid('INC'), code: nextIncidentCode(det.category),
      category: det.category, status: 'DETECTED',
      latitude: det.latitude, longitude: det.longitude,
      locationName: det.locationName || null, routeId: det.routeId || null,
      department: null, ticketId: null,
      firstSeenAt: now, lastSeenAt: now,
      observationCount: 0, uniqueDeviceCount: 0, uniqueBusCount: 0,
      aggConfidence: 0, maxConfidence: 0, aggMethod: null,
      impactScore: null, impactBreakdown: null,
      createdAt: now, updatedAt: now,
    });
    db.insert('incident_history', {
      id: uid('IH'), incidentId: incident.id, previousStatus: null, newStatus: 'DETECTED',
      changedBy: 'system', role: 'system', note: `Opened from detection ${det.id}`, timestamp: now,
    });
  }

  const obs = db.insert('observations', {
    id: uid('OBS'), incidentId: incident.id, detectionId: det.id,
    deviceId: det.deviceId || null, busId: det.busId || null, sourceType: det.sourceType,
    confidence: det.confidence, latitude: det.latitude, longitude: det.longitude,
    distanceFromIncidentM: Math.round(geo.haversineM(incident.latitude, incident.longitude, det.latitude, det.longitude)),
    timestamp: now,
  });

  const allObs = db.find('observations', o => o.incidentId === incident.id);
  const agg = aggregate(allObs);
  const buses = new Set(allObs.map(o => o.busId).filter(Boolean));
  incident = db.update('incidents', incident.id, {
    lastSeenAt: now,
    observationCount: allObs.length,
    uniqueDeviceCount: agg.uniqueDeviceCount,
    uniqueBusCount: buses.size,
    aggConfidence: Math.round(agg.aggConfidence * 1000) / 1000,
    maxConfidence: Math.round(agg.maxConfidence * 1000) / 1000,
    aggMethod: agg.method,
    updatedAt: now,
  });
  db.update('detections', det.id, { incidentId: incident.id });
  incident = refreshImpact(incident.id);

  if (!merged) {
    audit('system', 'INCIDENT_OPENED', 'incident', incident.id, `${det.category} via detection ${det.id}`);
    if ((incident.impactScore || 0) >= 70 || ['accident', 'waterlogging'].includes(det.category)) {
      notify({ kind: 'CRITICAL_INCIDENT', severity: 'critical', title: `New ${det.category.replace('_', ' ')} — ${incident.code}`, message: `Impact ${incident.impactScore}/100 near ${det.locationName || `${det.latitude.toFixed(4)}, ${det.longitude.toFixed(4)}`}`, entityType: 'incident', entityId: incident.id });
    }
  }

  // A defect re-detected on an incident awaiting verification ⇒ verification failed (handled in verify.js)
  return { incident, observation: obs, merged, prevStatus, radiusM: radius };
}

module.exports = { processDetection, aggregate, radiusFor, DEFAULT_RADII, OPEN_STATES };
