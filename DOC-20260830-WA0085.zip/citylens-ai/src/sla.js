'use strict';
/**
 * SLA engine. Rules live in sla_rules (editable). due_at is computed at ticket
 * creation; a periodic evaluator (started by realtime.js) recomputes status on
 * the real clock and writes escalation records + notifications on breach.
 * States: WITHIN_SLA · AT_RISK (≤25% time left) · BREACHED ·
 *         RESOLVED_WITHIN_SLA · RESOLVED_AFTER_SLA
 */
const db = require('./db');
const { uid } = require('./util');
const { audit, notify } = require('./audit');

const ESCALATION_LEVELS = ['DEPARTMENT_OFFICER', 'ZONE_OFFICER', 'COMMAND_CENTRE'];

function ruleFor(category, impactScore) {
  const rules = db.find('sla_rules', r => r.active !== false && r.category === category)
    .sort((a, b) => (b.minImpact || 0) - (a.minImpact || 0));
  for (const r of rules) if ((impactScore ?? 0) >= (r.minImpact || 0)) return r;
  return db.getBy('sla_rules', 'category', '*') || { hours: 72, name: 'Default 72 h' };
}

function applySla(ticket) {
  const rule = ruleFor(ticket.category, ticket.impactScore);
  const due = new Date(new Date(ticket.createdAt).getTime() + rule.hours * 3600e3).toISOString();
  return db.update('tickets', ticket.id, { slaRuleId: rule.id || null, slaRuleName: rule.name, slaHours: rule.hours, dueAt: due, slaStatus: 'WITHIN_SLA', escalationLevel: 0 });
}

function evaluateTicket(t, now = Date.now()) {
  if (!t.dueAt) return null;
  const done = ['RESOLVED', 'CLOSED'].includes(t.status);
  if (done) {
    const endAt = new Date(t.resolvedAt || t.updatedAt).getTime();
    const s = endAt <= new Date(t.dueAt).getTime() ? 'RESOLVED_WITHIN_SLA' : 'RESOLVED_AFTER_SLA';
    if (t.slaStatus !== s) return db.update('tickets', t.id, { slaStatus: s });
    return null;
  }
  const total = t.slaHours * 3600e3;
  const left = new Date(t.dueAt).getTime() - now;
  let s = 'WITHIN_SLA';
  if (left <= 0) s = 'BREACHED';
  else if (left <= total * 0.25) s = 'AT_RISK';
  if (s === t.slaStatus) return null;

  const upd = db.update('tickets', t.id, { slaStatus: s });
  if (s === 'AT_RISK') {
    notify({ kind: 'SLA_AT_RISK', severity: 'high', title: `SLA at risk — ${t.code}`, message: `${Math.max(0, Math.round(left / 60000))} min remaining (${t.slaRuleName}).`, entityType: 'ticket', entityId: t.id, department: t.department });
  }
  if (s === 'BREACHED') escalate(upd, 'SLA breached');
  return upd;
}

function escalate(t, reason) {
  const prev = t.escalationLevel || 0;
  const level = Math.min(prev + 1, ESCALATION_LEVELS.length);
  db.update('tickets', t.id, { escalationLevel: level });
  const row = db.insert('escalations', {
    id: uid('ESC'), ticketId: t.id, incidentId: t.incidentId, reason,
    previousLevel: prev ? ESCALATION_LEVELS[prev - 1] : null, newLevel: ESCALATION_LEVELS[level - 1],
    slaStatus: t.slaStatus || 'BREACHED', timestamp: new Date().toISOString(),
  });
  audit('system', 'SLA_ESCALATED', 'ticket', t.id, `${reason} → ${row.newLevel}`);
  notify({
    kind: 'SLA_BREACHED', severity: 'critical',
    title: `SLA breached — ${t.code}`,
    message: `Escalated to ${row.newLevel.replace(/_/g, ' ')}. ${reason}.`,
    entityType: 'ticket', entityId: t.id,
    department: level === 1 ? t.department : null,          // L2+ go platform-wide
    forRole: level >= 3 ? 'operator' : null,
  });
  return row;
}

/** Evaluate all open tickets — called on an interval by realtime.js and after writes. */
function evaluateAll() {
  const now = Date.now();
  let changed = 0;
  for (const t of db.all('tickets')) if (evaluateTicket(t, now)) changed++;
  return changed;
}

module.exports = { applySla, evaluateTicket, evaluateAll, escalate, ruleFor, ESCALATION_LEVELS };
