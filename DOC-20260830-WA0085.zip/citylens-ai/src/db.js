'use strict';
/**
 * CityLens embedded data store.
 * --------------------------------------------------------------
 * Zero-dependency JSON document store with atomic, debounced writes.
 * The access layer below (find / get / insert / update / remove) is the
 * ONLY way the app touches data, so swapping in PostgreSQL/MySQL later
 * means re-implementing this one module (see schema.sql for the
 * equivalent relational schema). All lookups are parameterized through
 * this layer — no string-built queries anywhere in the codebase.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'citylens.json');
const TMP_FILE = DB_FILE + '.tmp';

const COLLECTIONS = [
  // identity & fleet
  'users', 'buses', 'devices', 'routes', 'departments',
  // live data (all real, ingested)
  'telemetry', 'detections', 'observations', 'ingest_events',
  // incident lifecycle
  'incidents', 'incident_history', 'tickets', 'ticket_history',
  'repair_evidence', 'verifications',
  // governance
  'sla_rules', 'escalations', 'notifications', 'audit_logs', 'human_feedback',
  // spatial config
  'safety_zones', 'road_segments',
  // AI ops
  'ai_jobs', 'ai_models',
  // platform
  'integrations', 'settings',
];
const SCHEMA_VERSION = 2;

let state = null;
let dirty = false;
let flushTimer = null;

function emptyState() {
  const s = { _meta: { version: SCHEMA_VERSION, seededAt: null } };
  for (const c of COLLECTIONS) s[c] = [];
  return s;
}

function load() {
  if (state) return state;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) {
    try {
      state = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
      for (const c of COLLECTIONS) if (!Array.isArray(state[c])) state[c] = [];
      if (!state._meta) state._meta = { version: 1, seededAt: null };
      if ((state._meta.version || 1) < SCHEMA_VERSION) {
        // v1 stored generated demonstration data (synthetic detections/incidents).
        // v2 is real-data-only: config collections are re-seeded, operational
        // collections start empty. A v1 file is archived, never silently reused.
        const bak = DB_FILE + '.v' + (state._meta.version || 1) + '.bak';
        try { fs.renameSync(DB_FILE, bak); console.log('[db] archived v1 data file →', bak); } catch {}
        state = emptyState();
      }
    } catch (err) {
      console.error('[db] corrupt data file, starting fresh:', err.message);
      state = emptyState();
    }
  } else {
    state = emptyState();
  }
  return state;
}

function flushNow() {
  if (!state) return;
  dirty = false;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(TMP_FILE, JSON.stringify(state));
    fs.renameSync(TMP_FILE, DB_FILE); // atomic swap
  } catch (err) {
    console.error('[db] flush failed:', err.message);
  }
}

function persist() {
  dirty = true;
  if (flushTimer) return;
  flushTimer = setTimeout(() => { flushTimer = null; if (dirty) flushNow(); }, 800);
}

process.on('exit', () => { if (dirty) flushNow(); });
process.on('SIGINT', () => { if (dirty) flushNow(); process.exit(0); });
process.on('SIGTERM', () => { if (dirty) flushNow(); process.exit(0); });

/* ---------------- access layer ---------------- */

function all(coll) { return load()[coll]; }

function find(coll, predicate) {
  const rows = load()[coll];
  return predicate ? rows.filter(predicate) : rows.slice();
}

function get(coll, id) {
  return load()[coll].find(r => r.id === id) || null;
}

function getBy(coll, field, value) {
  return load()[coll].find(r => r[field] === value) || null;
}

function insert(coll, row) {
  load()[coll].push(row);
  persist();
  return row;
}

function insertMany(coll, rows) {
  const c = load()[coll];
  for (const r of rows) c.push(r);
  persist();
  return rows;
}

function update(coll, id, patch) {
  const row = get(coll, id);
  if (!row) return null;
  Object.assign(row, patch);
  persist();
  return row;
}

function remove(coll, id) {
  const rows = load()[coll];
  const i = rows.findIndex(r => r.id === id);
  if (i === -1) return false;
  rows.splice(i, 1);
  persist();
  return true;
}

function replaceAll(coll, rows) {
  load()[coll] = rows;
  persist();
}

function meta() { return load()._meta; }
function setMeta(patch) { Object.assign(load()._meta, patch); persist(); }

function count(coll, predicate) {
  const rows = load()[coll];
  if (!predicate) return rows.length;
  let n = 0; for (const r of rows) if (predicate(r)) n++;
  return n;
}

function isSeeded() { return !!load()._meta.seededAt; }

function resetAll() {
  state = emptyState();
  persist();
}

module.exports = {
  load, all, find, get, getBy, insert, insertMany, update, remove,
  replaceAll, meta, setMeta, count, isSeeded, resetAll, flushNow,
  DATA_DIR,
};
