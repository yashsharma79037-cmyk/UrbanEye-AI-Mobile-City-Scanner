'use strict';
/** Shared domain catalog for CityLens AI (Pune reference dataset).
 *  Coordinates are approximate reference locations for the seeded Pune network. */

const CATEGORIES = {
  pothole:         { label: 'Pothole',                icon: 'pothole',    dept: 'Road Maintenance',        kind: 'infrastructure' },
  road_crack:      { label: 'Road Crack',             icon: 'crack',      dept: 'Road Maintenance',        kind: 'infrastructure' },
  road_damage:     { label: 'Road Damage',            icon: 'damage',     dept: 'Public Works Department', kind: 'infrastructure' },
  waterlogging:    { label: 'Waterlogging',           icon: 'water',      dept: 'Drainage Department',     kind: 'infrastructure' },
  missing_divider: { label: 'Missing Divider',        icon: 'divider',    dept: 'Road Maintenance',        kind: 'infrastructure' },
  damaged_divider: { label: 'Damaged Divider',        icon: 'divider',    dept: 'Road Maintenance',        kind: 'infrastructure' },
  missing_zebra:   { label: 'Missing Zebra Crossing', icon: 'zebra',      dept: 'Municipal Corporation',   kind: 'infrastructure' },
  sign_damage:     { label: 'Traffic Sign Damage',    icon: 'sign',       dept: 'Traffic Police',          kind: 'infrastructure' },
  vehicle:         { label: 'Vehicle',                icon: 'vehicle',    dept: 'Traffic Police',          kind: 'traffic' },
  congestion:      { label: 'Traffic Congestion',     icon: 'congestion', dept: 'Traffic Police',          kind: 'traffic' },
  pedestrian_risk: { label: 'Pedestrian Risk',        icon: 'pedestrian', dept: 'Traffic Police',          kind: 'safety' },
  obstruction:     { label: 'Road Obstruction',       icon: 'obstruction',dept: 'Municipal Corporation',   kind: 'safety' },
  accident:        { label: 'Accident',               icon: 'accident',   dept: 'Emergency Services',      kind: 'safety' },
  other:           { label: 'Other',                  icon: 'other',      dept: 'Municipal Corporation',   kind: 'other' },
};

const SEVERITIES = ['low', 'medium', 'high', 'critical'];

const DEPARTMENTS = [
  'Road Maintenance', 'Traffic Police', 'Municipal Corporation',
  'Drainage Department', 'Public Works Department', 'Transport Department', 'Emergency Services',
];

const VEHICLE_TYPES = ['Car', 'Bus', 'Motorcycle', 'Auto-rickshaw', 'Truck', 'Bicycle', 'Other'];

/** Approximate Pune landmark coordinates (reference network geometry). */
const PLACES = {
  'Swargate':        [18.5018, 73.8636],
  'Shivajinagar':    [18.5314, 73.8446],
  'JM Road':         [18.5236, 73.8478],
  'FC Road':         [18.5227, 73.8412],
  'Deccan Gymkhana': [18.5158, 73.8413],
  'Kothrud':         [18.5074, 73.8077],
  'Karve Road':      [18.5031, 73.8296],
  'Hadapsar':        [18.5089, 73.9260],
  'Magarpatta':      [18.5157, 73.9276],
  'Camp':            [18.5167, 73.8797],
  'Pune Station':    [18.5289, 73.8744],
  'Katraj':          [18.4575, 73.8650],
  'Bibwewadi':       [18.4776, 73.8672],
  'Aundh':           [18.5590, 73.8075],
  'Baner':           [18.5590, 73.7868],
  'University Circle':[18.5372, 73.8305],
  'Yerawada':        [18.5442, 73.8790],
  'Viman Nagar':     [18.5679, 73.9143],
  'Kalyani Nagar':   [18.5482, 73.9020],
  'Sinhagad Road':   [18.4839, 73.8230],
  'Warje':           [18.4832, 73.8039],
  'Wakdewadi':       [18.5432, 73.8515],
  'Nal Stop':        [18.5069, 73.8266],
};

const P = PLACES;

/** Route polylines: [routeCode, name, start, end, waypoints[[lat,lng]...]] */
const ROUTE_DEFS = [
  ['R-05', 'Swargate – Shivajinagar Corridor', 'Swargate', 'Shivajinagar',
    [P['Swargate'], [18.5090, 73.8600], [18.5152, 73.8552], P['JM Road'], [18.5280, 73.8460], P['Shivajinagar']]],
  ['R-12', 'Katraj – Pune Station Express', 'Katraj', 'Pune Station',
    [P['Katraj'], P['Bibwewadi'], [18.4900, 73.8660], P['Swargate'], [18.5100, 73.8700], [18.5200, 73.8760], P['Pune Station']]],
  ['R-18', 'Kothrud – Camp Line', 'Kothrud', 'Camp',
    [P['Kothrud'], P['Nal Stop'], P['Karve Road'], P['Deccan Gymkhana'], [18.5140, 73.8520], [18.5150, 73.8660], P['Camp']]],
  ['R-21', 'Hadapsar – Deccan Metro Feeder', 'Hadapsar', 'Deccan Gymkhana',
    [P['Hadapsar'], [18.5100, 73.9050], [18.5130, 73.8880], P['Camp'], [18.5150, 73.8620], [18.5140, 73.8500], P['Deccan Gymkhana']]],
  ['R-27', 'Aundh – Swargate City Link', 'Aundh', 'Swargate',
    [P['Aundh'], P['University Circle'], P['Wakdewadi'], P['Shivajinagar'], P['JM Road'], [18.5140, 73.8520], P['Swargate']]],
  ['R-33', 'Baner – Viman Nagar Crosstown', 'Baner', 'Viman Nagar',
    [P['Baner'], P['Aundh'], P['University Circle'], P['Shivajinagar'], P['Yerawada'], P['Kalyani Nagar'], P['Viman Nagar']]],
  ['R-40', 'Sinhagad Road – Pune Station', 'Warje', 'Pune Station',
    [P['Warje'], P['Sinhagad Road'], [18.4950, 73.8360], P['Deccan Gymkhana'], P['JM Road'], [18.5270, 73.8560], [18.5290, 73.8680], P['Pune Station']]],
  ['R-46', 'Magarpatta – Shivajinagar IT Shuttle', 'Magarpatta', 'Shivajinagar',
    [P['Magarpatta'], P['Hadapsar'], [18.5230, 73.9100], P['Kalyani Nagar'], P['Yerawada'], [18.5380, 73.8620], P['Shivajinagar']]],
];

/** Named road segments used for road-health scoring. */
const ROADS = [
  { name: 'JM Road', area: 'Deccan',            at: P['JM Road'],         lengthKm: 2.1 },
  { name: 'FC Road', area: 'Deccan',            at: P['FC Road'],         lengthKm: 1.8 },
  { name: 'Karve Road', area: 'Kothrud',         at: P['Karve Road'],      lengthKm: 4.6 },
  { name: 'Sinhagad Road', area: 'Vadgaon',      at: P['Sinhagad Road'],   lengthKm: 6.2 },
  { name: 'Satara Road', area: 'Bibwewadi',        at: [18.4820, 73.8590],   lengthKm: 5.4 },
  { name: 'Solapur Road', area: 'Hadapsar',       at: [18.5060, 73.9080],   lengthKm: 7.1 },
  { name: 'Ahmednagar Road', area: 'Yerawada',    at: P['Yerawada'],        lengthKm: 6.8 },
  { name: 'Baner Road', area: 'Baner',         at: P['Baner'],           lengthKm: 5.0 },
  { name: 'Ganeshkhind Road', area: 'Shivajinagar',   at: P['University Circle'],lengthKm: 3.4 },
  { name: 'Tilak Road', area: 'Sadashiv Peth',         at: [18.5065, 73.8480],   lengthKm: 2.4 },
  { name: 'Shankar Sheth Road', area: 'Camp', at: [18.5010, 73.8700],   lengthKm: 2.9 },
  { name: 'Airport Road', area: 'Viman Nagar',       at: P['Viman Nagar'],     lengthKm: 4.2 },
];

const AI_MODELS = [
  { id: 'MDL-ROAD',  name: 'YOLO Road Scanner',        version: 'v1.2', task: 'Road defect detection',      precision: 91.7, recall: 88.4, latencyMs: 41, fps: 22.8 },
  { id: 'MDL-VEH',   name: 'YOLO Vehicle Net',         version: 'v2.0', task: 'Vehicle detection & ANPR',   precision: 94.2, recall: 92.1, latencyMs: 36, fps: 26.4 },
  { id: 'MDL-TRAF',  name: 'FlowSense Density',        version: 'v1.1', task: 'Traffic density estimation', precision: 89.5, recall: 90.2, latencyMs: 28, fps: 31.0 },
  { id: 'MDL-PED',   name: 'GuardianEye Pedestrian',   version: 'v1.4', task: 'Pedestrian & risk detection',precision: 93.1, recall: 91.6, latencyMs: 39, fps: 24.2 },
  { id: 'MDL-SIGN',  name: 'SignSpot TSR',             version: 'v0.9', task: 'Traffic sign detection',     precision: 87.8, recall: 84.9, latencyMs: 33, fps: 27.5 },
];

function modelFor(category) {
  if (['vehicle', 'congestion', 'accident'].includes(category)) return category === 'congestion' ? AI_MODELS[2] : AI_MODELS[1];
  if (category === 'pedestrian_risk') return AI_MODELS[3];
  if (category === 'sign_damage') return AI_MODELS[4];
  return AI_MODELS[0];
}

function nearestPlace(lat, lng) {
  let best = null, bestD = Infinity;
  for (const [name, [plat, plng]] of Object.entries(PLACES)) {
    const d = (plat - lat) ** 2 + (plng - lng) ** 2;
    if (d < bestD) { bestD = d; best = name; }
  }
  return best || 'Pune';
}

const RECOMMENDED_ACTION = {
  pothole: 'Dispatch a Road Maintenance patching crew; cold-mix repair within 48 hours for high severity.',
  road_crack: 'Schedule crack sealing before monsoon to prevent pothole formation.',
  road_damage: 'Assess sub-surface damage; plan resurfacing of the affected stretch.',
  waterlogging: 'Alert Drainage Department; clear blocked storm-water drains and deploy pumps if critical.',
  missing_divider: 'Install temporary barricades immediately; replace divider blocks within 72 hours.',
  damaged_divider: 'Replace broken divider segments and inspect adjoining sections.',
  missing_zebra: 'Repaint crossing markings; prioritize school and hospital zones.',
  sign_damage: 'Traffic Police to replace or re-mount the damaged signage.',
  vehicle: 'Log vehicle event; forward ANPR record to Traffic Police if flagged.',
  congestion: 'Notify Traffic Police for signal retiming or manual regulation at the junction.',
  pedestrian_risk: 'Deploy traffic warden during peak hours; evaluate need for signalized crossing.',
  obstruction: 'Send municipal team to clear obstruction; issue notice if encroachment.',
  accident: 'Dispatch Emergency Services; Traffic Police to secure the site and divert traffic.',
  other: 'Route to Municipal Corporation for manual review.',
};

module.exports = {
  CATEGORIES, SEVERITIES, DEPARTMENTS, VEHICLE_TYPES,
  PLACES, ROUTE_DEFS, ROADS, AI_MODELS, modelFor, nearestPlace, RECOMMENDED_ACTION,
};
