'use strict';
/**
 * AI repair verification — closing the loop with re-observation, not buttons.
 *
 * While an incident is AWAITING_VERIFICATION:
 *  · a new detection of the same class within the merge radius  ⇒ verification FAILED
 *      → incident REOPENED, ticket REOPENED, notification raised.
 *  · an analysis run whose scanned frame covers the location WITHOUT detecting the
 *      class above threshold ⇒ a CLEAR verification observation is stored.
 * Closure requires (settings.verification): minClearObservations (default 3) AND
 * minIndependentDevices (default 2) AND zero re-detections ≥ confidenceThreshold
 * (default 0.55) since repair submission. Then: VERIFIED → CLOSED, ticket RESOLVED.
 */
const db = require('./db');
const geo = require('./geo');
const { uid } = require('./util');
const { audit, notify } = require('./audit');
const { transitionIncident, transitionTicket } = require('./state');
const { radiusFor } = require('./dedupe');

function cfg() {
  const r = db.getBy('settings', 'key', 'verification');
  return { minClearObservations: 3, minIndependentDevices: 2, confidenceThreshold: 0.55, ...((r && r.value) || {}) };
}

function record(incidentId, { result, deviceId, busId, jobId, confidence = null, latitude, longitude, evidenceRef = null }) {
  const c = cfg();
  const row = db.insert('verifications', {
    id: uid('VER'), incidentId, result, // 'CLEAR' | 'REDETECTED'
    deviceId: deviceId || null, busId: busId || null, jobId: jobId || null,
    confidence, threshold: c.confidenceThreshold,
    latitude, longitude, evidenceRef,
    timestamp: new Date().toISOString(),
  });
  return row;
}

/** Called by ingest when a detection lands on an incident AWAITING_VERIFICATION. */
function onRedetection(incident, det) {
  record(incident.id, { result: 'REDETECTED', deviceId: det.deviceId, busId: det.busId, jobId: det.jobId, confidence: det.confidence, latitude: det.latitude, longitude: det.longitude, evidenceRef: det.evidenceImage || null });
  const r = transitionIncident(incident.id, 'REOPENED', 'system', `Defect re-detected at ${(det.confidence * 100).toFixed(1)}% confidence — verification failed.`);
  if (incident.ticketId) transitionTicket(incident.ticketId, 'REOPENED', 'system', 'Verification failed — defect re-detected.');
  notify({ kind: 'VERIFICATION_FAILED', severity: 'critical', title: `Verification failed — ${incident.code}`, message: 'Post-repair scan re-detected the defect. Ticket reopened.', entityType: 'incident', entityId: incident.id, department: incident.department });
  audit('system', 'VERIFICATION_FAILED', 'incident', incident.id, `detection ${det.id}`);
  return r;
}

/**
 * Called after every completed analysis job: any AWAITING_VERIFICATION incident
 * whose location lies within the job's scan footprint, and which the job did NOT
 * re-detect, receives a CLEAR observation; closure conditions are then checked.
 * scan footprint = scanRadiusM around the job's geo anchor (uploaded clip GPS /
 * edge-client fix). No location on the job ⇒ no CLEAR credit (never guess).
 */
function onScanCompleted(job, detectionsCreated) {
  if (typeof job.latitude !== 'number' || typeof job.longitude !== 'number') return [];
  const scanRadiusM = job.scanRadiusM || 60;
  const awaiting = db.find('incidents', i => i.status === 'AWAITING_VERIFICATION');
  const results = [];
  for (const inc of awaiting) {
    const d = geo.haversineM(inc.latitude, inc.longitude, job.latitude, job.longitude);
    if (d > scanRadiusM + radiusFor(inc.category)) continue;
    const redetected = detectionsCreated.some(x => x.category === inc.category &&
      geo.haversineM(inc.latitude, inc.longitude, x.latitude, x.longitude) <= radiusFor(inc.category));
    if (redetected) continue; // ingest already routed it through onRedetection
    record(inc.id, { result: 'CLEAR', deviceId: job.deviceId, busId: job.busId, jobId: job.id, latitude: job.latitude, longitude: job.longitude });
    results.push({ incidentId: inc.id, cleared: true, closed: !!maybeClose(inc.id) });
  }
  return results;
}

function progress(incidentId) {
  const c = cfg();
  const inc = db.get('incidents', incidentId);
  const since = inc && (inc.repairSubmittedAt || inc.updatedAt);
  const rows = db.find('verifications', v => v.incidentId === incidentId && (!since || v.timestamp >= since));
  const clear = rows.filter(v => v.result === 'CLEAR');
  const redet = rows.filter(v => v.result === 'REDETECTED');
  const devices = new Set(clear.map(v => v.deviceId || v.busId).filter(Boolean));
  return {
    required: c, clearObservations: clear.length, independentDevices: devices.size,
    redetections: redet.length, rows,
    satisfied: redet.length === 0 && clear.length >= c.minClearObservations && devices.size >= c.minIndependentDevices,
  };
}

function maybeClose(incidentId) {
  const p = progress(incidentId);
  if (!p.satisfied) return null;
  const inc = db.get('incidents', incidentId);
  const v = transitionIncident(incidentId, 'VERIFIED', 'system', `Verified by re-observation: ${p.clearObservations} clear scans from ${p.independentDevices} independent devices.`);
  if (!v.ok) return null;
  transitionIncident(incidentId, 'CLOSED', 'system', 'Auto-closed after verified repair.');
  if (inc.ticketId) {
    transitionTicket(inc.ticketId, 'RESOLVED', 'system', 'Repair verified by post-repair observations.');
    transitionTicket(inc.ticketId, 'CLOSED', 'system', 'Closed with verified incident.');
    require('./sla').evaluateTicket(db.get('tickets', inc.ticketId));
  }
  return true;
}

module.exports = { record, onRedetection, onScanCompleted, progress, maybeClose, cfg };
