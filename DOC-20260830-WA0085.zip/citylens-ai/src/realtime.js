'use strict';
/**
 * Realtime layer. v1's simulator (random buses + generated detections) is GONE.
 * This module only (a) fans real events out over SSE, (b) runs the SLA
 * evaluator on the wall clock, (c) watches heartbeats and flags devices/buses
 * offline — all state changes here reflect real stored records and real time.
 */
const db = require('./db');
const sla = require('./sla');
const { notify, bindEmitter: bindAudit } = require('./audit');
const ingest = require('./ingest');

const clients = new Set();
let seq = 0;

function broadcast(event, data) {
  const payload = `id: ${++seq}\nevent: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) { try { res.write(payload); } catch { clients.delete(res); } }
}

function addClient(res) {
  clients.add(res);
  res.write(`event: hello\ndata: ${JSON.stringify({ now: new Date().toISOString(), clients: clients.size })}\n\n`);
  const ping = setInterval(() => { try { res.write(':ka\n\n'); } catch { clearInterval(ping); } }, 25000);
  res.on('close', () => { clients.delete(res); clearInterval(ping); });
}

const DEVICE_OFFLINE_MIN = 3;
const BUS_STALE_MIN = 5;

function watchdog() {
  const now = Date.now();
  for (const d of db.all('devices')) {
    const last = d.lastHeartbeatAt ? new Date(d.lastHeartbeatAt).getTime() : 0;
    const offline = !last || (now - last) > DEVICE_OFFLINE_MIN * 60000;
    if (offline && d.connectionStatus === 'online') {
      db.update('devices', d.id, { connectionStatus: 'offline' });
      notify({ kind: 'DEVICE_OFFLINE', severity: 'medium', title: `Device offline — ${d.deviceCode}`, message: `No heartbeat for ${DEVICE_OFFLINE_MIN}+ min (last ${d.lastHeartbeatAt || 'never'}).`, entityType: 'device', entityId: d.id, forRole: 'operator' });
      broadcast('device', { id: d.id, deviceCode: d.deviceCode, connectionStatus: 'offline' });
    }
  }
  for (const b of db.all('buses')) {
    const last = b.lastTelemetryAt ? new Date(b.lastTelemetryAt).getTime() : 0;
    const stale = !last || (now - last) > BUS_STALE_MIN * 60000;
    if (stale && b.status === 'active') {
      db.update('buses', b.id, { status: 'no_telemetry' });
      broadcast('bus', { id: b.id, busCode: b.busCode, status: 'no_telemetry' });
    }
  }
}

let timers = [];
function start() {
  bindAudit(broadcast);      // notifications stream out as they are created
  ingest.bindEmitter(broadcast);
  timers.push(setInterval(() => { const n = sla.evaluateAll(); if (n) broadcast('sla', { updated: n }); }, 60000));
  timers.push(setInterval(watchdog, 30000));
  sla.evaluateAll();
  watchdog();
  console.log('[realtime] SSE hub + SLA evaluator + heartbeat watchdog running (no simulation).');
}
function stop() { timers.forEach(clearInterval); timers = []; }

module.exports = { addClient, broadcast, start, stop };
