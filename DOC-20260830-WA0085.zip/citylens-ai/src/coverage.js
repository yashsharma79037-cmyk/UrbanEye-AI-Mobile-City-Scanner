'use strict';
/**
 * Coverage, road-health and traffic analytics — every number derives from
 * stored telemetry/incident records. With no data yet, the APIs say so
 * instead of inventing values.
 */
const db = require('./db');
const geo = require('./geo');

const NEAR_M = 45;           // a ping within 45 m of a segment counts as scanning it
const FRESH_MIN = 45, STALE_H = 6;

/** Build road_segments once from route geometry (config data, not observations). */
function ensureSegments() {
  if (db.count('road_segments', () => true) > 0) return;
  for (const r of db.all('routes')) {
    const wp = r.waypoints || [];
    for (let i = 0; i < wp.length - 1; i++) {
      db.insert('road_segments', {
        id: `SEG-${r.routeCode}-${i}`, routeId: r.id, routeCode: r.routeCode,
        roadName: r.roadNames && r.roadNames[i] ? r.roadNames[i] : r.routeName,
        a: wp[i], b: wp[i + 1],
        lengthM: Math.round(geo.haversineM(wp[i][0], wp[i][1], wp[i + 1][0], wp[i + 1][1])),
        importance: r.importance || 'arterial',
      });
    }
  }
}

/** Per-segment scan recency computed from telemetry. */
function coverage() {
  ensureSegments();
  const segs = db.all('road_segments');
  const pings = db.all('telemetry');
  const now = Date.now();
  const out = segs.map(s => {
    let last = null, count = 0, lastBus = null;
    for (const p of pings) {
      if (geo.pointToSegmentM(p.latitude, p.longitude, s.a[0], s.a[1], s.b[0], s.b[1]) <= NEAR_M) {
        count++;
        if (!last || p.timestamp > last) { last = p.timestamp; lastBus = p.busId || p.deviceId; }
      }
    }
    let status = 'uncovered';
    if (last) {
      const ageMin = (now - new Date(last)) / 60000;
      status = ageMin <= FRESH_MIN ? 'fresh' : ageMin <= STALE_H * 60 ? 'moderate' : 'stale';
    }
    return { ...s, lastScannedAt: last, observationCount: count, lastBus, status };
  });
  const km = st => Math.round(out.filter(s => st.includes(s.status)).reduce((a, s) => a + s.lengthM, 0) / 100) / 10;
  return {
    segments: out,
    totals: {
      segments: out.length,
      coveredKm: km(['fresh', 'moderate', 'stale']),
      freshKm: km(['fresh']),
      uncoveredKm: km(['uncovered']),
      telemetryPoints: pings.length,
    },
    thresholds: { nearM: NEAR_M, freshMin: FRESH_MIN, staleH: STALE_H },
  };
}

/**
 * Road health per road (0–100), documented formula over REAL incidents:
 *   health = 100 − 14·openCritical − 8·openOther − 4·recentClosed(30d) + 6·verifiedRepairs (cap 100, floor 0)
 * where incidents attach to a road by nearest segment (≤120 m).
 * Roads with zero linked incidents AND zero coverage report insufficient_data.
 */
function roadHealth() {
  ensureSegments();
  const segs = db.all('road_segments');
  const cov = coverage().segments;
  const byRoad = {};
  for (const s of segs) (byRoad[s.roadName] = byRoad[s.roadName] || { roadName: s.roadName, routeCode: s.routeCode, segs: [] }).segs.push(s);

  const incs = db.all('incidents');
  const d30 = new Date(Date.now() - 30 * 86400e3).toISOString();
  const rows = Object.values(byRoad).map(r => {
    const linked = incs.filter(i => {
      const n = geo.nearestSegment(r.segs, i.latitude, i.longitude, 120);
      return !!n;
    });
    const openCrit = linked.filter(i => !['CLOSED', 'REJECTED'].includes(i.status) && (i.impactScore || 0) >= 70).length;
    const openOther = linked.filter(i => !['CLOSED', 'REJECTED'].includes(i.status)).length - openCrit;
    const recentClosed = linked.filter(i => i.status === 'CLOSED' && i.closedAt >= d30).length;
    const verified = linked.filter(i => i.verifiedAt).length;
    const scanned = r.segs.some(s => cov.find(c => c.id === s.id && c.status !== 'uncovered'));
    const lengthKm = Math.round(r.segs.reduce((a, s) => a + s.lengthM, 0) / 100) / 10;
    if (!linked.length && !scanned) return { roadName: r.roadName, routeCode: r.routeCode, lengthKm, health: null, note: 'insufficient_data', openIncidents: 0 };
    const health = Math.max(0, Math.min(100, 100 - 14 * openCrit - 8 * openOther - 4 * recentClosed + 6 * Math.min(verified, 3)));
    return {
      roadName: r.roadName, routeCode: r.routeCode, lengthKm,
      health, openIncidents: openCrit + openOther, openCritical: openCrit,
      recentClosed30d: recentClosed, verifiedRepairs: verified,
      formula: '100 − 14·openCritical − 8·openOther − 4·closed30d + 6·min(verified,3)',
    };
  });
  const scored = rows.filter(r => r.health !== null);
  return { rows, cityAverage: scored.length ? Math.round(scored.reduce((a, r) => a + r.health, 0) / scored.length) : null, scoredRoads: scored.length };
}

/** Traffic analytics from telemetry speeds (real): per-segment avg speed + congestion flag. */
function traffic(hours = 3) {
  ensureSegments();
  const since = new Date(Date.now() - hours * 3600e3).toISOString();
  const pings = db.find('telemetry', p => p.timestamp >= since && typeof p.speed === 'number');
  const perSeg = {};
  for (const p of pings) {
    const n = geo.nearestSegment(db.all('road_segments'), p.latitude, p.longitude, 60);
    if (!n) continue;
    (perSeg[n.segment.id] = perSeg[n.segment.id] || { seg: n.segment, speeds: [] }).speeds.push(p.speed);
  }
  const rows = Object.values(perSeg).map(({ seg, speeds }) => {
    const avg = speeds.reduce((a, b) => a + b, 0) / speeds.length;
    return {
      segmentId: seg.id, roadName: seg.roadName, routeCode: seg.routeCode,
      samples: speeds.length, avgSpeed: Math.round(avg * 10) / 10,
      level: speeds.length < 5 ? 'insufficient_samples' : avg < 8 ? 'SEVERE' : avg < 14 ? 'HIGH' : avg < 22 ? 'MODERATE' : 'LOW',
    };
  }).sort((a, b) => a.avgSpeed - b.avgSpeed);
  return { windowHours: hours, samples: pings.length, rows, note: pings.length ? undefined : 'No telemetry with speed in window — connect the edge client or import a trace.' };
}

module.exports = { ensureSegments, coverage, roadHealth, traffic };
