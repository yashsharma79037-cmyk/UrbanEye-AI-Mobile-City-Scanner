#!/usr/bin/env python3
"""
CityLens Classical CV Analyzer v1 — real pixel-level inference (no fabrication).

Supported classes (honestly limited to what classical CV can defend):
  pothole      dark, roughly-convex blob on the road surface with strong local
               contrast versus its surrounding ring
  road_crack   thin, elongated high-gradient structure (skeleton-like component)
  road_damage  large irregular dark/rough surface region that is not blob-like

Method (documented, deterministic):
  * frames: images used as-is; videos sampled at ~1 fps via ffmpeg (max 24 frames)
  * ROI: lower 58% of the frame (dashcam road assumption)
  * pothole/damage: adaptive threshold (inverted) -> contours -> geometric +
    photometric features (area, solidity, aspect, inner-vs-ring darkness contrast)
  * crack: Canny -> dilate -> connected components filtered by elongation and fill
  * confidence: bounded weighted sum of measured features (formulas inline) —
    NEVER random. Weak candidates below 0.45 are discarded.
  * evidence: annotated full frame + tight crop written as real JPEGs
Outputs one JSON document on stdout. Any failure => {"ok": false, "error": ...}.
"""
import cv2, numpy as np, json, os, subprocess, sys, tempfile, time

MAX_FRAMES = 24
MIN_CONF = 0.45
CLASSES = ["pothole", "road_crack", "road_damage"]

def fail(msg):
    print(json.dumps({"ok": False, "error": msg})); sys.exit(0)

def sample_frames(src, workdir):
    ext = os.path.splitext(src)[1].lower()
    if ext in (".jpg", ".jpeg", ".png", ".webp", ".bmp"):
        return [(src, 0, 0.0)]
    # video → real frame extraction
    try:
        probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                "-of", "json", src], capture_output=True, text=True, timeout=30)
        dur = float(json.loads(probe.stdout)["format"]["duration"])
    except Exception as e:
        fail(f"ffprobe could not read the video: {e}")
    step = max(dur / MAX_FRAMES, 0.5)
    pattern = os.path.join(workdir, "f_%04d.jpg")
    r = subprocess.run(["ffmpeg", "-y", "-i", src, "-vf", f"fps=1/{step:.3f}",
                        "-frames:v", str(MAX_FRAMES), "-q:v", "3", pattern],
                       capture_output=True, timeout=180)
    if r.returncode != 0:
        fail("ffmpeg frame extraction failed: " + r.stderr.decode()[-300:])
    frames = sorted(f for f in os.listdir(workdir) if f.startswith("f_"))
    return [(os.path.join(workdir, f), i + 1, round((i + 0.5) * step, 2)) for i, f in enumerate(frames)]

def ring_contrast(gray, x, y, w, h):
    """mean(ring around box) - mean(inside box); positive = inside darker."""
    H, W = gray.shape
    pad = max(6, int(0.35 * max(w, h)))
    x0, y0 = max(0, x - pad), max(0, y - pad)
    x1, y1 = min(W, x + w + pad), min(H, y + h + pad)
    outer = gray[y0:y1, x0:x1].astype(np.float32)
    inner = gray[y:y + h, x:x + w].astype(np.float32)
    if inner.size == 0 or outer.size <= inner.size: return 0.0
    ring_sum = outer.sum() - inner.sum()
    ring_n = outer.size - inner.size
    return float(ring_sum / ring_n - inner.mean())

def detect_blobs(gray, roi_y, scale):
    """pothole / road_damage candidates from dark-region analysis."""
    roi = gray[roi_y:, :]
    blur = cv2.GaussianBlur(roi, (7, 7), 0)
    th = cv2.adaptiveThreshold(blur, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                               cv2.THRESH_BINARY_INV, 41, 12)
    th = cv2.morphologyEx(th, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    H, W = roi.shape
    out = []
    for c in cnts:
        area = cv2.contourArea(c)
        if area < 0.0018 * H * W or area > 0.16 * H * W: continue
        x, y, w, h = cv2.boundingRect(c)
        if w < 14 or h < 10: continue
        aspect = max(w / h, h / w)
        hull = cv2.convexHull(c)
        solidity = area / max(cv2.contourArea(hull), 1)
        contrast = ring_contrast(roi, x, y, w, h)          # measured darkness vs surroundings
        if contrast < 8: continue                          # not meaningfully darker than road
        fill = area / (w * h)
        # confidence = bounded weighted evidence (all measured):
        #   0.45 floor + contrast(≤.25) + solidity(≤.15) + compact aspect(≤.10) + fill(≤.05)
        conf = 0.45 + min(contrast / 90.0, 1.0) * 0.25 \
                    + max(0.0, (solidity - 0.55) / 0.45) * 0.15 \
                    + max(0.0, (2.6 - aspect) / 2.6) * 0.10 \
                    + max(0.0, (fill - 0.45) / 0.55) * 0.05
        if solidity >= 0.62 and aspect <= 3.2:
            klass = "pothole"
        elif area > 0.02 * H * W:
            klass = "road_damage"; conf -= 0.04
        else:
            continue
        conf = round(min(conf, 0.95), 3)
        if conf < MIN_CONF: continue
        out.append({
            "class": klass, "confidence": conf,
            "bbox_px": [int(x / scale), int((y + roi_y) / scale),
                        int((x + w) / scale), int((y + h + roi_y) / scale)],
            "features": {"area_frac": round(area / (H * W), 5), "solidity": round(solidity, 3),
                          "aspect": round(aspect, 2), "ring_contrast": round(contrast, 1), "fill": round(fill, 3)},
        })
    return out

def detect_cracks(gray, roi_y, scale):
    roi = gray[roi_y:, :]
    edges = cv2.Canny(cv2.GaussianBlur(roi, (5, 5), 0), 60, 150)
    grown = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(grown, connectivity=8)
    H, W = roi.shape
    out = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area < 120 or area > 0.05 * H * W: continue
        elong = max(w / max(h, 1), h / max(w, 1))
        fill = area / max(w * h, 1)
        if elong < 3.5 or fill > 0.35: continue            # thin + sparse = crack-like
        length = max(w, h)
        # confidence: 0.45 floor + elongation(≤.28) + length(≤.17) − density penalty
        conf = 0.45 + min((elong - 3.5) / 8.0, 1.0) * 0.28 + min(length / (0.7 * W), 1.0) * 0.17 \
                    - max(0.0, fill - 0.18) * 0.4
        conf = round(min(max(conf, 0.0), 0.92), 3)
        if conf < MIN_CONF: continue
        out.append({
            "class": "road_crack", "confidence": conf,
            "bbox_px": [int(x / scale), int((y + roi_y) / scale),
                        int((x + w) / scale), int((y + h + roi_y) / scale)],
            "features": {"elongation": round(float(elong), 2), "fill": round(float(fill), 3),
                          "length_px": int(length / scale)},
        })
    return out

def iou(a, b):
    ax1, ay1, ax2, ay2 = a; bx1, by1, bx2, by2 = b
    ix = max(0, min(ax2, bx2) - max(ax1, bx1)); iy = max(0, min(ay2, by2) - max(ay1, by1))
    inter = ix * iy
    ua = (ax2 - ax1) * (ay2 - ay1) + (bx2 - bx1) * (by2 - by1) - inter
    return inter / ua if ua else 0

def nms(dets, thr=0.45):
    dets = sorted(dets, key=lambda d: -d["confidence"]); keep = []
    for d in dets:
        if all(iou(d["bbox_px"], k["bbox_px"]) < thr for k in keep): keep.append(d)
    return keep

COLORS = {"pothole": (86, 86, 240), "road_crack": (52, 190, 245), "road_damage": (60, 140, 250)}

def annotate(img, dets, path):
    vis = img.copy()
    for d in dets:
        x1, y1, x2, y2 = d["bbox_px"]
        cv2.rectangle(vis, (x1, y1), (x2, y2), COLORS[d["class"]], 2)
        label = f'{d["class"]} {d["confidence"]:.2f}'
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(vis, (x1, max(0, y1 - th - 8)), (x1 + tw + 8, y1), COLORS[d["class"]], -1)
        cv2.putText(vis, label, (x1 + 4, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.imwrite(path, vis, [cv2.IMWRITE_JPEG_QUALITY, 82])

def main():
    try:
        cfg = json.loads(sys.argv[1]) if len(sys.argv) > 1 else json.load(sys.stdin)
    except Exception as e:
        fail(f"bad analyzer input: {e}")
    src, out_dir = cfg.get("path"), cfg.get("outDir")
    if not src or not os.path.exists(src): fail("input file not found")
    os.makedirs(out_dir, exist_ok=True)

    with tempfile.TemporaryDirectory() as work:
        frames = sample_frames(src, work)
        results, times = [], []
        for fpath, fno, tsec in frames:
            img = cv2.imread(fpath)
            if img is None: continue
            H0, W0 = img.shape[:2]
            scale = min(960.0 / W0, 1.0)
            small = cv2.resize(img, (int(W0 * scale), int(H0 * scale))) if scale < 1 else img
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            roi_y = int(gray.shape[0] * 0.42)              # analyse lower 58%
            t0 = time.time()
            dets = nms(detect_blobs(gray, roi_y, scale) + detect_cracks(gray, roi_y, scale))
            times.append((time.time() - t0) * 1000)
            for j, d in enumerate(dets[:6]):
                x1, y1, x2, y2 = d["bbox_px"]
                pad = 24
                crop = img[max(0, y1 - pad):min(H0, y2 + pad), max(0, x1 - pad):min(W0, x2 + pad)]
                cname = f"crop_{fno:03d}_{j}.jpg"
                cv2.imwrite(os.path.join(out_dir, cname), crop, [cv2.IMWRITE_JPEG_QUALITY, 82])
                d.update({"frame_number": fno, "frame_time_s": tsec,
                          "bbox_norm": {"x": round(x1 / W0, 4), "y": round(y1 / H0, 4),
                                         "w": round((x2 - x1) / W0, 4), "h": round((y2 - y1) / H0, 4)},
                          "evidence_crop": cname})
            if dets:
                aname = f"annot_{fno:03d}.jpg"
                annotate(img, dets[:6], os.path.join(out_dir, aname))
                for d in dets[:6]: d["evidence_annotated"] = aname
            results.extend(dets[:6])

        print(json.dumps({
            "ok": True, "engine": "classical-cv-v1", "classes": CLASSES,
            "framesProcessed": len(frames),
            "avgInferenceMs": round(sum(times) / len(times), 1) if times else None,
            "measuredFps": round(1000.0 / (sum(times) / len(times)), 1) if times and sum(times) else None,
            "results": results,
        }))

if __name__ == "__main__":
    main()
